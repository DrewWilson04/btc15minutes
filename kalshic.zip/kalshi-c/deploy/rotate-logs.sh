#!/usr/bin/env bash
# Keep the logs from ever filling the disk again.
# One bad night wrote 1.4 GB of repeated lines; this caps every log at 50 MB
# and keeps one previous copy. Run daily from launchd (see setup.md).
set -u
cd "$(dirname "$0")/.." || exit 1
MAX=$((50 * 1024 * 1024))

for f in logs/*.log logs/*/console.log logs/*/events.jsonl \
         logs/launchd.out.log logs/launchd.err.log; do
  [ -f "$f" ] || continue
  size=$(stat -f%z "$f" 2>/dev/null || echo 0)
  if [ "$size" -gt "$MAX" ]; then
    mv "$f" "$f.1"
    : > "$f"
    echo "$(date -u +%FT%TZ) rotated $f ($size bytes)"
  fi
done

# windows.jsonl and trades.log are the measurement record - never rotated,
# and they grow slowly (a few hundred KB a day).
