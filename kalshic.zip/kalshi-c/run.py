#!/usr/bin/env python3
"""Entry point.

    python run.py                 # paper mode against the live book
    python run.py --windows 4     # stop after 4 windows
    python run.py --check         # connectivity + credential check, no trading

Paper mode is the default and places no orders. Live mode requires BOTH
mode.live_trading: true in config.yaml AND a typed confirmation at startup.
"""

from __future__ import annotations

# macOS ships Python 3.9 as `python3`, and this needs 3.10+ for `X | Y` type
# unions, which are evaluated at import time. Without this check the failure is
# a bare `TypeError: unsupported operand type(s) for |` from deep inside a
# module, which tells you nothing about the real cause.
import sys as _sys
if _sys.version_info < (3, 10):
    _sys.exit(
        f"\nThis needs Python 3.10 or newer; you are on "
        f"{_sys.version.split()[0]} ({_sys.executable}).\n\n"
        f"macOS ships 3.9 as `python3`. Install a newer one and build the\n"
        f"virtualenv with it explicitly:\n\n"
        f"    brew install python@3.12\n"
        f"    rm -rf .venv\n"
        f"    python3.12 -m venv .venv\n"
        f"    ./.venv/bin/pip install -r requirements.txt\n")

import argparse
import asyncio
import logging
import os
import signal
import sys
import traceback
from pathlib import Path
from datetime import timedelta

from btcbot.auth import AuthError, KalshiSigner
from btcbot.clock import iso, sleep_until, utcnow
from btcbot.config import ConfigError, load_config
from btcbot.dashboard import BotState, Dashboard, attach_log_pane
from btcbot.web import WebDashboard
from btcbot.execution import LiveExecutor, PaperExecutor
from btcbot.feeds import KalshiIndexFeed, VenueFeed, build_feed
from btcbot.fees import FeeConfig
from btcbot.logging_jsonl import Logger, WindowRecord, setup_console_logging
from btcbot.orderbook import Book
from btcbot.portfolio import Portfolio
from btcbot.rest import KalshiREST, current_window_open, next_window_open
from btcbot.strategy_favorite import build_trader
from btcbot.strategy import WindowTrader
from btcbot.ws import MarketDataWS

log = logging.getLogger("run")


class SingleInstance:
    """Refuse to start a second bot against the same logs.

    Two bots sharing logs/windows.jsonl silently interleave their records, and
    the resulting file looks like one run with impossible sequences in it. The
    lock holds the PID so a stale file from a crash can be told apart from a
    live process.
    """

    def __init__(self, path: str = "logs/.bot.lock"):
        self.path = Path(path)
        self.acquired = False

    def acquire(self) -> tuple[bool, str]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                pid = int(self.path.read_text().strip())
            except (ValueError, OSError):
                pid = None
            if pid and pid != os.getpid() and _pid_alive(pid):
                return False, (
                    f"another bot is already running (pid {pid}).\n"
                    f"  Stop it first, or run:  kill {pid}\n"
                    f"  Two bots would interleave records in the same log files.")
            # Stale lock from a crash or a hard kill.
            self.path.unlink(missing_ok=True)
        self.path.write_text(str(os.getpid()))
        self.acquired = True
        return True, ""

    def release(self) -> None:
        if self.acquired:
            self.path.unlink(missing_ok=True)
            self.acquired = False


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


class Bot:
    def __init__(self, cfg, args):
        self.cfg = cfg
        self.args = args
        self.fee_cfg = FeeConfig.from_dict(cfg.get("fees"))
        self.logger = Logger(cfg)
        self.portfolio = Portfolio(cfg, self.fee_cfg)
        self.state_path = (cfg.get("capital.state_path", "./logs/state.json")
                           if cfg.get("capital.persist_state", True) else None)
        if getattr(args, "reset_state", False) and self.state_path:
            self.portfolio.reset(self.state_path)
        elif self.state_path and self.portfolio.load(self.state_path):
            p = self.portfolio
            log.info("restored state: balance $%.2f, cap %d, streak W%d L%d%s",
                     p.balance, p.buy_cap, p.consecutive_wins,
                     p.consecutive_losses,
                     f", HALTED ({p.halt_reason})" if p.halted else "")
        self.book = Book()
        self.signer = self._build_signer()
        self.rest = KalshiREST(cfg.api_base, self.signer)
        self.feed = build_feed(cfg)
        self.cross_feed = self._build_cross_feed()
        self.market_ws: MarketDataWS | None = None
        self.executor = self._build_executor()
        self._tasks: list[asyncio.Task] = []
        self._stopping = False
        self.windows_done = 0
        self._paint_errors = 0
        self._last_open_traded = None
        self._watching: str | None = None   # ticker the book is following
        self._halt_announced = False
        self.dash: Dashboard | None = None
        self.web: WebDashboard | None = None
        self.state: BotState | None = None
        want_tui = getattr(args, "dashboard", False)
        want_web = getattr(args, "web", False)
        if want_tui or want_web:
            # The web page keeps its own log panel; the TUI redirects logging
            # into it. Either way logs stop scrolling over the display.
            pane = attach_log_pane(
                maxlen=40 if want_web and not want_tui else 9,
                keep_console=want_web and not want_tui)
            self.state = BotState(cfg, self.portfolio, self.book, self.feed,
                                  mode="LIVE" if cfg.live_trading else "PAPER")
            if want_tui:
                self.dash = Dashboard(self.state, pane,
                                      theme=cfg.get('logging.dashboard_theme', 'dark'))
            if want_web:
                self.web = WebDashboard(self.state, pane,
                                        host=getattr(args, "host", "127.0.0.1"),
                                        port=getattr(args, "port", 8787),
                                        on_reset=self._reset_state)

    # -- construction -------------------------------------------------------

    def _build_signer(self) -> KalshiSigner:
        creds = self.cfg.creds
        if not creds.api_key_id or not creds.private_key_path:
            raise ConfigError(
                "Kalshi API credentials missing. Copy .env.example to .env and "
                "set KALSHI_API_KEY_ID and KALSHI_PRIVATE_KEY_PATH.\n"
                "Generate them at: Kalshi -> Settings -> API Keys -> Create New.\n"
                "Paper mode still needs them: the order book and index feeds "
                "are authenticated even for read-only access.")
        return KalshiSigner(creds.api_key_id, creds.private_key_path)

    def _build_cross_feed(self):
        cc = self.cfg.get("price_feed.cross_check", {})
        if not cc.get("enabled"):
            return None
        try:
            return VenueFeed(cc.get("venue", "coinbase"))
        except ValueError:
            log.warning("cross-check venue unknown; disabling cross-check")
            return None

    def _build_executor(self):
        if not self.cfg.live_trading:
            return PaperExecutor(self.fee_cfg, self.cfg.get("execution.paper", {}))
        return LiveExecutor(self.fee_cfg, self.rest, armed=True)

    # -- live-mode gate -----------------------------------------------------

    @staticmethod
    def confirm_live(cfg) -> bool:
        phrase = cfg.get("safety.live_confirmation_phrase")
        cap = cfg.get("safety.absolute_max_window_notional_usd")
        print("\n" + "=" * 72)
        print("  LIVE TRADING IS ENABLED IN config.yaml")
        print("  Real orders will be placed against your Kalshi account with")
        print(f"  real money. Max exposure per window: ${cap:.2f}")
        print("=" * 72)
        if not sys.stdin.isatty():
            print("  Refusing to arm live trading without an interactive terminal.")
            return False
        print(f"\n  Type exactly:  {phrase}")
        try:
            typed = input("  > ").strip()
        except (EOFError, KeyboardInterrupt):
            return False
        if typed != phrase:
            print("  Confirmation did not match. Staying in paper mode is safer;")
            print("  exiting instead of guessing what you meant.")
            return False
        print("  Live trading armed.\n")
        return True

    # -- feed plumbing ------------------------------------------------------

    # Wire field names below are what the live socket actually sends. They are
    # NOT the ones in the docs, and reading the wrong ones fails silently: the
    # book simply stays empty and every entry is rejected as "no_book".
    async def _on_snapshot(self, msg: dict) -> None:
        self.book.apply_snapshot(msg.get("yes_dollars_fp") or msg.get("yes") or [],
                                 msg.get("no_dollars_fp") or msg.get("no") or [],
                                 msg.get("seq", 0))
        self.logger.tape.record("book_snapshot", msg)

    async def _on_delta(self, msg: dict) -> None:
        side = msg.get("side")
        if side not in ("yes", "no"):
            return
        price = msg.get("price_dollars", msg.get("price"))
        delta = msg.get("delta_fp", msg.get("delta"))
        if price is None or delta is None:
            return
        self.book.apply_delta(side, price, delta, msg.get("seq", 0))
        self.logger.tape.record("book_delta", msg)

    async def _on_trade(self, msg: dict) -> None:
        self.logger.tape.record("trade", msg)
        if isinstance(self.executor, PaperExecutor):
            taker = msg.get("taker_side")
            price = (msg.get("yes_price_dollars") if taker == "yes"
                     else msg.get("no_price_dollars"))
            count = msg.get("count_fp", msg.get("count"))
            if taker in ("yes", "no") and price is not None and count is not None:
                self.executor.on_trade(taker, price, count)

    async def _on_index_tick(self, payload: dict) -> None:
        self.logger.tape.record("index", payload)
        if isinstance(self.feed, KalshiIndexFeed):
            self.feed.handle_payload(payload)

    # -- lifecycle ----------------------------------------------------------

    async def _observe_loop(self) -> None:
        """Keep the dashboard's idle view fresh: which window is live right
        now and what its target is. Display only — this market is never
        traded from here, it just proves the feed and the target line up."""
        while not self._stopping:
            try:
                if self.state is not None:
                    self.state.ws_market = bool(
                        self.market_ws and self.market_ws.connected.is_set())
                    self.state.ws_index = bool(
                        self.market_ws and self.market_ws.connected.is_set()
                        and self.feed.state.tick_count > 0)
                    self.state.next_open = next_window_open(
                        window_seconds=int(self.cfg.get("market.window_seconds")))
                    if self.state.trader is None:
                        cur = current_window_open(
                            window_seconds=int(self.cfg.get("market.window_seconds")))
                        m = await self.rest.find_window_market(
                            self.cfg.get("market.series_ticker"), cur)
                        self.state.observed_market = m
                        # Follow the observed market's book too. Without this
                        # the dashboards show no yes/no prices whenever the bot
                        # is not trading — between rounds, and for the whole of
                        # a round it joined too late to trade.
                        if (m is not None and self.market_ws is not None
                                and self._watching != m.ticker):
                            await self.market_ws.set_ticker(m.ticker)
                            self._watching = m.ticker
                    else:
                        self.state.observed_market = None
            except Exception:  # noqa: BLE001 - purely cosmetic, never fatal
                pass
            await asyncio.sleep(2.0)

    async def _paint_loop(self) -> None:
        """Repaint at a steady rate; the panels read live objects directly."""
        while not self._stopping:
            try:
                self.dash.render()
            except Exception:  # noqa: BLE001 - drawing must never kill the bot
                # Never fatal, but never silent either: a swallowed render
                # error looks exactly like a frozen bot from the outside.
                self._paint_errors += 1
                if self._paint_errors == 5:
                    # The dashboard is the only thing the operator can see. If
                    # it is broken, say so in plain text rather than leaving a
                    # frozen screen that looks like a hung bot.
                    print("\033[0m\n!! dashboard render is failing — the bot is "
                          "STILL TRADING; see logs/dashboard_errors.log\n",
                          flush=True)
                if self._paint_errors in (1, 5, 10, 100):
                    Path("logs/dashboard_errors.log").parent.mkdir(
                        parents=True, exist_ok=True)
                    with open("logs/dashboard_errors.log", "a") as fh:
                        fh.write(f"--- paint error #{self._paint_errors} ---\n")
                        traceback.print_exc(file=fh)
            await asyncio.sleep(0.2)

    async def start_streams(self) -> None:
        is_index = isinstance(self.feed, KalshiIndexFeed)
        k = self.cfg.get("price_feed.kalshi_index", {})
        self.market_ws = MarketDataWS(
            self.cfg.ws_url, self.signer, self.cfg.ws_sign_path,
            self._on_snapshot, self._on_delta, self._on_trade,
            on_index=self._on_index_tick if is_index else None,
            index_channel=k.get("channel", "cfbenchmarks_value"),
            index_id=k.get("index_id") if is_index else None,
            on_gap=self._on_ws_gap)
        self._tasks.append(asyncio.create_task(self.market_ws.run()))
        if not is_index:
            self._tasks.append(asyncio.create_task(self.feed.run()))

        if self.cross_feed is not None:
            self._tasks.append(asyncio.create_task(self.cross_feed.run()))

        if self.dash is not None:
            self.dash.start()
            self._tasks.append(asyncio.create_task(self._paint_loop()))
        if self.web is not None:
            self._tasks.append(asyncio.create_task(self.web.run()))
        if self.state is not None:
            self._tasks.append(asyncio.create_task(self._observe_loop()))

    async def check(self) -> int:
        """Connectivity and credential check. Trades nothing."""
        print(f"config:      {self.cfg.path}")
        print(f"environment: {self.cfg.environment}  ({self.cfg.api_base})")
        print(f"mode:        {'LIVE' if self.cfg.live_trading else 'PAPER'}")
        print(f"credentials: {self.cfg.creds.redacted()}")
        rc = 0
        try:
            status = await self.rest.exchange_status()
            print(f"exchange:    OK {status}")
        except Exception as exc:  # noqa: BLE001
            print(f"exchange:    FAIL {exc}")
            rc = 1

        try:
            m = await self.rest.find_window_market(
                self.cfg.get("market.series_ticker"),
                next_window_open(window_seconds=self.cfg.get("market.window_seconds")))
            if m:
                print(f"next market: {m.ticker} target ${m.target:,.2f} "
                      f"opens {iso(m.open_time)}")
            else:
                print("next market: not published yet (normal well before open)")
        except Exception as exc:  # noqa: BLE001
            print(f"next market: FAIL {exc}")
            rc = 1

        await self.start_streams()
        print("\nwaiting 20s for streams...")
        await asyncio.sleep(20)
        idx_ok = self.feed.state.tick_count > 0
        print(f"index feed:  {'OK' if idx_ok else 'NO TICKS'} "
              f"({self.feed.state.tick_count} ticks"
              f"{f', last {self.feed.price:,.2f}' if self.feed.price else ''})")
        print(f"order book:  {'OK' if self.book.is_ready() else 'no book yet'} "
              f"(subscribed once a window market is live)")
        if self.cross_feed:
            print(f"cross-check: {self.cross_feed.state.tick_count} ticks"
                  f"{f', {self.cross_feed.price:,.2f}' if self.cross_feed.price else ''}")
        if not idx_ok:
            rc = 1
        await self.stop()
        return rc

    async def run_forever(self) -> None:
        await self.start_streams()
        series = self.cfg.get("market.series_ticker")
        window_seconds = int(self.cfg.get("market.window_seconds"))
        prearm = float(self.cfg.get("market.prearm_seconds"))
        grace = float(self.cfg.get("market.missing_market_grace_seconds"))

        log.info("paper bot up. balance $%.2f, buy cap %d, mode %s",
                 self.portfolio.balance, self.portfolio.buy_cap,
                 "LIVE" if self.cfg.live_trading else "PAPER")

        # A restart mid-round should not forfeit the round: if we are still
        # inside the trigger gate, join it now rather than idling until the
        # next boundary. elapsed() is anchored to Kalshi's open_time, so the
        # gate means the same thing either way.
        if self.cfg.get("market.join_round_in_progress", True):
            joined = await self._maybe_join_current(series, grace)
            if joined:
                self.windows_done += 1
                if self.state_path:
                    self.portfolio.save(self.state_path)

        while not self._stopping:
            if self.portfolio.halted:
                # Halting stops TRADING, not the program. Breaking out here
                # ended the process, which took the dashboard, the receipts
                # and the trade ledger down with it — exactly when you most
                # want to read them. Idle instead, and keep serving.
                if not self._halt_announced:
                    self._halt_announced = True
                    log.error("halted (%s) — no further windows will be "
                              "traded. The dashboard stays up; clear the "
                              "cache to resume.", self.portfolio.halt_reason)
                await asyncio.sleep(15.0)
                continue
            if self.args.windows and self.windows_done >= self.args.windows:
                log.info("reached --windows %d, stopping", self.args.windows)
                break

            # A round closes at the exact instant the next one opens, so
            # asking for "the next boundary strictly after now" at that moment
            # skips a whole round — the bot traded every OTHER round. Prefer
            # the round currently open, as long as we have not already traded
            # it and its trigger gate is still open.
            gate = float(self.cfg.get("trigger.max_elapsed_seconds"))
            cur = current_window_open(window_seconds=window_seconds)
            if (cur != self._last_open_traded
                    and (utcnow() - cur).total_seconds() < gate):
                open_at = cur
            else:
                open_at = next_window_open(window_seconds=window_seconds)
            await sleep_until(open_at - timedelta(seconds=prearm))
            if self._stopping:
                break

            market = await self._acquire_market(series, open_at, grace)
            if market is None:
                log.warning("no market for window %s; skipping", iso(open_at))
                self.logger.event("window_skipped", window_open=iso(open_at),
                                  reason="market_never_appeared")
                # sleep_until returns instantly when the deadline has already
                # passed, so on its own this spins: it burns a core and floods
                # the log with the same line thousands of times. Always give
                # the retry a real floor.
                retry_at = open_at + timedelta(seconds=grace + 5)
                if retry_at <= utcnow():
                    await asyncio.sleep(10.0)
                else:
                    await sleep_until(retry_at)
                continue

            await self.market_ws.set_ticker(market.ticker)
            self._watching = market.ticker
            await sleep_until(market.open_time)
            await self._await_book(market)

            self._last_open_traded = market.open_time

            # Cooldown after a cluster of losses: sit the round out, but log
            # it so the gap is visible rather than looking like downtime.
            if not self.portfolio.start_round():
                log.warning("sitting out %s (cooldown, %d more after this)",
                            market.ticker, self.portfolio.cooldown_remaining)
                self.logger.event("cooldown_skip", window=market.ticker,
                                  remaining=self.portfolio.cooldown_remaining)
                rec = WindowRecord(window_id=market.ticker,
                                   ticker=market.ticker,
                                   open_time=iso(market.open_time),
                                   close_time=iso(market.close_time),
                                   target_price=market.target,
                                   no_entry_reason="cooldown_after_losses",
                                   buy_cap=self.portfolio.buy_cap)
                st = self.portfolio.state_dict()
                rec.balance_after = st["balance"]
                rec.halted = st["halted"]
                self.logger.window(rec)
                if self.state:
                    self.state.recent.append(rec)
                if self.state_path:
                    self.portfolio.save(self.state_path)
                await sleep_until(market.close_time)
                continue

            record = await self._trade_window(market)
            if self.state_path:
                self.portfolio.save(self.state_path)
            if record is None:
                self.logger.tape.close()
                continue

            self.windows_done += 1
            # Do not re-enter the same window if we finished early.
            if market.remaining() > 0:
                await sleep_until(market.close_time)
            # Now the round is genuinely over: observe where it actually
            # settled. Without this, a round the bot exited early has no
            # settlement price at all, and "was the direction right?" can only
            # be answered for the rounds it failed to sell — which is exactly
            # the rounds that went wrong.
            self._record_settlement(market, record)
            self.logger.tape.close()

        await self.stop()

    def _record_settlement(self, market, record) -> None:
        """Log where the round actually settled, however it was exited."""
        try:
            price = self.feed.price
            target = market.target
            if price is None or target is None:
                self.logger.event("settlement", window=market.ticker,
                                  target=target, btc=price, won=None,
                                  reason="no_price_at_close")
                return
            above = price >= target
            direction = record.direction
            won = None
            if direction in ("up", "down"):
                won = above if direction == "up" else not above
            self.logger.event("settlement", window=market.ticker,
                              target=target, btc=price,
                              margin=round(price - target, 4),
                              direction=direction, won=won,
                              traded=bool(record.capital_deployed),
                              net_pnl=record.net_pnl)
            if won is not None:
                log.info("settled %s: BTC %.2f vs target %.2f (%+.2f) — %s "
                         "was %s", market.ticker, price, target, price - target,
                         direction.upper(), "RIGHT" if won else "WRONG")
        except Exception:  # noqa: BLE001 - observation must never break the run
            log.debug("settlement observation failed", exc_info=True)

    def _reset_state(self) -> dict:
        """Clear cached streaks/balance. Called from the web Reset button."""
        before = self.portfolio.reset(self.state_path)
        if self.state is not None:
            self.state.recent.clear()
        return before

    async def _on_ws_gap(self) -> None:
        """Drop the book on disconnect: stale depth is worse than no depth."""
        if self.book.is_ready():
            log.warning("websocket gap — clearing the book until a fresh snapshot")
        self.book.clear()

    async def _await_book(self, market, timeout: float = 10.0) -> bool:
        """Wait for the first usable book, and complain loudly if none comes.

        An empty book rejects every entry with "no_book", which from the
        outside is indistinguishable from a quiet market — so it gets said out
        loud rather than left for the logs.
        """
        deadline = utcnow().timestamp() + timeout
        while utcnow().timestamp() < deadline:
            if self.book.is_ready():
                log.info("book ready for %s (bid/ask yes %.3f/%.3f, %d snapshots)",
                         market.ticker, self.book.bid("yes") or 0,
                         self.book.ask("yes") or 0, self.book.snapshots)
                return True
            await asyncio.sleep(0.2)
        log.error("NO ORDER BOOK for %s after %.0fs (snapshots=%d deltas=%d) — "
                  "entries will be rejected; check the websocket subscription",
                  market.ticker, timeout, self.book.snapshots, self.book.deltas)
        self.logger.event("book_missing", window=market.ticker,
                          snapshots=self.book.snapshots, deltas=self.book.deltas)
        return False

    async def _trade_window(self, market):
        """Run one round end to end. Returns its record, or None if it crashed."""
        trader_cls = build_trader(self.cfg.get("strategy.name", "ladder"))
        trader = trader_cls(self.cfg, market, self.book, self.feed,
                            self.executor, self.portfolio, self.fee_cfg,
                            self.logger, self.cross_feed)
        if self.state:
            self.state.market = market
            self.state.trader = trader
        try:
            record = await trader.run()
            if self.state:
                self.state.recent.append(record)
                self.state.trader = None
                # Clear the market too, or the WINDOW panel keeps showing a
                # closed round and the dashboard looks frozen.
                self.state.market = None
            log.info("round %s done: net $%+.3f | balance $%.2f | cap %d | "
                     "streak W%d L%d", record.window_id, record.net_pnl,
                     self.portfolio.balance, self.portfolio.buy_cap,
                     self.portfolio.consecutive_wins,
                     self.portfolio.consecutive_losses)
            return record
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 - one bad round must not kill the run
            if self.state:
                self.state.trader = None
                self.state.market = None
            log.exception("round %s crashed; continuing", market.ticker)
            self.logger.event("window_error", window=market.ticker)
            await sleep_until(market.close_time)
            return None

    async def _maybe_join_current(self, series, grace) -> bool:
        """Trade the in-flight round if its trigger gate has not closed."""
        if self.portfolio.halted:
            # Joining a round in progress skipped the halt check the main
            # loop does, so a halted bot resumed trading on restart.
            log.info("halted (%s) — not joining the round in progress",
                     self.portfolio.halt_reason)
            return False
        gate = float(self.cfg.get("trigger.max_elapsed_seconds"))
        cur_open = current_window_open(
            window_seconds=int(self.cfg.get("market.window_seconds")))
        elapsed = (utcnow() - cur_open).total_seconds()
        if elapsed >= gate:
            log.info("round %s is %.0fs in (gate %.0fs) — waiting for the next one",
                     iso(cur_open), elapsed, gate)
            return False
        try:
            market = await self.rest.find_window_market(series, cur_open)
        except Exception as exc:  # noqa: BLE001
            log.warning("could not look up the in-flight round: %s", exc)
            return False
        if market is None:
            return False
        agrees, shown = market.verify_target()
        if not agrees:
            log.error("TARGET MISMATCH on %s — not joining", market.ticker)
            return False
        log.info("joining round %s already in progress (%.0fs elapsed, "
                 "%.0fs of trigger gate left), target $%.2f",
                 market.ticker, elapsed, gate - elapsed, market.target)
        self._last_open_traded = market.open_time
        await self.market_ws.set_ticker(market.ticker)
        await self._await_book(market)
        await self._trade_window(market)
        if market.remaining() > 0:
            await sleep_until(market.close_time)
        return True

    async def _acquire_market(self, series, open_at, grace):
        """Poll until the window's target is published.

        The strike appears at the open bell, occasionally a beat after the
        market itself. Every second spent here is a second of the 5-minute
        trigger gate burned, so this polls hard rather than politely.
        """
        deadline = open_at.timestamp() + grace
        announced = False
        while utcnow().timestamp() < deadline:
            try:
                m = await self.rest.find_window_market(series, open_at)
                if m:
                    agrees, shown = m.verify_target()
                    if not agrees:
                        # Two Kalshi fields disagree about the target. Refuse
                        # the window rather than guess which one is right.
                        log.error("TARGET MISMATCH on %s: floor_strike=%.2f but "
                                  "the record's own subtitle says %.2f — skipping "
                                  "this window", m.ticker, m.floor_strike, shown)
                        self.logger.event("target_mismatch", window=m.ticker,
                                          floor_strike=m.floor_strike,
                                          subtitle_value=shown)
                        return None
                    log.info("window %s: %s target $%.2f%s (%.1fs after open)",
                             iso(open_at), m.ticker, m.target,
                             " ✓confirmed" if shown is not None else "",
                             utcnow().timestamp() - open_at.timestamp())
                    return m
                if not announced and utcnow() >= open_at:
                    log.info("window %s open, waiting for target to publish…",
                             iso(open_at))
                    announced = True
            except Exception as exc:  # noqa: BLE001
                log.warning("market lookup failed: %s", exc)
            await asyncio.sleep(0.5)
        return None

    async def stop(self) -> None:
        self._stopping = True
        if self.market_ws:
            await self.market_ws.stop()
        if self.cross_feed:
            await self.cross_feed.stop()
        if self.web:
            await self.web.stop()
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        if self.state_path:
            self.portfolio.save(self.state_path)
        await self.rest.close()
        # The logger is NOT closed here. run_forever() may still be
        # inside a round, and _finish() writing to a closed file loses
        # the whole round record. amain() closes it once the loop is out.
        if self.dash:
            self.dash.stop()


async def amain(args) -> int:
    cfg = load_config(args.config, profile=args.profile)
    setup_console_logging(cfg.get("logging.console_level", "INFO"))

    if cfg.live_trading and not args.check:
        if not Bot.confirm_live(cfg):
            return 2

    # One lock per log directory: three configs writing three different logs
    # are three different bots and must be allowed to run side by side.
    log_dir = Path(cfg.get("logging.window_log_path", "./logs/windows.jsonl")).parent
    lock = SingleInstance(str(log_dir / ".bot.lock"))
    if not args.check:
        ok, why = lock.acquire()
        if not ok:
            print(f"\nrefusing to start: {why}\n", file=sys.stderr)
            return 3

    bot = Bot(cfg, args)

    if args.check:
        return await bot.check()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, lambda: asyncio.create_task(bot.stop()))
        except NotImplementedError:
            pass

    if bot.web is not None and bot.dash is None:
        print(f"\n  KXBTC15M paper bot — dashboard at "
              f"http://{args.host}:{args.port}\n"
              f"  logs: {cfg.get('logging.window_log_path')}   Ctrl-C to stop\n")

    try:
        await bot.run_forever()
    except asyncio.CancelledError:
        pass
    finally:
        # Now the round loop has genuinely stopped, so nothing can still be
        # trying to write a record.
        try:
            bot.logger.close()
        except Exception:  # noqa: BLE001 - never mask the real exit reason
            pass
        lock.release()
        p = bot.portfolio
        print(f"\nfinal balance ${p.balance:.2f} "
              f"(started ${p.starting_balance:.2f}, "
              f"{bot.windows_done} windows)")
        if p.halted:
            print(f"HALTED: {p.halt_reason}")
        print(f"window log: {cfg.get('logging.window_log_path')}")
        print("summary:    python summarize.py")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Kalshi KXBTC15M paper trading bot")
    ap.add_argument("--config", default=None, help="path to config.yaml")
    ap.add_argument("--windows", type=int, default=0,
                    help="stop after N windows (0 = run until halted)")
    ap.add_argument("--dashboard", action="store_true",
                    help="live terminal dashboard instead of scrolling logs")
    ap.add_argument("--web", action="store_true",
                    help="serve a live dashboard at http://127.0.0.1:8787 "
                         "(survives closing the browser tab)")
    ap.add_argument("--port", type=int, default=8787, help="port for --web")
    ap.add_argument("--host", default="127.0.0.1",
                    help="bind address for --web (default localhost only)")
    ap.add_argument("--profile", default=None,
                    help="rule profile to run (see `profiles:` in config.yaml, "
                         "e.g. light or heavy). Defaults to active_profile.")
    ap.add_argument("--reset-state", action="store_true",
                    help="clear the cached balance, streaks and halt state "
                         "before starting")
    ap.add_argument("--check", action="store_true",
                    help="check credentials and feeds, then exit")
    args = ap.parse_args()
    try:
        return asyncio.run(amain(args))
    except (ConfigError, AuthError) as exc:
        print(f"\nconfiguration problem:\n  {exc}\n", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
