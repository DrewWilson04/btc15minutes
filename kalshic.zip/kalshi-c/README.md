# Kalshi KXBTC15M — favourite strategy (run C)

Paper-money bot for Kalshi's 15-minute Bitcoin market. It watches each round,
and if the round qualifies it buys a heavy favourite late and holds it to
settlement.

**This build cannot place a real order.** `LiveExecutor.buy` raises
`NotImplementedError` and the REST client has no POST method at all — only
`get()`. `mode.live_trading` is `false`. Nothing here can touch real money.

---

## The strategy

    1. Watch the first 12:00 - observation only, nothing is bought.
    2. The round must have TRAVELLED at least $35 (furthest above target plus
       furthest below).
    3. Skip if BTC ran more than $100 AGAINST the side being bought, or more
       than $100 in BOTH directions.
    4. Only inside the last 2:45, buy whichever side is offered at 0.93+.
    5. Hold it to settlement. There is no exit rule - it never sells.

    $20 a round, dropping to $16 for two rounds after a loss.

### Know what this bet is

Paying 0.93 to win 1.00 is **+7.5% before fees**, against losing the entire
stake if it goes the other way. It needs to be right about **93% of the time**
just to break even — roughly **33 wins to pay for one loss**.

Judge it on wins-per-loss, not on win rate. A night of 55W/2L looks like 96%
and is a losing night.

### What the record actually says

At the time this package was cut: **16W/1L and still down $10.89.** Both losses
so far contradict each other — one round was pinned to the target and drifted
$3 the wrong way, the other had $56 of cushion and blew through it by $143 in
165 seconds. The $35 range rule is a hypothesis under test, not a proven edge.

---

## Setup

**Needs Python 3.10 or newer.** macOS ships 3.9 as `python3`, which will not
run this — it uses `X | Y` type unions that are evaluated at import time.
Check first:

    python3 -V

If that says 3.9.x, install a newer one and build the virtualenv with it
**explicitly by version**, not with plain `python3`:

    brew install python@3.12
    python3.12 -m venv .venv
    ./.venv/bin/pip install -r requirements.txt

If `python3 -V` already says 3.10+:

    python3 -m venv .venv
    ./.venv/bin/pip install -r requirements.txt

Built and tested on 3.12. `run.py` checks the version and tells you what to do
if it is too old.

Copy your credentials in by hand — never through git:

    cp /path/to/.env .
    cp /path/to/kalshi_private_key.pem .
    chmod 600 .env kalshi_private_key.pem

Check it can reach Kalshi:

    ./.venv/bin/python run.py --config config.yaml --check

Run it:

    ./.venv/bin/python run.py --config config.yaml --web --port 8791

Dashboard: http://127.0.0.1:8791 — live prices, per-round receipts, the rules
it is actually running, and the full buy/sell ledger.

---

## Running it 24/7 on a dedicated Mac

    sudo pmset -a sleep 0 disksleep 0 powernap 0

`caffeinate` in the launchd job handles staying awake, so it does not matter
if your Mac lacks `disablesleep`. **Leave the lid open** — clamshell sleep is a
separate mechanism and is the one thing that will silently stop the bot with
nothing in the logs.

For it to restart after a reboot you need automatic login, which requires
FileVault OFF. That is a real trade-off: unattended restarts versus an
encrypted disk holding your private key.

    # edit both plists: replace YOURNAME with `whoami`
    cp deploy/*.plist ~/Library/LaunchAgents/
    launchctl load -w ~/Library/LaunchAgents/com.skoralabs.kalshibot.plist
    launchctl load -w ~/Library/LaunchAgents/com.skoralabs.logrotate.plist

`KeepAlive` restarts the bot on any crash. Log rotation runs at 04:00 and caps
each log at 50 MB — one bug once wrote 1.4 GB in minutes. `windows.jsonl` and
`trades.log` are never rotated; they are the measurement record.

**Do not put this in ~/Desktop or ~/Documents if iCloud Drive is on.** macOS
evicts files it thinks are cold, and a tape read has already failed with
`TimeoutError` on a supposedly local file. `~/kalshi-c` is safe.

---

## Output

    logs/c/windows.jsonl   one record per round - the measurement artifact
    logs/c/trades.log      every buy and sell, one line each, as they happen
    logs/c/events.jsonl    fine-grained events, including price_around_buy
    logs/c/state.json      balance and streaks, survives restarts

    ./.venv/bin/python summarize.py --log logs/c/windows.jsonl
    ./.venv/bin/python replay.py --tape tape --config config.yaml --speed 0

Every round logs its `range:` note, so any minimum-movement threshold can be
tested retrospectively without having pre-committed to one.

---

## Before this ever touches real money

  * **Rotate the API key.** The key used in development was pasted into a chat
    transcript. Revoke it at Kalshi and issue a new one.
  * Live order placement, order-state recovery on restart, and reconciliation
    against real fills all still have to be built.
  * No configuration in this repo has demonstrated a profitable edge.
