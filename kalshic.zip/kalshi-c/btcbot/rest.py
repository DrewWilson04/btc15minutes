"""Kalshi REST client: market discovery and metadata.

Read-only except for order placement, which is only reachable in live mode and
is routed through execution.py's LiveExecutor, never called directly here.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timedelta

import httpx

from .auth import KalshiSigner
from .clock import parse_iso, utcnow

log = logging.getLogger(__name__)


@dataclass
class Market:
    """One 15-minute window's market. Up = YES, Down = NO on this ticker.

    NOTE: `floor_strike` is None until the window actually opens. Kalshi lists
    future windows as status "initialized" with "Target price: TBD" and fills
    the strike in at the open bell. A market without a target is real and
    valid — it just cannot be traded yet.
    """
    ticker: str
    event_ticker: str
    floor_strike: float | None
    open_time: datetime
    close_time: datetime
    status: str
    title: str
    raw: dict

    @property
    def target(self) -> float | None:
        """The window's target price, read straight off the market record."""
        return self.floor_strike

    @property
    def has_target(self) -> bool:
        return self.floor_strike is not None

    def verify_target(self) -> tuple[bool, float | None]:
        """Cross-check `floor_strike` against Kalshi's own rendered subtitle.

        The record carries the target twice: once as the machine field
        `floor_strike`, once as human text, e.g. "Target Price: $79,995.38".
        They come from the same exchange but different fields, so agreement
        confirms we are reading the field we think we are. The target is NEVER
        computed here — this only compares two things Kalshi published.

        Returns (agrees, subtitle_value). agrees is True when there is nothing
        to contradict, so a missing subtitle is not treated as a mismatch.
        """
        sub = self.raw.get("yes_sub_title") or ""
        m = re.search(r"\$\s*([\d,]+(?:\.\d+)?)", sub)
        if not m or self.floor_strike is None:
            return True, None
        try:
            shown = float(m.group(1).replace(",", ""))
        except ValueError:
            return True, None
        return abs(shown - self.floor_strike) < 0.01, shown

    def elapsed(self, now: datetime | None = None) -> float:
        return ((now or utcnow()) - self.open_time).total_seconds()

    def remaining(self, now: datetime | None = None) -> float:
        return (self.close_time - (now or utcnow())).total_seconds()

    @classmethod
    def from_api(cls, d: dict) -> "Market":
        strike = d.get("floor_strike")
        return cls(
            ticker=d["ticker"],
            event_ticker=d.get("event_ticker", ""),
            floor_strike=None if strike is None else float(strike),
            open_time=parse_iso(d["open_time"]),
            close_time=parse_iso(d["close_time"]),
            status=d.get("status", ""),
            title=d.get("title", ""),
            raw=d,
        )


class KalshiREST:
    def __init__(self, base_url: str, signer: KalshiSigner | None = None,
                 timeout: float = 15.0):
        self.base_url = base_url.rstrip("/")
        self.signer = signer
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={"accept": "application/json",
                     "user-agent": "kxbtc15m-paper-bot/0.1"},
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "KalshiREST":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    # -- plumbing -----------------------------------------------------------

    def _path_for_signing(self, endpoint: str) -> str:
        """Signature covers the full path including the /trade-api/v2 prefix."""
        prefix = self.base_url.split(".com", 1)[-1].split(".co", 1)[-1]
        if not prefix.startswith("/"):
            prefix = "/trade-api/v2"
        return prefix + endpoint

    async def get(self, endpoint: str, params: dict | None = None,
                  authed: bool = False, retries: int = 3) -> dict:
        url = self.base_url + endpoint
        headers = {}
        last_exc: Exception | None = None
        for attempt in range(retries):
            if authed and self.signer:
                headers = self.signer.headers("GET", self._path_for_signing(endpoint))
            try:
                r = await self._client.get(url, params=params, headers=headers)
                if r.status_code == 429:
                    await asyncio.sleep(1.0 * (attempt + 1))
                    continue
                r.raise_for_status()
                return r.json()
            except (httpx.HTTPError, httpx.TimeoutException) as exc:
                last_exc = exc
                if attempt == retries - 1:
                    break
                await asyncio.sleep(0.5 * (2 ** attempt))
        raise RuntimeError(f"GET {endpoint} failed after {retries} tries: {last_exc}")

    # -- market discovery ---------------------------------------------------

    async def get_market(self, ticker: str) -> Market:
        data = await self.get(f"/markets/{ticker}")
        return Market.from_api(data["market"])

    async def list_markets(self, series_ticker: str, status: str | None = None,
                           limit: int = 20) -> list[Market]:
        params: dict = {"series_ticker": series_ticker, "limit": limit}
        if status:
            params["status"] = status
        data = await self.get("/markets", params=params)
        out = []
        for m in data.get("markets", []):
            try:
                out.append(Market.from_api(m))
            except (ValueError, KeyError, TypeError) as exc:
                log.warning("skipping unparseable market %s: %s", m.get("ticker"), exc)
        return out

    async def find_window_market(self, series_ticker: str,
                                 window_open: datetime,
                                 require_target: bool = True) -> Market | None:
        """The market whose open_time matches `window_open` (within a minute).

        `status=open` is the only query that returns the live window with its
        strike filled in; `unopened` returns windows hours out, all with
        "Target price: TBD". So we ask for open first and only fall back to a
        broader search if that comes up empty.

        With `require_target`, a matching market whose strike has not been
        published yet returns None so the caller keeps polling — the strike
        appears at the open bell, sometimes a beat after the market does.
        """
        for status in ("open", None, "unopened"):
            try:
                markets = await self.list_markets(series_ticker, status=status,
                                                  limit=50)
            except RuntimeError as exc:
                log.warning("market listing failed (status=%s): %s", status, exc)
                continue
            for m in markets:
                if abs((m.open_time - window_open).total_seconds()) >= 60:
                    continue
                if require_target and not m.has_target:
                    # Right window, target not published yet. Keep waiting
                    # rather than falling through to a different window.
                    return None
                return m
        return None

    async def get_orderbook(self, ticker: str, depth: int = 100) -> dict:
        """REST book snapshot. Used to seed state before the WS snapshot lands."""
        data = await self.get(f"/markets/{ticker}/orderbook",
                              params={"depth": depth}, authed=True)
        return data.get("orderbook", {})

    async def get_balance(self) -> float:
        """Live-mode account balance in dollars. Unused in paper mode."""
        data = await self.get("/portfolio/balance", authed=True)
        return float(data.get("balance", 0)) / 100.0

    async def exchange_status(self) -> dict:
        return await self.get("/exchange/status")


def next_window_open(now: datetime | None = None, window_seconds: int = 900) -> datetime:
    """Start of the next aligned window boundary strictly after `now`."""
    now = now or utcnow()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elapsed = (now - midnight).total_seconds()
    idx = int(elapsed // window_seconds) + 1
    return midnight + timedelta(seconds=idx * window_seconds)


def current_window_open(now: datetime | None = None,
                        window_seconds: int = 900) -> datetime:
    now = now or utcnow()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elapsed = (now - midnight).total_seconds()
    return midnight + timedelta(seconds=int(elapsed // window_seconds) * window_seconds)
