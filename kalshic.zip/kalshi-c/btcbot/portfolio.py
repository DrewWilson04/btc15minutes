"""Account state, position accounting, risk limits, halt and scaling logic.

Deliberately separate from the strategy so the risk rules can be unit tested
and replayed without any market plumbing.
"""
from __future__ import annotations

import json
import logging
from collections import deque
from pathlib import Path
from dataclasses import dataclass, field

from .fees import FeeConfig, fee

log = logging.getLogger(__name__)


@dataclass
class Fill:
    timestamp: str
    side: str                 # yes | no
    price: float              # actual fill price in dollars
    intended_price: float     # what we asked for
    contracts: int
    is_maker: bool
    fee_paid: float
    time_to_fill_s: float
    order_id: str
    notional: float = 0.0

    def __post_init__(self) -> None:
        if not self.notional:
            self.notional = round(self.price * self.contracts, 6)

    def as_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "side": self.side,
            "intended_price": round(self.intended_price, 4),
            "fill_price": round(self.price, 4),
            "contracts": self.contracts,
            "liquidity": "maker" if self.is_maker else "taker",
            "fee_paid": round(self.fee_paid, 4),
            "time_to_fill_s": round(self.time_to_fill_s, 3),
            "notional": round(self.notional, 4),
            "order_id": self.order_id,
        }


@dataclass
class Lot:
    """One buy's worth of contracts, with its own cost basis.

    Kalshi contracts are fungible — there is no order type that sells "the
    ones bought at 55c". But selling the QUANTITY of a rung when that rung's
    own basis clears the goal is the same economics, so lots are an accounting
    device here, not a market one.
    """
    order_id: str
    fills: list[Fill] = field(default_factory=list)

    @property
    def contracts(self) -> int:
        return sum(f.contracts for f in self.fills)

    @property
    def cost(self) -> float:
        return round(sum(f.price * f.contracts for f in self.fills), 6)

    @property
    def fees(self) -> float:
        return round(sum(f.fee_paid for f in self.fills), 6)

    @property
    def avg_price(self) -> float:
        c = self.contracts
        return self.cost / c if c else 0.0


@dataclass
class Position:
    """Open position in one window. Averages across ladder rungs."""
    side: str
    fills: list[Fill] = field(default_factory=list)

    def lots(self) -> list[Lot]:
        """One lot per buy, in the order they were bought."""
        grouped: dict[str, list[Fill]] = {}
        for f in self.fills:
            grouped.setdefault(f.order_id, []).append(f)
        return [Lot(oid, fs) for oid, fs in grouped.items()]

    def lots_cheapest_first(self) -> list[Lot]:
        """Cheapest basis first — those clear a given % goal at the lowest bid,
        so they are the ones that become sellable soonest."""
        return sorted(self.lots(), key=lambda l: l.avg_price)

    def drop_lot(self, order_id: str) -> None:
        self.fills = [f for f in self.fills if f.order_id != order_id]

    def reduce_lot(self, order_id: str, contracts: int) -> None:
        """Take `contracts` off ONE lot, oldest fill first.

        Used when a sell fills only partly: the contracts must come off the
        rung that was actually sold, or its cost basis — which every exit
        decision reads — no longer describes what is held.
        """
        import copy
        remaining = int(contracts)
        out: list[Fill] = []
        for f in self.fills:
            if f.order_id != order_id or remaining <= 0:
                out.append(f)
                continue
            if f.contracts <= remaining:
                remaining -= f.contracts
                continue                      # this fill is fully sold
            g = copy.copy(f)
            g.contracts = f.contracts - remaining
            g.notional = round(g.price * g.contracts, 6)
            remaining = 0
            out.append(g)
        self.fills = out

    @property
    def contracts(self) -> int:
        return sum(f.contracts for f in self.fills)

    @property
    def cost(self) -> float:
        """Capital deployed, excluding fees."""
        return round(sum(f.price * f.contracts for f in self.fills), 6)

    @property
    def entry_fees(self) -> float:
        return round(sum(f.fee_paid for f in self.fills), 6)

    @property
    def avg_price(self) -> float:
        c = self.contracts
        return self.cost / c if c else 0.0

    @property
    def is_open(self) -> bool:
        return self.contracts > 0

    def add(self, fill: Fill) -> None:
        self.fills.append(fill)


@dataclass
class WindowResult:
    window_id: str
    net_pnl: float
    took_position: bool

    @property
    def is_loss(self) -> bool:
        return self.took_position and self.net_pnl < 0

    @property
    def is_win(self) -> bool:
        return self.took_position and self.net_pnl > 0


class Portfolio:
    """Balance, exposure limits, halt state, and the buy-cap ladder."""

    def __init__(self, cfg, fee_cfg: FeeConfig, starting_balance: float | None = None):
        self.cfg = cfg
        self.fee_cfg = fee_cfg
        self.balance = (starting_balance
                        if starting_balance is not None
                        else float(cfg.get("capital.paper_starting_balance_usd")))
        self.starting_balance = self.balance

        self.max_deployed_fraction = float(cfg.get("capital.max_deployed_fraction"))
        self.notional_per_buy = float(cfg.get("entry.notional_per_buy_usd"))
        self.cap_default = int(cfg.get("entry.buy_cap.default"))
        self.cap_scaled = int(cfg.get("entry.buy_cap.scaled"))
        self.wins_to_scale = int(cfg.get("scaling.wins_to_scale_up"))
        self.hard_max_notional = float(
            cfg.get("safety.absolute_max_window_notional_usd",
                    self.cap_scaled * self.notional_per_buy))

        self.size_tiers = sorted(
            (cfg.get("entry.size_tiers", []) or []),
            key=lambda t: int(t["wins"]))
        cool = cfg.get("halt.cooldown", {}) or {}
        self.cool_losses = int(cool.get("losses", 0))
        self.cool_within = int(cool.get("within_rounds", 0))
        self.cool_wait = int(cool.get("wait_rounds", 0))
        self.cooldown_remaining = 0

        self.buy_cap = self.cap_default
        self.consecutive_wins = 0
        self.consecutive_losses = 0
        self.recent: deque[WindowResult] = deque(
            maxlen=int(cfg.get("halt.rolling_window_count")))
        self.halted = False
        self.halt_reason: str | None = None
        self.results: list[WindowResult] = []

        # Lifetime tallies. These persist across restarts alongside the
        # balance, so "rounds seen" means since the last cache clear, not
        # since this process started.
        self.rounds_total = 0      # every round played through to its close
        self.rounds_traded = 0     # rounds a position was actually opened in
        self.rounds_won = 0
        self.rounds_lost = 0

        self.halt_consecutive = int(cfg.get("halt.consecutive_losses"))
        self.halt_rolling = int(cfg.get("halt.rolling_losses"))

    def refresh_limits(self) -> None:
        """Re-read the cap/scaling numbers after a profile switch.

        Streaks, balance and history are untouched — only the limits change.
        A cap that shrank is applied immediately; a cap the bot had scaled up
        to is clamped back into the new profile's range.
        """
        self.notional_per_buy = float(self.cfg.get("entry.notional_per_buy_usd"))
        self.cap_default = int(self.cfg.get("entry.buy_cap.default"))
        self.cap_scaled = int(self.cfg.get("entry.buy_cap.scaled"))
        self.wins_to_scale = int(self.cfg.get("scaling.wins_to_scale_up"))
        self.max_deployed_fraction = float(
            self.cfg.get("capital.max_deployed_fraction"))
        self.hard_max_notional = float(
            self.cfg.get("safety.absolute_max_window_notional_usd",
                         self.cap_scaled * self.notional_per_buy))
        self.halt_consecutive = int(self.cfg.get("halt.consecutive_losses"))
        self.halt_rolling = int(self.cfg.get("halt.rolling_losses"))
        self.buy_cap = max(self.cap_default, min(self.buy_cap, self.cap_scaled))

    @property
    def streak_multiplier(self) -> float:
        """Budget growth from a winning streak: +pct_per_step for every
        wins_per_step consecutive wins, capped at max_pct.

        Any losing round resets it, because consecutive_wins resets with it.
        """
        g = self.cfg.get("entry.streak_growth", {}) or {}
        step = float(g.get("pct_per_step", 0) or 0)
        per = int(g.get("wins_per_step", 0) or 0)
        cap = float(g.get("max_pct", 0) or 0)
        if step <= 0 or per <= 0:
            return 1.0
        return 1.0 + min((self.consecutive_wins // per) * step, cap)

    def stake_for_price(self, price: float) -> float:
        """Per-buy stake for a contract at `price`.

        Cheaper contracts get a bigger stake: more room to the $1.00
        settlement, and a smaller fee drag. Falls back to the flat notional
        when no price_stakes table is configured.
        """
        tiers = self.cfg.get("entry.price_stakes", []) or []
        if not tiers:
            return self.current_notional
        # The streak multiplier divides across the price bands too.
        for row in sorted(tiers, key=lambda r: float(r["up_to_price"])):
            if price <= float(row["up_to_price"]) + 1e-9:
                return round(float(row["max_stake"]) * self.streak_multiplier, 2)
        return self.current_notional

    @property
    def round_budget(self) -> float:
        """Hard cap on everything deployed in one round."""
        budget = self.cfg.get("entry.round_budget_usd", None)
        if budget is None:
            return self.buy_cap * self.current_notional
        return float(budget)

    @property
    def current_notional(self) -> float:
        """Stake per buy right now, including any streak growth.

        Optional fixed-fractional mode: a percentage of the CURRENT balance,
        so volume drifts up as the account grows and back down after a losing
        run, every round, with no cliffs and no streak counter.

        Falls back to the win-streak step ladder if a percentage is not set.
        """
        pct = self.cfg.get("entry.stake_pct_of_balance", None)
        if pct:
            stake = self.balance * float(pct)
            lo = float(self.cfg.get("entry.stake_min_usd", 0.0) or 0.0)
            hi = float(self.cfg.get("entry.stake_max_usd", 0.0) or 0.0)
            if lo:
                stake = max(stake, lo)
            if hi:
                stake = min(stake, hi)
            return round(stake, 2)

        stake = self.notional_per_buy
        for tier in self.size_tiers:
            if self.consecutive_wins >= int(tier["wins"]):
                stake = float(tier["notional"])
        return round(stake * self.streak_multiplier, 2)

    def start_round(self) -> bool:
        """Call at the start of a round. False means sit this one out."""
        if self.cooldown_remaining > 0:
            self.cooldown_remaining -= 1
            log.warning("cooling off — sitting out this round (%d more after "
                        "this)", self.cooldown_remaining)
            return False
        return True

    # -- exposure -----------------------------------------------------------

    @property
    def max_deployed(self) -> float:
        """50% of CURRENT balance — recomputed as the balance moves."""
        return self.balance * self.max_deployed_fraction

    def window_notional_cap(self) -> float:
        """Most that may be deployed in one round.

        Three limits, smallest wins: what the buys x stake ladder asks for,
        the soft operating ceiling, and the hard backstop.
        """
        caps = [self.round_budget, self.hard_max_notional]
        soft = self.cfg.get("entry.round_budget_soft_usd", None)
        if soft:
            caps.append(float(soft))
        return round(min(caps), 2)

    def can_deploy(self, amount: float, already_deployed: float) -> tuple[bool, str]:
        """Whether another `amount` of capital may be committed right now."""
        if self.halted:
            return False, "halted"
        if already_deployed + amount > self.window_notional_cap() + 1e-9:
            return False, "window_notional_cap"
        if already_deployed + amount > self.max_deployed + 1e-9:
            return False, "max_deployed_fraction"
        if amount > self.balance + 1e-9:
            return False, "insufficient_balance"
        return True, ""

    # -- settlement ---------------------------------------------------------

    def apply_window(self, window_id: str, net_pnl: float,
                     took_position: bool) -> WindowResult:
        """Book a finished window and update balance, halt and scaling state."""
        result = WindowResult(window_id, round(net_pnl, 6), took_position)
        self.balance = round(self.balance + net_pnl, 6)
        self.results.append(result)

        self.rounds_total += 1
        if took_position:
            self.rounds_traded += 1
            if result.is_win:
                self.rounds_won += 1
            elif result.is_loss:
                self.rounds_lost += 1

        if not took_position:
            # Windows with no position are not counted either way.
            return result

        self.recent.append(result)

        if result.is_loss:
            self.consecutive_losses += 1
            self.consecutive_wins = 0
            if self.buy_cap != self.cap_default:
                log.info("losing window: buy cap %d -> %d", self.buy_cap, self.cap_default)
            self.buy_cap = self.cap_default
        elif result.is_win:
            self.consecutive_wins += 1
            self.consecutive_losses = 0
            if (self.consecutive_wins >= self.wins_to_scale
                    and self.buy_cap != self.cap_scaled):
                log.info("%d consecutive wins: buy cap %d -> %d",
                         self.consecutive_wins, self.buy_cap, self.cap_scaled)
                self.buy_cap = self.cap_scaled
        else:
            # Exactly flat: not a loss, so it breaks neither streak's rules,
            # but it does not advance the win streak either.
            self.consecutive_losses = 0

        self._check_cooldown()
        self._check_halt()
        return result

    def _check_cooldown(self) -> None:
        """Two losses in a short run means sit out a few rounds."""
        if self.cool_losses <= 0 or self.cool_wait <= 0:
            return
        recent = list(self.recent)[-self.cool_within:]
        losses = sum(1 for r in recent if r.is_loss)
        if losses >= self.cool_losses and self.cooldown_remaining == 0:
            self.cooldown_remaining = self.cool_wait
            log.error("%d losses in the last %d rounds — sitting out the next "
                      "%d", losses, len(recent), self.cool_wait)

    def _check_halt(self) -> None:
        if self.halted:
            return
        if self.consecutive_losses >= self.halt_consecutive:
            self.halted = True
            self.halt_reason = (f"{self.consecutive_losses} consecutive losing windows "
                                f"(limit {self.halt_consecutive})")
        else:
            losses = sum(1 for r in self.recent if r.is_loss)
            if losses >= self.halt_rolling:
                self.halted = True
                self.halt_reason = (f"{losses} losing windows in the last "
                                    f"{len(self.recent)} (limit {self.halt_rolling} "
                                    f"in {self.recent.maxlen})")
        if self.halted:
            log.error("HALTED: %s", self.halt_reason)

    # -- persistence --------------------------------------------------------
    #
    # Streaks are the whole point of persisting: "12 straight wins raises the
    # cap" and "3 straight losses halts" mean nothing if every restart hands
    # you a fresh allowance. The JSONL logs are the permanent record; this is
    # just the live counters.

    def state_snapshot(self) -> dict:
        return {
            "version": 1,
            "balance": round(self.balance, 6),
            "starting_balance": round(self.starting_balance, 6),
            "buy_cap": self.buy_cap,
            "stake_per_buy": round(self.current_notional, 4),
            "cooldown_remaining": self.cooldown_remaining,
            "consecutive_wins": self.consecutive_wins,
            "consecutive_losses": self.consecutive_losses,
            "halted": self.halted,
            "halt_reason": self.halt_reason,
            "rounds_total": self.rounds_total,
            "rounds_traded": self.rounds_traded,
            "rounds_won": self.rounds_won,
            "rounds_lost": self.rounds_lost,
            "recent": [{"window_id": r.window_id, "net_pnl": r.net_pnl,
                        "took_position": r.took_position} for r in self.recent],
        }

    def restore(self, data: dict) -> None:
        if not data or data.get("version") != 1:
            return
        self.balance = float(data.get("balance", self.balance))
        self.starting_balance = float(
            data.get("starting_balance", self.starting_balance))
        self.buy_cap = int(data.get("buy_cap", self.buy_cap))
        self.consecutive_wins = int(data.get("consecutive_wins", 0))
        self.consecutive_losses = int(data.get("consecutive_losses", 0))
        self.halted = bool(data.get("halted", False))
        self.halt_reason = data.get("halt_reason")
        self.cooldown_remaining = int(data.get("cooldown_remaining", 0))
        self.rounds_total = int(data.get("rounds_total", 0))
        self.rounds_traded = int(data.get("rounds_traded", 0))
        self.rounds_won = int(data.get("rounds_won", 0))
        self.rounds_lost = int(data.get("rounds_lost", 0))
        self.recent.clear()
        for r in data.get("recent", []):
            self.recent.append(WindowResult(
                r.get("window_id", "?"), float(r.get("net_pnl", 0.0)),
                bool(r.get("took_position", False))))

    def save(self, path) -> None:
        p = Path(path)
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix(p.suffix + ".tmp")
            tmp.write_text(json.dumps(self.state_snapshot(), indent=1))
            tmp.replace(p)          # atomic: a crash mid-write cannot corrupt it
        except OSError as exc:
            log.warning("could not save state to %s: %s", p, exc)

    def load(self, path) -> bool:
        p = Path(path)
        if not p.exists():
            return False
        try:
            self.restore(json.loads(p.read_text()))
            return True
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            log.warning("ignoring unreadable state file %s: %s", p, exc)
            return False

    def reset(self, path=None) -> dict:
        """Clear the cached streaks and balance. Logs are left alone."""
        before = self.state_snapshot()
        self.balance = float(self.cfg.get("capital.paper_starting_balance_usd"))
        self.starting_balance = self.balance
        self.buy_cap = self.cap_default
        self.consecutive_wins = 0
        self.consecutive_losses = 0
        self.cooldown_remaining = 0
        self.recent.clear()
        self.results.clear()
        self.halted = False
        self.halt_reason = None
        self.rounds_total = 0
        self.rounds_traded = 0
        self.rounds_won = 0
        self.rounds_lost = 0
        if path:
            self.save(path)
        log.warning("state cleared: balance $%.2f, cap %d, streaks 0, halt off",
                    self.balance, self.buy_cap)
        return before

    # -- reporting ----------------------------------------------------------

    def state_dict(self) -> dict:
        return {
            "rounds_total": self.rounds_total,
            "rounds_traded": self.rounds_traded,
            "rounds_skipped": self.rounds_total - self.rounds_traded,
            "stake_per_buy": round(self.current_notional, 4),
            "cooldown_remaining": self.cooldown_remaining,
            "rounds_won": self.rounds_won,
            "rounds_lost": self.rounds_lost,
            "balance": round(self.balance, 4),
            "buy_cap": self.buy_cap,
            "consecutive_wins": self.consecutive_wins,
            "consecutive_losses": self.consecutive_losses,
            "rolling_losses": sum(1 for r in self.recent if r.is_loss),
            "rolling_count": len(self.recent),
            "halted": self.halted,
            "halt_reason": self.halt_reason,
            "max_deployed_now": round(self.max_deployed, 4),
            "window_notional_cap": round(self.window_notional_cap(), 4),
        }


def contracts_for_notional(notional: float, price: float) -> int:
    """floor(notional / price). Zero if the price makes a clip impossible."""
    if price <= 0:
        return 0
    return int(notional / price)
