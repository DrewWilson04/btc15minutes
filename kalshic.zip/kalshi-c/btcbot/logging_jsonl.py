"""Structured logging.

Three streams:
  windows.jsonl  one record per window — the measurement artifact
  events.jsonl   fine-grained events, for debugging a specific window
  tape/*.jsonl   raw book deltas and index ticks, so replay.py can re-run the
                 strategy against real recorded data

The window record is the product here. It is written even when nothing traded,
because "why no trade" is exactly what the paper run is measuring.
"""
from __future__ import annotations

import gzip
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .clock import iso, to_local

log = logging.getLogger(__name__)


def _jsonable(o: Any) -> Any:
    if isinstance(o, float):
        return round(o, 6)
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    return o


class JsonlWriter:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = self.path.open("a", encoding="utf-8")

    def write(self, record: dict) -> None:
        self._fh.write(json.dumps(_jsonable(record), separators=(",", ":")) + "\n")
        self._fh.flush()

    def close(self) -> None:
        try:
            self._fh.close()
        except Exception:  # noqa: BLE001
            pass


class TapeRecorder:
    """Raw market data for one window, so it can be replayed exactly."""

    def __init__(self, cfg_tape: dict):
        self.enabled = bool(cfg_tape.get("enabled", True))
        self.dir = Path(cfg_tape.get("dir", "./tape"))
        self.compress = bool(cfg_tape.get("compress", True))
        self._fh = None
        self.window_id: str | None = None
        self.count = 0
        # Flush periodically: gzip buffers, so an interrupted recording would
        # otherwise leave a zero-byte tape and lose the whole window.
        self.flush_every = int(cfg_tape.get("flush_every", 25))

    def start(self, window_id: str, header: dict) -> None:
        if not self.enabled:
            return
        self.close()
        self.dir.mkdir(parents=True, exist_ok=True)
        safe = window_id.replace("/", "_")
        path = self.dir / (f"{safe}.jsonl.gz" if self.compress else f"{safe}.jsonl")
        self._fh = (gzip.open(path, "wt", encoding="utf-8") if self.compress
                    else path.open("w", encoding="utf-8"))
        self.window_id = window_id
        self.count = 0
        self.record("header", header)

    def record(self, kind: str, payload: dict) -> None:
        if not self._fh:
            return
        try:
            self._fh.write(json.dumps(
                {"t": iso(), "kind": kind, "d": _jsonable(payload)},
                separators=(",", ":")) + "\n")
            self.count += 1
            if self.flush_every and self.count % self.flush_every == 0:
                self._fh.flush()
        except Exception:  # noqa: BLE001 - tape must never break trading
            log.debug("tape write failed", exc_info=True)

    def close(self) -> None:
        if self._fh:
            try:
                self._fh.close()
            except Exception:  # noqa: BLE001
                pass
        self._fh = None


@dataclass
class WindowRecord:
    """Everything the summary tool needs about one window."""
    window_id: str
    ticker: str = ""
    open_time: str = ""
    close_time: str = ""
    target_price: float | None = None

    # trigger
    trigger_fired: bool = False
    trigger_elapsed_s: float | None = None
    trigger_time: str | None = None        # wall clock of the touch (UTC ISO)
    trigger_btc_price: float | None = None
    trigger_distance: float | None = None
    direction: str | None = None          # up | down
    side: str | None = None               # yes | no

    # adverse-move brake
    adverse_move_fired: bool = False
    adverse_move_elapsed_s: float | None = None
    adverse_move_btc: float | None = None
    adverse_move_distance: float | None = None

    # why nothing happened
    no_entry_reason: str | None = None
    no_trigger_reason: str | None = None

    # feed health
    feed_source: str = ""
    feed_tick_count: int = 0
    feed_calibration_error: float | None = None   # our tick vs floor_strike at open
    feed_cross_check_divergence: float | None = None
    ws_reconnects: int = 0

    # activity
    buys: list[dict] = field(default_factory=list)
    unfilled_orders: list[dict] = field(default_factory=list)
    exits: list[dict] = field(default_factory=list)

    # how close it came to selling — the answer to "why didn't it sell?"
    best_bid_seen: float | None = None        # best bid while holding
    best_net_return: float | None = None      # best net return reached
    best_net_elapsed_s: float | None = None   # when that was
    best_net_needed: float | None = None      # the goal in force at that moment

    # BTC and the contract price 5s before the buy, at the buy, and 5s after.
    snapshots: dict = field(default_factory=dict)

    held_to_settle: bool = False           # rode a winning position to expiry
    held_to_settle_from_s: float | None = None
    hold_broken: bool = False
    thin_margin_fired: bool = False
    free_roll_kept: int = 0                # contracts actually left riding
    free_roll_target: int = 0              # what the fraction/cap asked for              # margin failed, went back to selling

    # outcome
    cycles: int = 0                 # entry/exit round trips within this round
    contracts_held: int = 0
    contracts_sold: int = 0
    avg_buy_price: float | None = None    # average cost per contract
    avg_sell_price: float | None = None   # average sale price per contract
    avg_spread: float | None = None       # sell - buy, before fees
    capital_deployed: float = 0.0
    entry_fees: float = 0.0
    exit_fees: float = 0.0
    gross_pnl: float = 0.0
    net_pnl: float = 0.0
    net_return: float | None = None
    exit_reason: str | None = None
    settled_by_expiry: bool = False

    # account state after this window
    balance_after: float = 0.0
    buy_cap: int = 0            # cap this window actually ran under
    buy_cap_after: int = 0      # cap for the NEXT window, after this result
    consecutive_wins: int = 0
    consecutive_losses: int = 0
    halted: bool = False
    halt_reason: str | None = None

    notes: list[str] = field(default_factory=list)

    def note(self, msg: str) -> None:
        self.notes.append(msg)

    def as_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items()}
        d["schema"] = 1
        d["logged_at"] = iso()
        return d


class TradeLog:
    """A plain-text ledger of every fill, one line each, in the order they
    happen.

    Separate from events.jsonl on purpose: that file is for debugging and is
    unreadable by eye, while this answers "what did it actually buy and sell,
    and when" without any tooling.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = self.path.open("a", encoding="utf-8")
        if self._fh.tell() == 0:
            self._fh.write(
                "# date       clock     round   window                    "
                "action  qty side  price   value    fee     detail\n")
            self._fh.flush()

    def fill(self, *, when, elapsed_s, window_id, action, contracts, side,
             price, value, fee, detail="") -> None:
        try:
            sec = int(elapsed_s or 0)
            rc = f"+{sec // 60}:{sec % 60:02d}"
            d = to_local(when)
            stamp = d.strftime("%Y-%m-%d %H:%M:%S") if d else "?"
            self._fh.write(
                f"{stamp}  {rc:>6}   {window_id:<24}  "
                f"{action:<6}  {contracts:>3} {str(side).upper():<4} "
                f"{price:6.3f}  {value:7.2f}  {fee:5.2f}   {detail}\n")
            self._fh.flush()      # a crash must not cost the ledger
        except Exception:  # noqa: BLE001 - logging must never break trading
            log.debug("trade log write failed", exc_info=True)

    def close(self) -> None:
        try:
            self._fh.close()
        except Exception:  # noqa: BLE001
            pass

class Logger:
    def __init__(self, cfg):
        self.windows = JsonlWriter(cfg.get("logging.window_log_path"))
        self.events = JsonlWriter(cfg.get("logging.event_log_path",
                                          "./logs/events.jsonl"))
        self.tape = TapeRecorder(cfg.get("logging.tape", {}))
        self.trades = TradeLog(cfg.get("logging.trade_log_path",
                                       "./logs/trades.log"))

    def window(self, record: WindowRecord) -> None:
        self.windows.write(record.as_dict())

    def event(self, kind: str, **fields) -> None:
        self.events.write({"t": iso(), "kind": kind, **fields})

    def close(self) -> None:
        self.windows.close()
        self.events.close()
        self.tape.close()
        self.trades.close()


def setup_console_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)-18s %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("websockets").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
