"""Live terminal dashboard.

Renders in place with ANSI escapes rather than curses, so the same frame can be
captured to a file, diffed, or piped somewhere. Runs in the bot's process and
reads live objects directly — the book, the feed, the portfolio, the window in
flight — so what you see is the state the strategy is acting on, not a log tail
lagging behind it.

Console logging is redirected into the LOG pane while this is active; writing
to stdout underneath a full-screen redraw would tear the frame.
"""
from __future__ import annotations

import logging
import os
import shutil
from collections import deque
from datetime import datetime

from .clock import local_hms, tz_abbrev, utcnow

# -- palette ----------------------------------------------------------------
RESET = "\033[22;39m"   # normal intensity + default fg, KEEPS the background
HARD_RESET = "\033[0m"  # full reset, used only when tearing the screen down
BOLD = "\033[1m"
DIM = "\033[38;5;240m"

# Dark theme. Backgrounds are painted explicitly so the dashboard looks the
# same on a light terminal as on a dark one.
BG_DARK = "\033[48;5;234m"
BG_NONE = ""

AMBER = "\033[38;5;214m"
ORANGE = "\033[38;5;208m"
GREEN = "\033[38;5;41m"
RED = "\033[38;5;203m"
CYAN = "\033[38;5;80m"
GREY = "\033[38;5;246m"
WHITE = "\033[38;5;255m"
BLUE = "\033[38;5;75m"
YELLOW = "\033[38;5;227m"
MAGENTA = "\033[38;5;176m"

HIDE_CURSOR = "\033[?25l"
SHOW_CURSOR = "\033[?25h"
CLEAR = "\033[2J"
HOME = "\033[H"


def _vis_len(s: str) -> int:
    """Length ignoring ANSI escapes, so padding lines up."""
    out, i, n = 0, 0, len(s)
    while i < n:
        if s[i] == "\033":
            i += 1
            if i < n and s[i] == "[":
                i += 1
                while i < n and not ("@" <= s[i] <= "~"):
                    i += 1
                i += 1
            continue
        out += 1
        i += 1
    return out


class LogPane(logging.Handler):
    """Captures log records for the LOG panel instead of the screen."""

    LEVEL_COLOR = {
        "DEBUG": GREY, "INFO": GREY, "WARNING": YELLOW,
        "ERROR": RED, "CRITICAL": RED,
    }

    def __init__(self, maxlen: int = 9):
        super().__init__()
        self.lines: deque[tuple[str, str, str]] = deque(maxlen=maxlen)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
            self.lines.append((ts, record.levelname, record.getMessage()))
        except Exception:  # noqa: BLE001 - logging must never raise
            pass


class BotState:
    """Everything the dashboard reads. Held by the runner, mutated in place."""

    def __init__(self, cfg, portfolio, book, feed, mode: str = "PAPER"):
        self.cfg = cfg
        self.portfolio = portfolio
        self.book = book
        self.feed = feed
        self.mode = mode
        self.market = None          # current Market being TRADED
        self.trader = None          # current WindowTrader
        # The live window while we are NOT trading it (started mid-window, or
        # waiting for the next boundary). Display only — never traded.
        self.observed_market = None
        self.next_open = None       # datetime of the next boundary
        self.recent: deque = deque(maxlen=8)
        self.started = utcnow()
        self.windows_done = 0
        self.ws_market = False
        self.ws_index = False
        self.note = ""


class Dashboard:
    def __init__(self, state: BotState, log_pane: LogPane | None = None,
                 width: int | None = None, theme: str = "dark"):
        self.state = state
        self.log_pane = log_pane
        self.theme = theme
        self.bg = BG_DARK if theme == "dark" else BG_NONE
        self.width = width or min(shutil.get_terminal_size((100, 40)).columns, 104)
        self.width = max(self.width, 76)
        self._started = False

    # -- chrome -------------------------------------------------------------

    def _rule(self, label: str = "", color: str = AMBER) -> str:
        inner = self.width - 2
        if not label:
            return f"{color}{'─' * inner}{RESET}"
        text = f" {label} "
        pad = inner - len(text)
        return f"{color}──{text}{'─' * max(0, pad - 2)}{RESET}"

    def _row(self, left: str, right: str = "") -> str:
        space = self.width - _vis_len(left) - _vis_len(right)
        return left + " " * max(1, space) + right

    @staticmethod
    def _mmss(seconds: float) -> str:
        if seconds is None:
            return "--:--"
        neg = seconds < 0
        seconds = abs(int(seconds))
        return f"{'-' if neg else ''}{seconds // 60:02d}:{seconds % 60:02d}"

    @staticmethod
    def _money(v: float | None, width: int = 0, sign: bool = False) -> str:
        if v is None:
            return "—".rjust(width)
        s = f"{'+' if sign and v > 0 else ''}${v:,.2f}" if v >= 0 else f"-${abs(v):,.2f}"
        return s.rjust(width) if width else s

    @staticmethod
    def _pct(v: float | None, sign: bool = True) -> str:
        if v is None:
            return "—"
        return f"{'+' if sign and v > 0 else ''}{v * 100:.2f}%"

    # -- panels -------------------------------------------------------------

    def _header(self) -> list[str]:
        s = self.state
        mode_col = RED if s.mode == "LIVE" else GREEN
        up = (utcnow() - s.started).total_seconds()
        links = []
        for name, ok in (("MKT", s.ws_market), ("IDX", s.ws_index)):
            links.append(f"{GREEN if ok else RED}{'●' if ok else '○'}{GREY}{name}{RESET}")
        return [
            self._row(
                f"{BOLD}{AMBER}KXBTC15M{RESET} {GREY}│{RESET} "
                f"{mode_col}{BOLD}{s.mode}{RESET} {GREY}│{RESET} "
                f"{' '.join(links)}",
                f"{GREY}up {self._mmss(up)}  {local_hms(utcnow())} "
                f"{tz_abbrev()}{RESET}",
            ),
        ]

    def _feed_panel(self) -> list[str]:
        """Always visible, window or no window: proof the index is live."""
        s = self.state
        st = s.feed.state
        price = s.feed.price
        age = None
        if st.last is not None:
            from .clock import monotonic
            age = monotonic() - st.last.received_at
        stale_after = float(s.cfg.get(
            "price_feed.kalshi_index.stale_tick_seconds", 5.0))
        if price is None:
            dot, acol, atxt = f"{RED}○{RESET}", GREY, "no ticks yet"
        elif age is not None and age > stale_after:
            dot, acol, atxt = f"{YELLOW}◐{RESET}", YELLOW, f"STALE {age:.1f}s"
        else:
            dot, acol, atxt = f"{GREEN}●{RESET}", GREY, f"{age:.1f}s ago"
        return [self._row(
            f"  {dot} {GREY}BRTI{RESET} {BOLD}{WHITE}"
            f"{(f'{price:,.2f}' if price else '—'):>12}{RESET}   "
            f"{GREY}last tick{RESET} {acol}{atxt}{RESET}",
            f"{GREY}{st.tick_count:,} ticks{RESET}")]

    def _window_panel(self) -> list[str]:
        s = self.state
        m, t = s.market, s.trader
        out = [self._rule("WINDOW")]
        if m is None:
            obs = s.observed_market
            countdown = ""
            if s.next_open is not None:
                secs = (s.next_open - utcnow()).total_seconds()
                countdown = (f"{GREY}next window in{RESET} {AMBER}{BOLD}"
                             f"{self._mmss(secs)}{RESET} "
                             f"{GREY}({s.next_open.strftime('%H:%M')}Z){RESET}")
            if obs is not None and obs.has_target:
                btc = s.feed.price
                d = (btc - obs.target) if btc else None
                dcol = GREY if d is None else (GREEN if d > 0 else RED)
                out.append(self._row(
                    f"  {GREY}observing{RESET} {DIM}{obs.ticker}{RESET}  "
                    f"{GREY}TARGET{RESET} {WHITE}{obs.target:>12,.2f}{RESET}  "
                    f"{GREY}Δ{RESET} {dcol}"
                    f"{(f'{d:+,.2f}' if d is not None else '—'):>9}{RESET}",
                    countdown))
                gate = float(s.cfg.get("trigger.max_elapsed_seconds"))
                out.append(f"  {DIM}not trading this one — the ±$"
                           f"{s.cfg.get('trigger.distance_usd')} trigger only counts "
                           f"in a window's first {self._mmss(gate)}{RESET}")
            else:
                out.append(self._row(
                    f"  {GREY}waiting for the next window to open…{RESET}",
                    countdown))
            return out

        remaining = t.remaining() if t else m.remaining()
        elapsed = t.elapsed() if t else m.elapsed()
        # Colour the clock by which exit regime is active.
        clock_col = GREEN if remaining > 240 else YELLOW if remaining > 60 else RED
        gate = float(s.cfg.get("trigger.max_elapsed_seconds"))
        phase = ("PRE-OPEN" if elapsed < 0 else
                 "TRIGGER WINDOW" if elapsed <= gate else "LOCKED-OUT")
        clock_txt = (f"{GREY}T-{RESET}{clock_col}{BOLD}{self._mmss(remaining)}{RESET}"
                     if remaining >= 0 else f"{RED}{BOLD}CLOSED{RESET}")
        out.append(self._row(
            f"  {CYAN}{m.ticker}{RESET}",
            f"{clock_txt}"
            f"  {GREY}elapsed{RESET} {self._mmss(max(0, elapsed))}  "
            f"{DIM}{phase}{RESET}"))

        btc = s.feed.price
        target = m.target
        dist = (btc - target) if btc else None
        dcol = GREY if dist is None else (GREEN if dist > 0 else RED)
        arrow = "" if dist is None else ("▲" if dist > 0 else "▼")
        thresh = float(s.cfg.get("trigger.distance_usd"))
        armed = dist is not None and abs(dist) >= thresh
        out.append(self._row(
            f"  {GREY}TARGET{RESET} {WHITE}{target:>12,.2f}{RESET}   "
            f"{GREY}BTC{RESET} {BOLD}{WHITE}"
            f"{(f'{btc:,.2f}' if btc else '—'):>12}{RESET}   "
            f"{GREY}Δ{RESET} {dcol}{BOLD}"
            f"{(f'{dist:+,.2f}' if dist is not None else '—'):>10} {arrow}{RESET}",
            f"{GREY}trip ±{thresh}{RESET} "
            f"{(GREEN + '◆ IN RANGE') if armed else (GREY + '◇ waiting')}{RESET}"))
        return out

    def _trigger_panel(self) -> list[str]:
        s, t = self.state, self.state.trader
        out = [self._rule("TRIGGER")]
        if t is None:
            out.append(f"  {GREY}—{RESET}")
            return out
        r = t.record
        if r.trigger_fired:
            side_col = GREEN if r.direction == "up" else RED
            out.append(self._row(
                f"  {side_col}{BOLD}▶ {r.direction.upper():<5}{RESET} "
                f"{GREY}({r.side.upper()}){RESET}  "
                f"{GREY}locked{RESET} {WHITE}{local_hms(r.trigger_time)}{RESET} "
                f"{GREY}{tz_abbrev()}{RESET} {DIM}(+{r.trigger_elapsed_s:.2f}s){RESET}  "
                f"{GREY}BTC{RESET} {r.trigger_btc_price:,.2f}  "
                f"{GREY}Δ{RESET} {r.trigger_distance:+.2f}",
                f"{DIM}direction is final for this window{RESET}"))
        if r.trigger_fired and r.adverse_move_fired:
            out.append(self._row(
                f"  {RED}{BOLD}■ ADVERSE MOVE{RESET} {GREY}BTC{RESET} "
                f"{r.adverse_move_btc:,.2f} {GREY}is{RESET} "
                f"{RED}{r.adverse_move_distance:+.2f}{RESET} {GREY}vs target "
                f"at +{r.adverse_move_elapsed_s:.0f}s{RESET}",
                f"{YELLOW}no more buys · exit bar → breakeven{RESET}"))
        if not r.trigger_fired and r.no_trigger_reason:
            out.append(f"  {YELLOW}✕ no trigger{RESET}  {GREY}{r.no_trigger_reason}{RESET}")
        elif not r.trigger_fired:
            peak = t._peak_distance() if t.feed.state.history else 0.0
            out.append(self._row(
                f"  {GREY}armed, watching…{RESET}",
                f"{GREY}peak |Δ| this window{RESET} {WHITE}{peak:,.2f}{RESET}"))
        return out

    def _book_panel(self) -> list[str]:
        s = self.state
        b = s.book
        out = [self._rule("BOOK")]
        if not b.is_ready():
            out.append(f"  {GREY}no book{RESET}")
            return out

        locked = s.trader.locked_side if s.trader else None
        cells = []
        for side, label in (("yes", "UP  /YES"), ("no", "DOWN/NO ")):
            bid, ask = b.bid(side), b.ask(side)
            mark = f"{AMBER}▸{RESET}" if locked == side else " "
            col = WHITE if locked == side else GREY
            cells.append(
                f"{mark}{col}{label}{RESET} "
                f"{GREY}bid{RESET} {GREEN}{bid:.2f}{RESET} "
                f"{GREY}ask{RESET} {RED}{ask:.2f}{RESET}")
        spread = b.spread("yes")
        out.append(self._row("  " + "     ".join(cells),
                             f"{GREY}spread{RESET} "
                             f"{(f'{spread * 100:.1f}¢' if spread is not None else '—')}"))

        # Entry band, drawn against the price we would actually pay.
        if locked:
            ref = s.cfg.get("entry.band_reference", "ask")
            price = b.quote(locked, ref)
            rung = (s.trader.buys_done or 0) + 1
            lo, hi = s.trader._band_for_rung(rung)
            inband = price is not None and lo <= price <= hi
            allowed, why = s.trader._buying_allowed()
            out.append(self._row(
                f"  {GREY}buy {rung} band{RESET} {lo:.2f}–{hi:.2f}  "
                f"{GREY}{ref}{RESET} "
                f"{(GREEN if inband else GREY)}{BOLD}"
                f"{(f'{price:.2f}' if price else '—')}{RESET}",
                (f"{RED}■ buys stopped: {why}{RESET}" if not allowed
                 else f"{GREEN}● IN BAND{RESET}" if inband
                 else f"{GREY}○ outside band{RESET}")))
        return out

    def _position_panel(self) -> list[str]:
        s, t = self.state, self.state.trader
        out = [self._rule("POSITION")]
        pos = t.position if t else None
        if not pos or not pos.is_open:
            filled = len(t.record.buys) if t else 0
            out.append(self._row(
                f"  {GREY}flat{RESET}",
                f"{GREY}buys filled {filled}/{s.portfolio.buy_cap}{RESET}"))
            return out

        from .fees import net_return_on_exit
        bid = s.book.bid(pos.side)
        net_ret = None
        if bid is not None:
            net_ret, _f, _p = net_return_on_exit(
                pos.cost, pos.entry_fees, bid, pos.contracts, False, t.fee_cfg)
        rcol = GREEN if (net_ret or 0) >= 0 else RED
        out.append(self._row(
            f"  {WHITE}{BOLD}{pos.side.upper():<4}{RESET} "
            f"{WHITE}{pos.contracts:>3}{RESET} {GREY}@{RESET} {pos.avg_price:.3f}   "
            f"{GREY}cost{RESET} {self._money(pos.cost)}  "
            f"{GREY}fees{RESET} {self._money(pos.entry_fees)}",
            f"{GREY}rungs{RESET} {t.buys_done}/{s.portfolio.buy_cap}"))

        rule = t._active_rule(t.remaining())
        need = rule.min_net_return
        gap = None if net_ret is None else net_ret - need
        out.append(self._row(
            f"  {GREY}mark{RESET} {GREEN}{(f'{bid:.2f}' if bid else '—')}{RESET}   "
            f"{GREY}net{RESET} {rcol}{BOLD}{self._pct(net_ret):>8}{RESET}   "
            f"{GREY}need{RESET} {YELLOW}{self._pct(need, sign=False):>7}{RESET} "
            f"{DIM}({rule.name}){RESET}",
            (f"{GREEN}▲ SELLING{RESET}" if gap is not None and gap >= 0
             else f"{GREY}{self._pct(gap)} to target{RESET}"
             if gap is not None else "")))
        return out

    def _activity_panel(self) -> list[str]:
        """Per-event blotter for the window in flight: the trigger, every buy
        with what it cost, and every exit with what it made."""
        s = self.state
        t = s.trader
        out = [self._rule("ACTIVITY")]
        if t is None:
            out.append(f"  {GREY}—{RESET}")
            return out
        r = t.record
        rows: list[str] = []

        if r.trigger_fired:
            dcol = GREEN if r.direction == "up" else RED
            rows.append(
                f"  {GREY}{(r.buys[0]['timestamp'][11:19] if False else '')}{RESET}"
                f"{AMBER}TRIG {RESET}{dcol}{BOLD}{r.direction.upper():<5}{RESET}"
                f"{GREY}@{RESET}+{r.trigger_elapsed_s:>6.2f}s  "
                f"{GREY}BTC{RESET} {r.trigger_btc_price:>10,.2f}  "
                f"{GREY}Δ{RESET} {dcol}{r.trigger_distance:>+7.2f}{RESET}  "
                f"{DIM}target {r.target_price:,.2f}{RESET}")

        for b in r.buys:
            fills = b.get("fills") or []
            if not fills:
                continue
            qty = sum(f["contracts"] for f in fills)
            cost = sum(f["fill_price"] * f["contracts"] for f in fills)
            fees = sum(f["fee_paid"] for f in fills)
            liq = fills[0].get("liquidity", "?")
            lcol = BLUE if liq == "maker" else MAGENTA
            rows.append(
                f"  {DIM}{b.get('timestamp','')[11:19]}{RESET} "
                f"{GREEN}BUY {b.get('rung','?')}{RESET} "
                f"{WHITE}{qty:>3}{RESET}{GREY}c @{RESET} {b.get('avg_fill_price', 0):.3f}  "
                f"{GREY}cost{RESET} {self._money(cost, 6)}  "
                f"{GREY}fee{RESET} {self._money(fees, 5)}  "
                f"{lcol}{liq}{RESET}")

        for o in r.unfilled_orders:
            if o.get("kind") == "abandoned_limit":
                rows.append(
                    f"  {DIM}{o.get('timestamp','')[11:19]}{RESET} "
                    f"{YELLOW}CXL {o.get('rung','?')}{RESET} "
                    f"{GREY}limit {o.get('posted_price') or 0:.3f} unfilled after "
                    f"{o.get('rested_s', 0):.1f}s → crossed{RESET}")

        for e in r.exits:
            pnl = e.get("realized_net_pnl")
            pctv = e.get("realized_net_pct")
            col = GREEN if (pnl or 0) >= 0 else RED
            if e.get("reason") == "expired_settled":
                rows.append(
                    f"  {DIM}{e.get('timestamp','')[11:19]}{RESET} "
                    f"{col}SETL{RESET} {WHITE}{e.get('contracts', 0):>3}{RESET}"
                    f"{GREY}c settled{RESET} {e.get('settle_value', 0):.0f}  "
                    f"{col}{self._money(pnl, 7, sign=True)}{RESET} "
                    f"{col}{self._pct(pctv):>8}{RESET}")
            else:
                rows.append(
                    f"  {DIM}{e.get('timestamp','')[11:19]}{RESET} "
                    f"{RED}SELL{RESET} {WHITE}{e.get('filled_contracts', 0):>3}{RESET}"
                    f"{GREY}c @{RESET} {(e.get('avg_fill_price') or 0):.3f}  "
                    f"{GREY}bid{RESET} {(e.get('bid_at_decision') or 0):.3f}  "
                    f"{col}{self._money(pnl, 7, sign=True)}{RESET} "
                    f"{col}{self._pct(pctv):>8}{RESET}  {DIM}{e.get('reason','')}{RESET}")

        if not rows:
            peak = t._peak_distance() if t.feed.state.history else 0.0
            trip = float(s.cfg.get("trigger.distance_usd"))
            out.append(self._row(
                f"  {GREY}watching for ±{trip} …{RESET}",
                f"{GREY}closest so far{RESET} {WHITE}{peak:,.2f}{RESET}"
                f"{GREY} / {trip}{RESET}"))
        else:
            out.extend(rows[-7:])
        return out

    def _account_panel(self) -> list[str]:
        s = self.state
        p = s.portfolio
        deployed = 0.0
        if s.trader and s.trader.position:
            deployed = s.trader.position.cost
        pnl = p.balance - p.starting_balance
        pcol = GREEN if pnl >= 0 else RED
        out = [self._rule("ACCOUNT")]
        out.append(self._row(
            f"  {GREY}BALANCE{RESET} {BOLD}{WHITE}{self._money(p.balance)}{RESET} "
            f"{pcol}({self._money(pnl, sign=True)}){RESET}   "
            f"{GREY}CAP{RESET} {WHITE}{p.buy_cap}{RESET}   "
            f"{GREY}W{RESET}{GREEN}{p.consecutive_wins}{RESET} "
            f"{GREY}L{RESET}{RED}{p.consecutive_losses}{RESET}",
            f"{GREY}deployed{RESET} {self._money(deployed)}"
            f"{GREY}/{self._money(p.max_deployed)}{RESET}"))
        if p.halted:
            out.append(f"  {RED}{BOLD}■ HALTED{RESET} {RED}{p.halt_reason}{RESET}")
        return out

    def _history_panel(self) -> list[str]:
        s = self.state
        out = [self._rule("RECENT WINDOWS")]
        if not s.recent:
            out.append(f"  {GREY}none yet{RESET}")
            return out
        for r in list(s.recent)[-6:]:
            if r.capital_deployed:
                col = GREEN if r.net_pnl > 0 else RED if r.net_pnl < 0 else GREY
                mark = "▲" if r.net_pnl > 0 else "▼" if r.net_pnl < 0 else "="
                detail = (f"{r.direction or '—':<4} "
                          f"{r.contracts_held:>3}c  "
                          f"{self._money(r.capital_deployed):>7} → "
                          f"{col}{self._money(r.net_pnl, sign=True):>7} "
                          f"{self._pct(r.net_return):>8}{RESET}  "
                          f"{DIM}{(r.exit_reason or '')[:22]}{RESET}")
            else:
                col, mark = GREY, "·"
                detail = f"{GREY}no position — {(r.no_entry_reason or '')[:40]}{RESET}"
            out.append(f"  {col}{mark}{RESET} {GREY}{r.window_id[-13:]:<13}{RESET} {detail}")
        return out

    def _log_panel(self) -> list[str]:
        out = [self._rule("LOG")]
        if not self.log_pane or not self.log_pane.lines:
            out.append(f"  {GREY}—{RESET}")
            return out
        for ts, level, msg in list(self.log_pane.lines):
            col = LogPane.LEVEL_COLOR.get(level, GREY)
            room = self.width - 12
            out.append(f"  {DIM}{ts}{RESET} {col}{msg[:room]}{RESET}")
        return out

    # -- driver -------------------------------------------------------------

    def frame(self) -> str:
        panels = (self._header() + self._feed_panel() + self._window_panel() + self._trigger_panel()
                  + self._book_panel() + self._position_panel()
                  + self._activity_panel() + self._account_panel()
                  + self._history_panel() + self._log_panel() + [self._rule()])
        # Every line starts by re-asserting the background, then \033[K fills
        # to end-of-line WITH that background — which is what makes the theme
        # cover the full width instead of only the printed characters.
        body = "\n".join(self.bg + line + "\033[K" for line in panels)
        return body + "\n" + self.bg + "\033[J"

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        print(HIDE_CURSOR + self.bg + CLEAR, end="", flush=True)

    def render(self) -> None:
        self.start()
        print(HOME + self.frame(), end="", flush=True)

    def stop(self) -> None:
        if not self._started:
            return
        self._started = False
        print(HARD_RESET + SHOW_CURSOR, flush=True)


def attach_log_pane(maxlen: int = 9, keep_console: bool = False) -> LogPane:
    """Capture logging for the dashboard.

    With the terminal dashboard, console handlers must go: anything printed
    underneath a full-screen redraw tears the frame. With only the web
    dashboard there is no frame to protect, so the console stays — otherwise
    startup errors vanish into a pane nobody can see yet.
    """
    pane = LogPane(maxlen)
    root = logging.getLogger()
    if not keep_console:
        for h in list(root.handlers):
            root.removeHandler(h)
    elif not root.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-7s %(name)-18s %(message)s", "%H:%M:%S"))
        root.addHandler(h)
    root.addHandler(pane)
    root.setLevel(logging.INFO)
    logging.getLogger("websockets").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    return pane


def strip_ansi(s: str) -> str:
    """Remove ANSI escapes. Handles all CSI finals (\033[K, \033[J, \033[H),
    not just SGR — stripping only on 'm' would swallow the rest of the line."""
    out, i, n = [], 0, len(s)
    while i < n:
        if s[i] == "\033":
            i += 1
            if i < n and s[i] == "[":
                i += 1
                while i < n and not ("@" <= s[i] <= "~"):
                    i += 1
                i += 1
            continue
        out.append(s[i])
        i += 1
    return "".join(out)
