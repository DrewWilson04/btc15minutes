"""Clock abstraction so the strategy can run on wall time or on tape time.

The strategy's rules are all keyed to elapsed/remaining seconds. If it reads
the wall clock directly it can only ever run live, and a recorded window would
appear to have expired before the tape starts playing. Injecting the clock is
what makes replay.py exercise the real logic instead of an approximation of it.
"""
from __future__ import annotations

import asyncio
import heapq
import itertools
from datetime import datetime, timedelta

from .clock import monotonic, utcnow


class Clock:
    def now(self) -> datetime:
        raise NotImplementedError

    def time(self) -> float:
        """Monotonic-ish seconds, for durations."""
        raise NotImplementedError

    async def sleep(self, seconds: float) -> None:
        raise NotImplementedError


class RealClock(Clock):
    def now(self) -> datetime:
        return utcnow()

    def time(self) -> float:
        return monotonic()

    async def sleep(self, seconds: float) -> None:
        await asyncio.sleep(seconds)


class VirtualClock(Clock):
    """Time advances only when the tape pump says so.

    Sleepers register a wake deadline and are released as virtual time passes
    them, so a 5-second ladder cooldown costs 5 seconds of tape, not 5 seconds
    of the operator's life.
    """

    def __init__(self, start: datetime):
        self._now = start
        self._t = 0.0
        self._waiters: list[tuple[float, int, asyncio.Future]] = []
        self._counter = itertools.count()

    def now(self) -> datetime:
        return self._now

    def time(self) -> float:
        return self._t

    async def sleep(self, seconds: float) -> None:
        if seconds <= 0:
            await asyncio.sleep(0)
            return
        fut = asyncio.get_running_loop().create_future()
        heapq.heappush(self._waiters,
                       (self._t + seconds, next(self._counter), fut))
        await fut

    def advance_to(self, ts: datetime) -> None:
        delta = (ts - self._now).total_seconds()
        if delta <= 0:
            return
        self._now = ts
        self._t += delta
        self._release()

    def _release(self) -> None:
        while self._waiters and self._waiters[0][0] <= self._t:
            _, _, fut = heapq.heappop(self._waiters)
            if not fut.done():
                fut.set_result(None)

    def release_all(self) -> None:
        """Wake everything — used when the tape ends.

        Time must jump to the last pending deadline, not merely release the
        futures: a loop of the form `while clock.time() < deadline: sleep()`
        would otherwise be woken forever without its condition ever becoming
        true, which turns tape exhaustion into a spin.
        """
        if self._waiters:
            self._t = max(self._t, max(w[0] for w in self._waiters))
        while self._waiters:
            _, _, fut = heapq.heappop(self._waiters)
            if not fut.done():
                fut.set_result(None)

    @property
    def pending_sleepers(self) -> int:
        return len(self._waiters)
