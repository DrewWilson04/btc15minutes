"""The window state machine: trigger, entry ladder, exit ladder.

One WindowTrader owns exactly one 15-minute window. It is deliberately
ignorant of transport: it is handed a Book that something else keeps current,
a PriceFeed it subscribes to, and an Executor that may be paper or live. That
is what lets replay.py run this same class against recorded data.

Timing rules are all keyed to time remaining, measured against the market's own
close_time rather than a local timer, so a slow start or a reconnect cannot
drift the schedule.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

from .clock import iso
from .execution import Executor, OrderResult
from .feeds import PriceFeed, Tick
from .fees import FeeConfig, fee, net_return_on_exit
from .logging_jsonl import Logger, WindowRecord
from .orderbook import Book, Side, side_for_direction
from .portfolio import Portfolio, Position, contracts_for_notional
from .rest import Market
from .vclock import Clock, RealClock

log = logging.getLogger(__name__)


@dataclass
class ExitRule:
    name: str
    time_remaining_under: float | None
    min_net_return: float


def load_exit_rules(cfg) -> list[ExitRule]:
    rules = [ExitRule(r["name"], r.get("time_remaining_under"),
                      float(r["min_net_return"]))
             for r in cfg.get("exit.thresholds")]
    # Tightest time condition first, so "under 1:00" wins over "under 4:00"
    # regardless of how they were ordered in the file.
    rules.sort(key=lambda r: (r.time_remaining_under is None,
                              r.time_remaining_under or 0))
    return rules


class WindowTrader:
    def __init__(self, cfg, market: Market, book: Book, feed: PriceFeed,
                 executor: Executor, portfolio: Portfolio, fee_cfg: FeeConfig,
                 logger: Logger, cross_check_feed: PriceFeed | None = None,
                 clock: Clock | None = None):
        self.cfg = cfg
        self.clock = clock or RealClock()
        self.market = market
        self.book = book
        self.feed = feed
        self.cross_feed = cross_check_feed
        self.executor = executor
        self.portfolio = portfolio
        self.fee_cfg = fee_cfg
        self.logger = logger

        # --- tunables, all from config ---
        self.trigger_distance = float(cfg.get("trigger.distance_usd"))
        self.trigger_max_elapsed = float(cfg.get("trigger.max_elapsed_seconds"))
        # Optional: after the touch, wait this long and require the price to
        # still be on the same side of target before committing any money.
        # A flip during the wait means the touch was noise, and the round is
        # abandoned rather than traded in the direction that already failed.
        self.confirm_after = float(cfg.get("trigger.confirm_after_seconds", 0.0) or 0.0)
        # Stake comes from the portfolio so a win streak raises it and a loss
        # resets it, without the strategy holding a stale copy.
        self.notional = portfolio.current_notional
        self.band_ref = cfg.get("entry.band_reference", "ask")
        self.rungs = list(cfg.get("entry.rungs"))
        self.cooldown = float(cfg.get("entry.cooldown_seconds"))
        self.no_buy_after = float(cfg.get("entry.no_buy_after_elapsed_seconds"))
        self.allow_reentry = bool(cfg.get("entry.allow_reentry", False))
        self.max_cycles = int(cfg.get("entry.max_cycles_per_round", 1))
        self.adverse_distance = float(cfg.get("exit.adverse_move.distance_usd"))
        self.adverse_after = float(cfg.get(
            "exit.adverse_move.after_elapsed_seconds", 0.0))
        self.adverse_min_return = float(cfg.get("exit.adverse_move.min_net_return"))
        self.adverse_stops_buys = bool(cfg.get("exit.adverse_move.stop_further_buys"))
        self.sell_by_lot = bool(cfg.get("exit.sell_by_lot", False))
        sweep = cfg.get("exit.lot_sweep", {}) or {}
        self.sweep_enabled = bool(sweep.get("enabled", False))
        self.sweep_within_price = float(sweep.get("within_price", 0.0))
        self.sweep_within_return = float(sweep.get("within_return_fraction", 0.0))
        self.sweep_min_net = float(sweep.get("min_net_return", 0.0001))
        dear = cfg.get("exit.sell_all_when_dearest", {}) or {}
        self.dearest_enabled = bool(dear.get("enabled", False))
        self.dearest_min_net = float(dear.get("min_net_return", 0.05))
        self.dearest_min_lots = int(dear.get("min_lots", 2))
        blend = cfg.get("exit.sell_all_blended", {}) or {}
        self.blended_enabled = bool(blend.get("enabled", False))
        self.blended_min_net = float(blend.get("min_net_return", 0.085))
        hold = cfg.get("exit.hold_if_winning", {}) or {}
        self.hold_enabled = bool(hold.get("enabled", False))
        self.hold_under = float(hold.get("time_remaining_under", 0.0))
        self.hold_margin = float(hold.get("min_margin_usd", 0.0))
        self.hold_thin_price = float(hold.get("thin_margin_side_price", 0.0))
        self.hold_thin_get_out = float(hold.get("thin_margin_get_out_under", 0.0))
        self.thin_keep_fraction = float(hold.get("thin_margin_keep_fraction", 0.0))
        self.thin_keep_max_cost = float(hold.get("thin_margin_keep_max_cost", 0.0))
        self._free_roll_target: int | None = None
        self.order_mode = cfg.get("execution.order_type")
        self.limit_timeout = float(cfg.get("execution.limit_timeout_seconds"))
        self.exit_rules = load_exit_rules(cfg)
        self.forced_time = float(cfg.get("exit.forced_exit.time_remaining_under"))
        self.forced_distance = float(cfg.get("exit.forced_exit.distance_usd"))
        self.feed_stale = float(cfg.get("price_feed.kalshi_index.stale_tick_seconds", 5.0))

        # --- per-window state ---
        if market.floor_strike is None:
            # A window can only be traded against a target Kalshi published.
            # There is no fallback and there must never be one: inventing a
            # target would silently change what every rule in here means.
            raise ValueError(
                f"refusing to trade {market.ticker}: Kalshi has not published "
                f"floor_strike for this window")
        self.window_id = market.ticker
        self.record = WindowRecord(
            window_id=self.window_id,
            ticker=market.ticker,
            open_time=iso(market.open_time),
            close_time=iso(market.close_time),
            target_price=market.target,
            feed_source=feed.name,
            buy_cap=portfolio.buy_cap,
        )
        self.locked_side: Side | None = None
        self.locked_direction: str | None = None
        self.position: Position | None = None
        self.buys_done = 0       # rungs in the CURRENT position
        self.total_buys = 0      # buys across the whole round — this is what
                                 # the buy cap limits. Selling is unrestricted,
                                 # so a round can run buy/sell/buy/sell/buy/buy
                                 # /sell/sell and still be 4 buys.
        self.cycle = 0
        self.exited = False
        # Totals across every cycle in the round; the per-cycle Position is
        # reset each time it is closed out.
        self.total_cost = 0.0
        self.total_entry_fees = 0.0
        self.total_contracts = 0
        self.adverse_fired = False
        # High-water mark of net return while holding, so a round that never
        # sold can report how close it came and against which goal.
        self.best_net_seen: float | None = None
        self.exit_fees_paid = 0.0
        self._trigger_event = asyncio.Event()
        self._trigger_tick: Tick | None = None
        self._done = False

    # -- clock --------------------------------------------------------------

    def _now_iso(self) -> str:
        """Timestamps come from the injected clock, so a replayed round is
        stamped with the time it happened rather than the time it was replayed."""
        return iso(self.clock.now())

    def elapsed(self) -> float:
        return (self.clock.now() - self.market.open_time).total_seconds()

    def remaining(self) -> float:
        return (self.market.close_time - self.clock.now()).total_seconds()

    # -- trigger ------------------------------------------------------------

    def _on_tick(self, tick: Tick) -> None:
        """Runs on every index tick. Cheap by design: a fleeting touch of the
        threshold must not be missed between polls."""
        if self._done:
            return
        if self.locked_side is not None:
            # Direction is already final; the only thing left to watch for is
            # the move going badly wrong.
            self._check_adverse(tick)
            return
        elapsed = self.elapsed()
        if elapsed < 0:
            return
        if elapsed > self.trigger_max_elapsed:
            return
        distance = tick.price - self.market.target
        if abs(distance) < self.trigger_distance:
            return

        # Lock. Direction is final for the window from here on.
        self.locked_direction = "up" if distance > 0 else "down"
        self.locked_side = side_for_direction(self.locked_direction)
        self._trigger_tick = tick
        self.record.trigger_fired = True
        self.record.trigger_elapsed_s = round(elapsed, 3)
        self.record.trigger_time = tick.wall_time
        self.record.trigger_btc_price = tick.price
        self.record.trigger_distance = round(distance, 4)
        self.record.direction = self.locked_direction
        self.record.side = self.locked_side
        self._trigger_event.set()
        log.info("TRIGGER %s at +%.3fs: BTC %.2f vs target %.2f (%+.2f) -> %s",
                 self.window_id, elapsed, tick.price, self.market.target,
                 distance, self.locked_direction.upper())
        self.logger.event("trigger", window=self.window_id,
                          elapsed_s=round(elapsed, 3), btc=tick.price,
                          target=self.market.target, distance=round(distance, 4),
                          direction=self.locked_direction)

    def _check_adverse(self, tick: Tick) -> None:
        """Has BTC crossed to the wrong side of the target by adverse_distance?

        Measured as signed distance from the target, not from the entry price:
        the target is the line that decides the payout, so being $50 the wrong
        side of it is what actually breaks the thesis.
        """
        if self.adverse_fired or self.adverse_distance <= 0:
            return
        if self.elapsed() < self.adverse_after:
            # Dormant early in the round: a big swing against us is not yet a
            # reason to give up on the profit target.
            return
        signed = tick.price - self.market.target
        broken = (signed <= -self.adverse_distance
                  if self.locked_direction == "up"
                  else signed >= self.adverse_distance)
        if not broken:
            return
        self.adverse_fired = True
        self.record.adverse_move_fired = True
        self.record.adverse_move_elapsed_s = round(self.elapsed(), 3)
        self.record.adverse_move_btc = tick.price
        self.record.adverse_move_distance = round(signed, 4)
        log.warning("ADVERSE MOVE %s: BTC %.2f is %+.2f vs target while %s — "
                    "exit bar drops to breakeven",
                    self.window_id, tick.price, signed,
                    (self.locked_direction or "?").upper())
        self.logger.event("adverse_move", window=self.window_id,
                          btc=tick.price, distance=round(signed, 4),
                          direction=self.locked_direction,
                          elapsed_s=round(self.elapsed(), 3))

    async def _await_trigger(self) -> bool:
        """Wait for a lock until the trigger deadline passes.

        The lock itself is set synchronously in _on_tick, so a touch of the
        threshold cannot be missed between polls; this loop only decides when
        to give up.
        """
        while not self._trigger_event.is_set():
            if self.elapsed() > self.trigger_max_elapsed:
                return False
            if self.remaining() <= 0:
                return False
            if self._done:
                return False
            await self.clock.sleep(0.05)
        return True

    # -- entry --------------------------------------------------------------

    def _band_for_rung(self, rung: int) -> tuple[float, float]:
        """(min_price, max_price) for this rung of the CURRENT position.

        Rung numbering restarts with each new position, because the ceilings
        describe what you will pay for the first, second, … clip of exposure —
        and after a sell you are building exposure from scratch. The total
        number of buys is what the round-level cap limits.
        """
        for row in self.rungs:
            up_to = row.get("up_to")
            if up_to is None or rung <= int(up_to):
                return float(row["min_price"]), float(row["max_price"])
        last = self.rungs[-1]
        return float(last["min_price"]), float(last["max_price"])

    def _round_buy_gates(self) -> tuple[bool, str]:
        """Round-level gates on buying, independent of the current position.

        The buy cap is counted over the whole round, not per position: with a
        cap of 4 the round gets 4 buys however they are arranged around sells.

        Kept separate from _buying_allowed because re-entry needs to ask "may
        this ROUND still buy?" without being told "no, the position you just
        closed is closed".
        """
        if self._done:
            return False, "round_over"
        if self.total_buys >= self.portfolio.buy_cap:
            return False, "buy_cap_reached"
        if self.adverse_fired and self.adverse_stops_buys:
            return False, "adverse_move"
        if self.elapsed() >= self.no_buy_after:
            return False, "past_buy_cutoff"
        if self.remaining() <= self.forced_time:
            return False, "too_close_to_close"
        return True, ""

    def _buying_allowed(self) -> tuple[bool, str]:
        """Whether another rung may be attempted right now, this cycle."""
        ok, why = self._round_buy_gates()
        if not ok:
            return ok, why
        if self.exited:
            return False, "position_closed"
        return True, ""

    def _band_price(self) -> float | None:
        if self.locked_side is None:
            return None
        return self.book.quote(self.locked_side, self.band_ref)

    def _deployed(self) -> float:
        return self.position.cost if self.position else 0.0

    async def _try_buy(self, rung: int) -> tuple[bool, str]:
        """One rung of the ladder. Returns (bought, reason_if_not)."""
        lo, hi = self._band_for_rung(rung)
        price = self._band_price()
        if price is None:
            return False, "no_book"
        if not (lo <= price <= hi):
            return False, "outside_band"

        # Stake comes from the price band, then is trimmed to whatever is
        # left of the round budget.
        stake = self.portfolio.stake_for_price(price)
        left = self.portfolio.window_notional_cap() - self._deployed()
        stake = min(stake, left)
        if stake < price:
            return False, "round_budget_spent"
        contracts = contracts_for_notional(stake, price)
        if contracts <= 0:
            return False, "price_too_high_for_clip"

        cost_estimate = price * contracts
        ok, why = self.portfolio.can_deploy(cost_estimate, self._deployed())
        if not ok:
            self.record.note(f"buy_{rung}_blocked:{why}")
            return False, why

        # `hi` is the rung's price ceiling. It is passed down as a hard fill
        # limit as well, so a thin touch cannot fill the rest of the clip at a
        # price the rule already rejected.
        result = await self.executor.buy(self.book, self.locked_side, contracts,
                                         self.order_mode, self.limit_timeout,
                                         max_price=hi)
        self._record_order(result, rung, price)

        if not result.filled or result.filled_contracts == 0:
            return False, result.reason

        if self.position is None:
            self.position = Position(side=self.locked_side)
        for f in result.fills:
            self.position.add(f)
            self.total_cost += f.price * f.contracts
            self.total_entry_fees += f.fee_paid
            self.total_contracts += f.contracts
        self.buys_done += 1
        self.total_buys += 1
        log.info("BUY %d/%d %s %d @ %.3f (%s) fee %.3f",
                 self.total_buys, self.portfolio.buy_cap, self.locked_side,
                 result.filled_contracts, result.avg_price,
                 "maker" if result.fills[0].is_maker else "taker",
                 result.total_fees)
        return True, ""

    def _record_order(self, result: OrderResult, rung: int, intended: float) -> None:
        entry = result.as_dict()
        entry.update({"rung": rung, "cycle": self.cycle,
                      "intended_price": round(intended, 4),
                      "timestamp": self._now_iso(),
                      "elapsed_s": round(self.elapsed(), 3),
                      "book": self.book.snapshot_dict()})
        if result.filled and result.filled_contracts:
            self.record.buys.append(entry)
            fills = result.fills or []
            liq = ("maker" if fills and fills[0].is_maker else "taker")
            self.logger.trades.fill(
                when=self.clock.now(), elapsed_s=self.elapsed(),
                window_id=self.window_id, action="BUY",
                contracts=result.filled_contracts,
                side=str(self.locked_direction or self.locked_side or ""),
                price=result.avg_price,
                value=result.avg_price * result.filled_contracts,
                fee=result.total_fees,
                detail=f"clip {rung} of {self.portfolio.buy_cap}, {liq}")
            if result.limit_attempt:
                # The fill was a taker cross; the limit that was given up on
                # is its own log line, since the maker/taker split turns on it.
                self.record.unfilled_orders.append({
                    "order_id": result.order_id, "rung": rung,
                    "timestamp": self._now_iso(), "kind": "abandoned_limit",
                    "cancelled": True, **result.limit_attempt})
        else:
            self.record.unfilled_orders.append(entry)
        self.logger.event("order", window=self.window_id, **entry)

    async def _run_ladder(self) -> None:
        """Work the ladder: rung 1 in its own band, then rung by rung.

        Each rung has its own price ceiling (see entry.rungs), and the whole
        ladder stops early if the adverse-move brake trips or the buy cutoff
        passes. Selling is unaffected by any of that — this only gates buying.
        """
        got_first = False
        while True:
            allowed, why = self._buying_allowed()
            if not allowed:
                if not self.record.no_entry_reason:
                    self.record.no_entry_reason = why
                break
            ok, reason = await self._try_buy(1)
            if ok:
                got_first = True
                break
            if reason in ("halted", "max_deployed_fraction", "window_notional_cap"):
                self.record.no_entry_reason = reason
                return
            await self.clock.sleep(0.1)

        if not got_first:
            if not self.record.no_entry_reason:
                self.record.no_entry_reason = "price_never_entered_band"
            return

        while self.total_buys < self.portfolio.buy_cap:
            await self.clock.sleep(self.cooldown)
            allowed, why = self._buying_allowed()
            if not allowed:
                self.record.note(f"ladder_stopped:{why}")
                break
            ok, reason = await self._try_buy(self.buys_done + 1)
            if not ok and reason in ("halted", "max_deployed_fraction",
                                     "window_notional_cap"):
                self.record.note(f"ladder_stopped:{reason}")
                break

    # -- exit ---------------------------------------------------------------

    def _active_rule(self, remaining: float) -> ExitRule:
        for rule in self.exit_rules:
            if rule.time_remaining_under is None:
                continue
            if remaining < rule.time_remaining_under:
                return rule
        return next(r for r in self.exit_rules if r.time_remaining_under is None)

    def winning_margin(self) -> float | None:
        """How far BTC is on OUR side of the target, in dollars.

        Positive means the position is currently in the money; negative means
        it is not. None when there is no price to judge by.
        """
        price = self.feed.price
        if price is None or self.locked_direction is None:
            return None
        signed = price - self.market.target
        return signed if self.locked_direction == "up" else -signed

    def _hold_decision(self, remaining: float) -> tuple[str, str]:
        """What to do with a winning position in the closing minutes.

        Returns one of:
          "none"      — normal exit ladder applies
          "all"       — hold to settlement; a winning contract pays $1.00,
                        which beats any bid and skips the exit fee
          "breakeven" — precarious: aim for flat, and in the last seconds
                        take whatever the book gives

        The precarious case is a THIN margin (BTC barely on our side) while
        the book also prices our side cheaply — both saying it is a coin flip.
        Settlement then pays $1.00 or nothing, which is not worth riding, so
        this pulls the breakeven bar forward rather than waiting for the
        normal ladder to reach it.
        """
        if not self.hold_enabled or remaining > self.hold_under:
            return "none", ""
        margin = self.winning_margin()
        if margin is None:
            return "none", "no_price"
        if margin <= 0:
            return "none", "wrong_side"
        if margin > self.hold_margin:
            return "all", f"winning_by_{margin:.2f}"

        side_price = (self.book.bid(self.position.side)
                      if self.position is not None else None)
        if (self.hold_thin_price > 0 and side_price is not None
                and side_price < self.hold_thin_price):
            return "breakeven", (f"thin_margin_{margin:.2f}_side_at_"
                                 f"{side_price:.3f}")
        return "none", "margin_too_thin"

    async def _thin_margin_free_roll(self, bid: float, remaining: float) -> bool:
        """Final seconds of a coin flip: sell most, keep a slice to settle.

        Contracts are fungible, so which ones we keep is arbitrary — lots are
        sold most-expensive-first purely to keep the bookkeeping clean.

        Returns True while it is still working (caller should loop again),
        False when there is nothing left to sell and the remainder should just
        ride to settlement.
        """
        if self.position is None or self.thin_keep_fraction <= 0:
            return False
        held = self.position.contracts

        # Latch the target on the first pass. Recomputing it from the
        # shrinking position halves the slice again on every pass, so a 50%
        # roll would quietly end up at 25%, then 12%.
        if self._free_roll_target is None:
            keep = int(held * self.thin_keep_fraction)
            if self.thin_keep_max_cost > 0 and keep > 0:
                avg = self.position.avg_price or 1.0
                keep = min(keep, int(self.thin_keep_max_cost / avg))
            self._free_roll_target = max(0, keep)
        keep = self._free_roll_target
        if keep <= 0 or keep >= held:
            return False

        dear = [l for l in self.position.lots_cheapest_first()][::-1]
        for lot in dear:
            if self.position.contracts - lot.contracts < keep:
                continue
            lot_net, _f, _p = net_return_on_exit(
                lot.cost, lot.fees, bid, lot.contracts, False, self.fee_cfg)
            log.info("FREE ROLL %s: selling rung @%.3f, keeping ~%d contracts "
                     "to settle (%.0fs left)", self.window_id, lot.avg_price,
                     keep, remaining)
            await self._exit_now("thin_margin_partial", bid, lot_net, lot=lot)
            # Record what is actually left riding, not the target — lots are
            # whole, so the slice usually overshoots the target upward.
            self.record.free_roll_kept = (self.position.contracts
                                          if self.position else 0)
            self.record.free_roll_target = keep
            return True

        # Nothing more can be sold without dipping under the slice: let it ride.
        if not self.record.free_roll_kept:
            self.record.free_roll_kept = self.position.contracts
            self.record.free_roll_target = keep
            log.info("FREE ROLL %s: holding %d contracts to settlement",
                     self.window_id, self.position.contracts)
            self.logger.event("free_roll", window=self.window_id,
                              contracts=self.position.contracts,
                              remaining_s=round(remaining, 2))
        return False

    def _forced(self, remaining: float) -> bool:
        if remaining > self.forced_time:
            return False
        price = self.feed.price
        if price is None:
            return True     # no feed this late: get out regardless
        return abs(price - self.market.target) > self.forced_distance

    async def _monitor_exit(self) -> None:
        """Watch the live bid against the active threshold for ONE cycle.

        Returns as soon as the position is closed; run() decides whether
        another cycle starts.
        """
        while not self._done and not self.exited:
            remaining = self.remaining()
            if remaining <= 0:
                break
            if self.position is None or not self.position.is_open:
                await self.clock.sleep(0.05)
                continue

            bid = self.book.bid(self.position.side)
            if bid is None:
                await self.clock.sleep(0.05)
                continue

            contracts = self.position.contracts
            net_ret, _exit_fee, _pnl = net_return_on_exit(
                self.position.cost, self.position.entry_fees,
                bid, contracts, False, self.fee_cfg)

            # Track the high-water mark so a round that never sold can say
            # how close it got, and against which goal.
            if self.best_net_seen is None or net_ret > self.best_net_seen:
                self.best_net_seen = net_ret
                self.record.best_net_return = round(net_ret, 6)
                self.record.best_bid_seen = round(bid, 4)
                self.record.best_net_elapsed_s = round(self.elapsed(), 2)
                self.record.best_net_needed = self._active_rule(remaining).min_net_return

            # A clearly winning position is worth more at settlement than at
            # any bid, so this outranks every run-out rule below it.
            hold_mode, why = self._hold_decision(remaining)

            if hold_mode == "all":
                if not self.record.held_to_settle:
                    self.record.held_to_settle = True
                    self.record.held_to_settle_from_s = round(self.elapsed(), 2)
                    log.info("HOLDING %s to settlement: %s (%.0fs left) — "
                             "settles at $1.00, better than the %.3f bid",
                             self.window_id, why, remaining, bid)
                    self.logger.event("hold_to_settle", window=self.window_id,
                                      reason=why, remaining_s=round(remaining, 2),
                                      bid=bid)
                await self.clock.sleep(0.05)
                continue

            if self.record.held_to_settle and not self.record.hold_broken:
                self.record.hold_broken = True
                self.record.note(f"hold_broken:{why or 'unknown'}")
                log.warning("hold broken on %s (%s) — back to the exit rules",
                            self.window_id, why)

            forced = self._forced(remaining)
            rule = self._active_rule(remaining)
            need, need_name = rule.min_net_return, rule.name

            if hold_mode == "breakeven":
                # Coin flip: aim for flat now rather than waiting for the
                # ladder, and take anything at all in the final seconds.
                if remaining <= self.hold_thin_get_out:
                    if await self._thin_margin_free_roll(bid, remaining):
                        continue
                    need, need_name = -10.0, "thin_margin_get_out"
                elif need > 0.0:
                    need, need_name = 0.0, "thin_margin_breakeven"
                if not self.record.thin_margin_fired:
                    self.record.thin_margin_fired = True
                    log.info("THIN MARGIN %s: %s — aiming for breakeven "
                             "(%.0fs left)", self.window_id, why, remaining)
                    self.logger.event("thin_margin", window=self.window_id,
                                      reason=why, remaining_s=round(remaining, 2))

            if self.adverse_fired and self.adverse_min_return < need:
                # The thesis is broken: take breakeven rather than hold out for
                # the profit target. A time rule that is LOWER still wins,
                # because late in the window getting out matters more.
                need, need_name = self.adverse_min_return, "adverse_move_breakeven"

            if forced and not (hold_mode == "breakeven"
                               and self.record.free_roll_kept):
                # Bailouts and the final get-out always clear the whole
                # position; there is no time left to work it rung by rung.
                await self._exit_now("forced_exit_near_close", bid, net_ret)
                return
            if hold_mode == "breakeven" and self.record.free_roll_kept:
                await self.clock.sleep(0.05)
                continue

            # If the DEAREST rung is up enough, every cheaper rung is up more
            # — clear the whole position in one go rather than trickling out.
            if (self.dearest_enabled and self.position is not None
                    and not self.exited):
                lots = self.position.lots()
                if len(lots) >= self.dearest_min_lots:
                    dearest = max(lots, key=lambda l: l.avg_price)
                    d_net, _f, _p = net_return_on_exit(
                        dearest.cost, dearest.fees, bid, dearest.contracts,
                        False, self.fee_cfg)
                    if d_net >= self.dearest_min_net:
                        log.info("DEAREST RUNG @%.3f is up %+.2f%% — selling "
                                 "the whole position (%d contracts)",
                                 dearest.avg_price, d_net * 100,
                                 self.position.contracts)
                        await self._exit_now("dearest_rung_in_profit", bid,
                                             net_ret)
                        if self.exited:
                            return
                        continue

            if self.sell_by_lot and need > -1.0:
                # Cheapest basis first: those clear the goal at the lowest bid,
                # so they become sellable soonest. One lot per tick, then
                # re-price — the bid may have moved after taking liquidity.
                sold_any = False
                for lot in self.position.lots_cheapest_first():
                    lot_net, _f, _p = net_return_on_exit(
                        lot.cost, lot.fees, bid, lot.contracts, False,
                        self.fee_cfg)
                    if lot_net >= need:
                        await self._exit_now(need_name, bid, lot_net, lot=lot)
                        sold_any = True
                        if self.sweep_enabled and not self.exited:
                            await self._sweep_near_lots(lot, need, need_name)
                        break
                if self.exited:
                    return
                if sold_any:
                    continue
            elif net_ret >= need:
                # Sell at the going price, not at a limit pegged to the
                # threshold — if the bid gapped past it, we capture the gap.
                await self._exit_now(need_name, bid, net_ret)
                return

            # Last resort, checked after everything else has passed: the
            # position as a whole is up enough, so clear it.
            if (self.blended_enabled and self.position is not None
                    and not self.exited and net_ret >= self.blended_min_net):
                log.info("BLENDED %+.2f%% on the whole position — clearing it",
                         net_ret * 100)
                await self._exit_now("blended_position_profit", bid, net_ret)
                if self.exited:
                    return

            await self.clock.sleep(0.05)

        # Round ended with the position still on: it settles at expiry.
        if self.position and self.position.is_open and not self.exited:
            await self._settle_at_expiry()

    async def _sweep_near_lots(self, trigger, need: float, need_name: str) -> None:
        """Sell the rungs sitting just behind one that just hit its goal.

        A rung qualifies if it is CLOSE to the one that triggered — bought
        within `within_price`, or already within `within_return_fraction`
        (relative) of the goal — AND is genuinely in profit on its own basis.

        The profit floor is absolute. A losing rung is never sold because a
        different rung was green; those exit on the time ladder instead. That
        matters most in the "any profit" band, where the goal sits at ~0 and a
        naive sweep would reach into losses.

        The bid is re-read before each sale, because taking liquidity moves it.
        """
        if self.position is None:
            return
        for lot in list(self.position.lots_cheapest_first()):
            if lot.order_id == trigger.order_id:
                continue
            bid = self.book.bid(self.position.side)
            if bid is None:
                return
            lot_net, _f, _p = net_return_on_exit(
                lot.cost, lot.fees, bid, lot.contracts, False, self.fee_cfg)

            if lot_net < self.sweep_min_net:
                continue                       # not in profit — leave it
            if lot_net >= need:
                continue                       # clears on its own next tick

            close_by_price = (self.sweep_within_price > 0 and
                              abs(lot.avg_price - trigger.avg_price)
                              <= self.sweep_within_price + 1e-9)
            close_by_return = (self.sweep_within_return > 0 and need > 0 and
                               lot_net >= need * (1.0 - self.sweep_within_return))
            if not (close_by_price or close_by_return):
                continue

            log.info("SWEEP %s: rung @%.3f at %+.2f%% rides along with the "
                     "rung @%.3f", self.window_id, lot.avg_price, lot_net * 100,
                     trigger.avg_price)
            await self._exit_now(f"{need_name}_sweep", bid, lot_net, lot=lot)
            if self.exited:
                return

    async def _exit_now(self, reason: str, bid_at_decision: float,
                        net_ret_at_decision: float, lot=None) -> None:
        """Sell the whole position, or just one lot's worth of contracts."""
        if self.exited or self.position is None:
            return
        contracts = lot.contracts if lot is not None else self.position.contracts
        basis_cost = lot.cost if lot is not None else self.position.cost
        basis_fees = lot.fees if lot is not None else self.position.entry_fees
        result = await self.executor.sell(self.book, self.position.side, contracts)
        entry = result.as_dict()
        entry.update({
            "timestamp": self._now_iso(),
            "reason": reason,
            "cycle": self.cycle,
            "lot": (None if lot is None else
                    {"order_id": lot.order_id, "contracts": lot.contracts,
                     "avg_price": round(lot.avg_price, 4)}),
            "elapsed_s": round(self.elapsed(), 3),
            "remaining_s": round(self.remaining(), 3),
            "bid_at_decision": round(bid_at_decision, 4),
            "net_return_at_decision": round(net_ret_at_decision, 6),
            "book": self.book.snapshot_dict(),
        })

        if not result.filled or result.filled_contracts == 0:
            entry["note"] = "exit_order_did_not_fill"
            self.record.exits.append(entry)
            self.logger.event("exit_failed", window=self.window_id, **entry)
            return

        self.exit_fees_paid += result.total_fees
        proceeds = result.total_cost
        realized = proceeds - result.total_fees - basis_cost - basis_fees
        entry["realized_net_pnl"] = round(realized, 6)
        entry["realized_net_pct"] = (round(realized / basis_cost, 6)
                                     if basis_cost else None)
        # What these particular contracts cost, and what they fetched.
        sold = result.filled_contracts
        entry["avg_buy_price"] = (round(basis_cost / contracts, 4)
                                  if contracts else None)
        entry["avg_sell_price"] = round(result.avg_price, 4) if sold else None
        entry["gross_spread"] = (round(result.avg_price - basis_cost / contracts, 4)
                                 if sold and contracts else None)
        entry["basis_cost"] = round(basis_cost, 4)
        entry["basis_entry_fees"] = round(basis_fees, 4)
        self.record.exits.append(entry)
        self.logger.trades.fill(
            when=self.clock.now(), elapsed_s=self.elapsed(),
            window_id=self.window_id, action="SELL", contracts=sold,
            side=str(self.locked_direction or self.position.side or ""),
            price=result.avg_price, value=proceeds, fee=result.total_fees,
            detail=f"{realized / basis_cost * 100:+.2f}% net"
                   if basis_cost else "")
        self.logger.event("exit", window=self.window_id, **entry)
        log.info("EXIT %s%s: %d @ %.3f (bid %.3f) net %+.2f%% -> $%+.3f",
                 reason,
                 f" [lot @{lot.avg_price:.3f}]" if lot is not None else "",
                 result.filled_contracts, result.avg_price,
                 bid_at_decision, (entry["realized_net_pct"] or 0) * 100, realized)

        if lot is not None and result.filled_contracts >= contracts:
            # That rung is out; the rest of the position keeps working.
            self.position.drop_lot(lot.order_id)
            self.record.exit_reason = reason
            if not self.position.is_open:
                self.exited = True
                self.position = None
        elif lot is None and result.filled_contracts >= self.position.contracts:
            self.exited = True
            self.record.exit_reason = reason
            # Do NOT end the round here: with re-entry enabled the ladder may
            # get another turn. run() decides whether the round continues.
            self.position = None
        else:
            # Partial exit: keep working the remainder rather than assuming out.
            self.record.note(f"partial_exit:{result.filled_contracts}"
                             f"_of_{contracts}")
            if lot is not None:
                # Take the contracts off the rung that was actually sold, so
                # its cost basis still describes what is left of it.
                self.position.reduce_lot(lot.order_id, result.filled_contracts)
            else:
                remaining = self.position.contracts - result.filled_contracts
                self.position.fills = _shrink_fills(self.position.fills, remaining)
            if not self.position.is_open:
                self.exited = True
                self.position = None

    async def _settle_at_expiry(self) -> None:
        """No exit found before close: the contract settles 0 or 1."""
        price = self.feed.price
        if price is None:
            self.record.note("expiry_without_feed_price")
            won = None
        else:
            above = price >= self.market.target
            won = (above if self.position.side == "yes" else not above)

        contracts = self.position.contracts
        settle_value = (1.0 if won else 0.0) if won is not None else 0.0
        proceeds = settle_value * contracts
        realized = proceeds - self.position.cost - self.position.entry_fees
        self.exited = True
        self.record.exit_reason = "expired_settled"
        self.record.settled_by_expiry = True
        entry = {
            "timestamp": self._now_iso(),
            "reason": "expired_settled",
            "elapsed_s": round(self.elapsed(), 3),
            "remaining_s": round(self.remaining(), 3),
            "cycle": self.cycle,
            "settle_value": settle_value,
            "contracts": contracts,
            "filled_contracts": contracts,
            "avg_fill_price": settle_value,
            "btc_at_expiry": price,
            "target": self.market.target,
            "won": won,
            "fees": 0.0,   # settlement is not charged an exit fee
            "realized_net_pnl": round(realized, 6),
            "realized_net_pct": (round(realized / self.position.cost, 6)
                                 if self.position.cost else None),
            "avg_buy_price": (round(self.position.cost / contracts, 4)
                              if contracts else None),
            "avg_sell_price": settle_value,
            "gross_spread": (round(settle_value - self.position.cost / contracts, 4)
                             if contracts else None),
            "basis_cost": round(self.position.cost, 4),
            "basis_entry_fees": round(self.position.entry_fees, 4),
        }
        self.record.exits.append(entry)
        self.logger.trades.fill(
            when=self.clock.now(), elapsed_s=self.elapsed(),
            window_id=self.window_id, action="SETTLE", contracts=contracts,
            side=str(self.locked_direction or self.position.side or ""),
            price=settle_value, value=proceeds, fee=0.0,
            detail=f"expired {'WON' if won else 'LOST'}, "
                   f"{realized / self.position.cost * 100:+.2f}% net"
                   if self.position.cost else "expired")
        self.logger.event("expiry", window=self.window_id, **entry)
        log.info("EXPIRY %s settled %s: $%+.3f", self.window_id,
                 "WON" if won else "LOST", realized)

    async def _confirm_direction(self) -> bool:
        """Hold fire for `confirm_after` seconds, then re-check the side.

        The touch says which way to bet; this asks whether it is still true a
        moment later. A price back on the other side of target means the move
        did not hold, and the round is skipped entirely — no position is opened
        in either direction.
        """
        target = self.clock.time() + self.confirm_after
        while self.clock.time() < target:
            if self.remaining() <= 0:
                self.record.no_entry_reason = "window_closed_during_confirm"
                return False
            await self.clock.sleep(0.1)

        px = self.feed.price
        if px is None:
            self.record.no_entry_reason = "no_price_at_confirm"
            self.record.note("confirm:no_price")
            log.info("%s: no price at confirm — skipping", self.window_id)
            return False

        still = "up" if px > self.market.target else "down"
        distance = px - self.market.target
        held = (still == self.locked_direction)
        self.record.note(
            f"confirm@{self.confirm_after:.0f}s:{'held' if held else 'flipped'}"
            f":{distance:+.2f}")
        self.logger.event("trigger_confirm", window=self.window_id,
                          elapsed_s=round(self.elapsed(), 3),
                          direction=self.locked_direction, still=still,
                          btc=px, distance=round(distance, 4), held=held)
        if not held:
            self.record.no_entry_reason = "direction_flipped_during_confirm"
            log.info("%s: %s trigger flipped to %s after %.0fs — skipping round",
                     self.window_id, self.locked_direction, still,
                     self.confirm_after)
            return False
        log.info("%s: %s confirmed after %.0fs (BTC %+.2f vs target)",
                 self.window_id, self.locked_direction, self.confirm_after,
                 distance)
        return True

    # -- orchestration ------------------------------------------------------

    async def run(self) -> WindowRecord:
        self.feed.subscribe(self._on_tick)
        self.logger.tape.start(self.window_id, {
            "ticker": self.market.ticker,
            "target": self.market.target,
            "open_time": iso(self.market.open_time),
            "close_time": iso(self.market.close_time),
            "config_digest": {
                "trigger_distance": self.trigger_distance,
                "order_mode": self.order_mode,
                "buy_cap": self.portfolio.buy_cap,
            },
        })

        self._calibrate_feed()

        if self.portfolio.halted:
            self.record.no_trigger_reason = "halted"
            self.record.no_entry_reason = "halted"
            return self._finish(took_position=False, net_pnl=0.0)

        triggered = await self._await_trigger()
        if not triggered:
            self.record.no_trigger_reason = self._explain_no_trigger()
            self.record.no_entry_reason = self.record.no_trigger_reason
            log.info("no trigger for %s (%s)", self.window_id,
                     self.record.no_trigger_reason)
            return self._finish(took_position=False, net_pnl=0.0)

        if self.confirm_after > 0 and not await self._confirm_direction():
            return self._finish(took_position=False, net_pnl=0.0)

        # One cycle = build a position, then close it. With re-entry enabled
        # the round can run several: sell into a spike, wait, buy the next dip.
        while True:
            self.cycle += 1
            self.exited = False
            self.position = None
            self.buys_done = 0

            ladder = asyncio.create_task(self._run_ladder())
            monitor = asyncio.create_task(self._monitor_exit())
            try:
                await asyncio.wait([ladder, monitor],
                                   return_when=asyncio.FIRST_EXCEPTION)
            finally:
                for t in (ladder, monitor):
                    if not t.done():
                        t.cancel()
                results = await asyncio.gather(ladder, monitor,
                                               return_exceptions=True)
                # Never swallow these. A crashed ladder used to look exactly
                # like a round that simply stopped buying, and the round would
                # quietly fall through to settlement with one clip on.
                for name, res in zip(("ladder", "exit-monitor"), results):
                    if isinstance(res, asyncio.CancelledError):
                        continue
                    if isinstance(res, BaseException):
                        log.error("%s task crashed in round %s: %r",
                                  name, self.window_id, res, exc_info=res)
                        self.record.note(f"{name}_crashed:{type(res).__name__}")
                        self.logger.event("task_crash", window=self.window_id,
                                          task=name, error=repr(res))

            self.record.cycles = self.cycle

            if not self._can_start_another_cycle():
                break
            log.info("round %s: position closed, re-arming for cycle %d",
                     self.window_id, self.cycle + 1)
            self.logger.event("reentry", window=self.window_id,
                              next_cycle=self.cycle + 1,
                              elapsed_s=round(self.elapsed(), 3))
            # A fresh cycle must not inherit the previous one's "no entry"
            # note, or the log would blame the round for a rung it did take.
            self.record.no_entry_reason = None

        self._done = True

        # A cancelled monitor must never leave a position unaccounted for.
        if self.position and self.position.is_open and not self.exited:
            self._done = False
            try:
                await self._settle_at_expiry()
            finally:
                self._done = True

        took = self.total_contracts > 0
        return self._finish(took_position=took, net_pnl=self._net_pnl())

    def _can_start_another_cycle(self) -> bool:
        """Re-arm only if the last cycle actually closed and buying is open."""
        if not self.allow_reentry or not self.exited:
            return False
        if self.cycle >= self.max_cycles:
            self.record.note(f"reentry_stopped:max_cycles_{self.max_cycles}")
            return False
        allowed, why = self._round_buy_gates()
        if not allowed:
            self.record.note(f"reentry_stopped:{why}")
            return False
        return True

    def _explain_no_trigger(self) -> str:
        price = self.feed.price
        if self.feed.state.tick_count == 0:
            return "no_price_feed_ticks"
        if price is None:
            return "no_price"
        peak = self._peak_distance()
        if peak < self.trigger_distance:
            return (f"never_hit_threshold (max |BTC-target| was "
                    f"${peak:.2f} < ${self.trigger_distance})")
        return "threshold_hit_after_trigger_deadline"

    def _peak_distance(self) -> float:
        """Largest |BTC - target| seen this window, so 'never hit threshold'
        can be reported with the number that fell short."""
        peak = 0.0
        for _mono, price in self.feed.state.history:
            peak = max(peak, abs(price - self.market.target))
        return peak

    def _net_pnl(self) -> float:
        if not self.record.exits and not self.position:
            return 0.0
        total = 0.0
        for e in self.record.exits:
            total += e.get("realized_net_pnl", 0.0) or 0.0
        return round(total, 6)

    def _calibrate_feed(self) -> None:
        """floor_strike is a published BRTI observation; comparing our last
        tick to it proves the feed end to end, every window, for free."""
        if not self.cfg.get("price_feed.calibration.enabled", True):
            return
        price = self.feed.price
        if price is None:
            return
        err = price - self.market.target
        self.record.feed_calibration_error = round(err, 4)
        warn = float(self.cfg.get("price_feed.calibration.warn_threshold_usd", 5.0))
        if abs(err) > warn:
            self.record.note(f"feed_calibration_error_{err:+.2f}")
        if self.cross_feed and self.cross_feed.price:
            div = price - self.cross_feed.price
            self.record.feed_cross_check_divergence = round(div, 4)
            warn_d = float(self.cfg.get(
                "price_feed.cross_check.warn_divergence_usd", 25.0))
            if abs(div) > warn_d:
                self.record.note(f"cross_check_divergence_{div:+.2f}")

    def _finish(self, took_position: bool, net_pnl: float) -> WindowRecord:
        self._done = True
        r = self.record
        r.contracts_held = self.total_contracts
        r.capital_deployed = round(self.total_cost, 6)
        r.entry_fees = round(self.total_entry_fees, 6)
        r.cycles = self.cycle
        r.exit_fees = round(self.exit_fees_paid, 6)

        # Round-level averages: what every contract cost on average, and what
        # every contract sold for on average.
        r.avg_buy_price = (round(self.total_cost / self.total_contracts, 4)
                           if self.total_contracts else None)
        sold_c = sum((e.get("filled_contracts") or 0) for e in r.exits)
        sold_v = sum((e.get("filled_contracts") or 0)
                     * (e.get("avg_sell_price") or e.get("avg_fill_price") or 0)
                     for e in r.exits)
        r.contracts_sold = sold_c
        r.avg_sell_price = round(sold_v / sold_c, 4) if sold_c else None
        r.avg_spread = (round(r.avg_sell_price - r.avg_buy_price, 4)
                        if (r.avg_sell_price is not None
                            and r.avg_buy_price is not None) else None)
        r.net_pnl = round(net_pnl, 6)
        r.gross_pnl = round(net_pnl + r.entry_fees + r.exit_fees, 6)
        r.net_return = (round(net_pnl / r.capital_deployed, 6)
                        if r.capital_deployed else None)
        r.feed_tick_count = self.feed.state.tick_count

        result = self.portfolio.apply_window(self.window_id, net_pnl, took_position)
        state = self.portfolio.state_dict()
        r.balance_after = state["balance"]
        # r.buy_cap was stamped at construction with the cap this window ran
        # under; overwriting it here would misreport a window that scaled up
        # and then lost, since the loss resets the cap.
        r.buy_cap_after = state["buy_cap"]
        r.consecutive_wins = state["consecutive_wins"]
        r.consecutive_losses = state["consecutive_losses"]
        r.halted = state["halted"]
        r.halt_reason = state["halt_reason"]

        self.logger.window(r)
        # The tape is NOT closed here. A round that exits early still has
        # minutes left to run, and those minutes are the only place the
        # settlement outcome can be observed. run.py closes it at close_time.
        return r


def _shrink_fills(fills, target_contracts: int):
    """Reduce a fill list to `target_contracts`, oldest first (FIFO)."""
    out = []
    remaining = target_contracts
    for f in reversed(fills):
        if remaining <= 0:
            break
        if f.contracts <= remaining:
            out.append(f)
            remaining -= f.contracts
        else:
            import copy
            g = copy.copy(f)
            g.contracts = remaining
            g.notional = round(g.price * g.contracts, 6)
            out.append(g)
            remaining = 0
    return list(reversed(out))
