"""Live order book state for a single Kalshi binary market.

Wire format (verified against the live socket, not the docs):

  orderbook_snapshot  {"yes_dollars_fp": [["0.1600","8.55"], ...],
                       "no_dollars_fp":  [...]}
  orderbook_delta     {"price_dollars": "0.1600", "delta_fp": "-8.55",
                       "side": "yes"}

Two things that bite:

  * Prices are DOLLAR STRINGS, and the tick is not a cent. KXBTC15M uses
    Kalshi's "tapered deci-cent" structure: 0.001 steps below $0.10 and above
    $0.90, 0.01 in between. Integer cents cannot represent the wings, so
    levels are keyed by integer TENTHS OF A CENT (milli-dollars) internally
    and exposed as dollars.
  * Sizes are fractional ("8.55"), so depth is a float. Our own order sizes
    stay whole contracts; only the book's resting depth is fractional.

Kalshi publishes bid ladders for both sides and no ask ladders: an ask on YES
is the mirror of a bid on NO, so best_ask(yes) = 1 - best_bid(no).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Literal

Side = Literal["yes", "no"]

UNITS_PER_DOLLAR = 1000          # 0.001 = one unit
FULL = UNITS_PER_DOLLAR          # a settled contract pays $1.00


def to_units(price) -> int:
    """Dollar price (str or float) -> integer milli-dollars."""
    return int(round(float(price) * UNITS_PER_DOLLAR))


def to_price(units: int) -> float:
    return units / UNITS_PER_DOLLAR


def _levels(raw: Iterable) -> dict[int, float]:
    out: dict[int, float] = {}
    for row in raw or []:
        try:
            price, size = row[0], row[1]
            u, s = to_units(price), float(size)
        except (TypeError, ValueError, IndexError):
            continue
        if s > 0 and 0 < u < FULL:
            out[u] = out.get(u, 0.0) + s
    return out


@dataclass
class Book:
    """Bid ladders for both sides, keyed by milli-dollars."""
    yes: dict[int, float] = field(default_factory=dict)
    no: dict[int, float] = field(default_factory=dict)
    seq: int = 0
    snapshots: int = 0
    deltas: int = 0

    # -- wire ---------------------------------------------------------------

    def apply_snapshot(self, yes_levels, no_levels, seq: int = 0) -> None:
        self.yes = _levels(yes_levels)
        self.no = _levels(no_levels)
        self.seq = seq
        self.snapshots += 1

    def apply_delta(self, side: Side, price, delta, seq: int = 0) -> None:
        book = self.yes if side == "yes" else self.no
        try:
            u, d = to_units(price), float(delta)
        except (TypeError, ValueError):
            return
        if not (0 < u < FULL):
            return
        new = book.get(u, 0.0) + d
        if new > 1e-9:
            book[u] = new
        else:
            book.pop(u, None)
        self.seq = seq
        self.deltas += 1

    def clear(self) -> None:
        """Drop state after a disconnect: a gap makes the ladder untrustworthy."""
        self.yes, self.no = {}, {}
        self.seq = 0

    # -- touch --------------------------------------------------------------

    def _book(self, side: Side) -> dict[int, float]:
        return self.yes if side == "yes" else self.no

    def best_bid_units(self, side: Side) -> int | None:
        b = self._book(side)
        return max(b) if b else None

    def best_ask_units(self, side: Side) -> int | None:
        """Best price to BUY `side`, mirrored off the opposite side's bid."""
        other = self._book("no" if side == "yes" else "yes")
        return (FULL - max(other)) if other else None

    def bid(self, side: Side) -> float | None:
        u = self.best_bid_units(side)
        return None if u is None else to_price(u)

    def ask(self, side: Side) -> float | None:
        u = self.best_ask_units(side)
        return None if u is None else to_price(u)

    def mid(self, side: Side) -> float | None:
        b, a = self.bid(side), self.ask(side)
        return None if (b is None or a is None) else (b + a) / 2.0

    def spread(self, side: Side) -> float | None:
        b, a = self.bid(side), self.ask(side)
        return None if (b is None or a is None) else round(a - b, 4)

    def quote(self, side: Side, reference: str) -> float | None:
        """Price used for band checks: ask | mid | bid."""
        if reference == "ask":
            return self.ask(side)
        if reference == "mid":
            return self.mid(side)
        if reference == "bid":
            return self.bid(side)
        raise ValueError(f"unknown band reference: {reference}")

    # -- depth --------------------------------------------------------------

    def ask_ladder(self, side: Side) -> list[tuple[float, float]]:
        """Levels we could BUY `side` at, cheapest first: [(price, size)]."""
        other = self._book("no" if side == "yes" else "yes")
        out = [(FULL - u, s) for u, s in other.items() if 0 < FULL - u < FULL]
        return [(to_price(u), s) for u, s in sorted(out, key=lambda x: x[0])]

    def bid_ladder(self, side: Side) -> list[tuple[float, float]]:
        """Levels we could SELL `side` into, richest first: [(price, size)]."""
        b = self._book(side)
        return [(to_price(u), s) for u, s in sorted(b.items(), key=lambda x: -x[0])]

    def size_at(self, side: Side, price) -> float:
        return self._book(side).get(to_units(price), 0.0)

    def depth(self, side: Side, max_price: float) -> float:
        """Total size buyable at or below `max_price`."""
        return sum(s for p, s in self.ask_ladder(side) if p <= max_price + 1e-9)

    def is_ready(self) -> bool:
        return bool(self.yes) and bool(self.no)

    def snapshot_dict(self, depth: int = 5) -> dict:
        return {
            "yes_top": [[to_price(u), s] for u, s in
                        sorted(self.yes.items(), key=lambda x: -x[0])[:depth]],
            "no_top": [[to_price(u), s] for u, s in
                       sorted(self.no.items(), key=lambda x: -x[0])[:depth]],
            "seq": self.seq,
        }


def opposite(side: Side) -> Side:
    return "no" if side == "yes" else "yes"


def side_for_direction(direction: str) -> Side:
    """Up = YES, Down = NO. One ticker per round carries both."""
    d = direction.lower()
    if d in ("up", "yes"):
        return "yes"
    if d in ("down", "no"):
        return "no"
    raise ValueError(f"unknown direction: {direction}")
