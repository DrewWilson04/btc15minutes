"""Config loading and validation.

Single source of truth is config.yaml. Nothing else in the package should
contain a tunable number. Credentials come from .env / environment only and
are never written to logs.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


log = logging.getLogger(__name__)


class ConfigError(RuntimeError):
    pass


@dataclass
class Credentials:
    api_key_id: str | None
    private_key_path: str | None
    cfbenchmarks_api_key: str | None = None

    @property
    def has_kalshi(self) -> bool:
        return bool(self.api_key_id and self.private_key_path
                    and Path(self.private_key_path).expanduser().exists())

    def redacted(self) -> dict:
        return {
            "api_key_id": (self.api_key_id[:8] + "...") if self.api_key_id else None,
            "private_key_path": self.private_key_path,
            "cfbenchmarks_api_key": "set" if self.cfbenchmarks_api_key else None,
        }


@dataclass
class Config:
    raw: dict[str, Any]
    path: Path
    creds: Credentials = field(default_factory=lambda: Credentials(None, None))

    # -- dotted access ------------------------------------------------------

    def get(self, dotted: str, default: Any = ...) -> Any:
        node: Any = self.raw
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                if default is ...:
                    raise ConfigError(f"missing config key: {dotted}")
                return default
            node = node[part]
        return node

    # -- frequently used shortcuts -----------------------------------------

    @property
    def active_profile(self) -> str | None:
        return self.raw.get("active_profile")

    @property
    def profile_label(self) -> str:
        name = self.active_profile or ""
        prof = (self.raw.get("profiles") or {}).get(name) or {}
        return prof.get("label", name.title() or "custom")

    @property
    def live_trading(self) -> bool:
        return bool(self.get("mode.live_trading", False))

    @property
    def environment(self) -> str:
        return str(self.get("mode.environment", "prod"))

    @property
    def api_base(self) -> str:
        if self.environment == "demo":
            return "https://demo-api.kalshi.co/trade-api/v2"
        return "https://api.elections.kalshi.com/trade-api/v2"

    @property
    def ws_url(self) -> str:
        if self.environment == "demo":
            return "wss://demo-api.kalshi.co/trade-api/ws/v2"
        return "wss://api.elections.kalshi.com/trade-api/ws/v2"

    @property
    def ws_sign_path(self) -> str:
        return "/trade-api/ws/v2"


DEFAULT_CONFIG_PATHS = ("config.yaml", "config.yml")


def _load_dotenv(root: Path) -> None:
    """Minimal .env loader; python-dotenv if available, else hand-rolled."""
    env_path = root / ".env"
    if not env_path.exists():
        return
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=False)
        return
    except ImportError:
        pass
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _load_credentials(root: Path) -> Credentials:
    """.env first, then credentials.json. Both are gitignored."""
    _load_dotenv(root)

    key_id = os.environ.get("KALSHI_API_KEY_ID")
    key_path = os.environ.get("KALSHI_PRIVATE_KEY_PATH")
    cf_key = os.environ.get("CFBENCHMARKS_API_KEY") or None

    cred_json = root / "credentials.json"
    if (not key_id or not key_path) and cred_json.exists():
        import json
        data = json.loads(cred_json.read_text())
        key_id = key_id or data.get("api_key_id") or data.get("key_id")
        key_path = key_path or data.get("private_key_path")
        cf_key = cf_key or data.get("cfbenchmarks_api_key")
        # Allow an inline PEM in credentials.json by spilling it to a sibling
        # file, so the signing path only ever deals with files on disk.
        if not key_path and data.get("private_key"):
            spill = root / ".kalshi_private_key.pem"
            spill.write_text(data["private_key"])
            spill.chmod(0o600)
            key_path = str(spill)

    if key_path:
        p = Path(key_path).expanduser()
        if not p.is_absolute():
            p = (root / p).resolve()
        key_path = str(p)

    return Credentials(key_id, key_path, cf_key)


def _validate(cfg: Config) -> None:
    """Fail loudly at startup rather than mid-window."""
    required = [
        "mode.live_trading", "market.series_ticker", "market.window_seconds",
        "trigger.distance_usd", "trigger.max_elapsed_seconds",
        "entry.notional_per_buy_usd", "entry.rungs",
        "entry.cooldown_seconds", "entry.no_buy_after_elapsed_seconds",
        "entry.buy_cap.default", "entry.buy_cap.scaled",
        "exit.adverse_move.distance_usd", "exit.adverse_move.min_net_return",
        "execution.order_type", "execution.limit_timeout_seconds",
        "fees.taker_rate", "fees.maker_share_of_taker",
        "capital.paper_starting_balance_usd", "capital.max_deployed_fraction",
        "exit.thresholds", "halt.consecutive_losses", "halt.rolling_losses",
        "halt.rolling_window_count", "scaling.wins_to_scale_up",
        "logging.window_log_path",
    ]
    for key in required:
        cfg.get(key)

    order_type = cfg.get("execution.order_type")
    if order_type not in ("limit_first", "always_take", "always_limit"):
        raise ConfigError(f"execution.order_type must be limit_first|always_take|"
                          f"always_take, got {order_type!r}")

    ref = cfg.get("entry.band_reference", "ask")
    if ref not in ("ask", "mid", "bid"):
        raise ConfigError(f"entry.band_reference must be ask|mid|bid, got {ref!r}")

    src = cfg.get("price_feed.source")
    if src not in ("kalshi_index", "composite", "coinbase"):
        raise ConfigError(f"price_feed.source must be kalshi_index|composite|"
                          f"coinbase, got {src!r}")

    if cfg.environment not in ("prod", "demo"):
        raise ConfigError(f"mode.environment must be prod|demo, got {cfg.environment!r}")

    rungs = cfg.get("entry.rungs")
    if not isinstance(rungs, list) or not rungs:
        raise ConfigError("entry.rungs must be a non-empty list")
    for i, row in enumerate(rungs):
        lo, hi = row.get("min_price"), row.get("max_price")
        if lo is None or hi is None or not (0 < lo < hi < 1):
            raise ConfigError(f"entry.rungs[{i}] must satisfy 0 < min_price < "
                              f"max_price < 1")
    if rungs[-1].get("up_to") is not None:
        raise ConfigError("the last entry.rungs row must have `up_to: null` so "
                          "rungs beyond the table still have a band")
    ups = [r.get("up_to") for r in rungs[:-1]]
    if any(u is None for u in ups) or ups != sorted(ups):
        raise ConfigError("entry.rungs `up_to` values must ascend, with only "
                          "the final row null")

    cutoff = cfg.get("entry.no_buy_after_elapsed_seconds")
    window = cfg.get("market.window_seconds")
    if not (0 < cutoff < window):
        raise ConfigError("entry.no_buy_after_elapsed_seconds must fall inside "
                          "the window")

    # Lowering the profit target while the ladder can still buy means adding to
    # a position on terms you have already given up on. Catch it in config
    # rather than discovering it in a P&L curve.
    for t in cfg.get("exit.thresholds"):
        tr = t.get("time_remaining_under")
        if tr is None:
            continue
        starts_at = window - float(tr)
        if starts_at < cutoff:
            # Deliberate here, but worth saying out loud: between these two
            # times the ladder can still BUY while the profit target has
            # already been cut, so it is adding on terms it has given up on.
            log.warning(
                "exit threshold %r drops the target at %.0fs elapsed, but "
                "buying stays open until %.0fs — for %.0fs the bot can buy "
                "while aiming at the lower target",
                t.get("name"), starts_at, cutoff, cutoff - starts_at)

    frac = cfg.get("capital.max_deployed_fraction")
    if not (0 < frac <= 1):
        raise ConfigError("capital.max_deployed_fraction must be in (0, 1]")

    thresholds = cfg.get("exit.thresholds")
    if not isinstance(thresholds, list) or not thresholds:
        raise ConfigError("exit.thresholds must be a non-empty list")
    if not any(t.get("time_remaining_under") is None for t in thresholds):
        raise ConfigError("exit.thresholds needs one base rule with "
                          "time_remaining_under: null")

    if cfg.get("entry.buy_cap.scaled") < cfg.get("entry.buy_cap.default"):
        raise ConfigError("entry.buy_cap.scaled must be >= entry.buy_cap.default")

    # The absolute ceiling must actually be able to contain a full ladder.
    max_notional = (cfg.get("entry.buy_cap.scaled")
                    * cfg.get("entry.notional_per_buy_usd"))
    hard = cfg.get("safety.absolute_max_window_notional_usd", max_notional)
    if hard < max_notional:
        raise ConfigError(
            f"safety.absolute_max_window_notional_usd ({hard}) is below the "
            f"scaled ladder size ({max_notional}); raise it or lower buy_cap")


def load_config(path: str | Path | None = None,
                profile: str | None = None) -> Config:
    root = Path(__file__).resolve().parent.parent
    if path is None:
        for name in DEFAULT_CONFIG_PATHS:
            candidate = root / name
            if candidate.exists():
                path = candidate
                break
        else:
            raise ConfigError(f"no config file found in {root}")
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise ConfigError(f"config file not found: {p}")

    raw = yaml.safe_load(p.read_text()) or {}
    cfg = Config(raw=raw, path=p, creds=_load_credentials(root))
    active = profile or raw.get("active_profile")
    if active:
        apply_profile(cfg, active)
    else:
        _validate(cfg)
    return cfg


def set_dotted(root: dict, dotted: str, value) -> None:
    node = root
    parts = dotted.split(".")
    for part in parts[:-1]:
        nxt = node.get(part)
        if not isinstance(nxt, dict):
            nxt = {}
            node[part] = nxt
        node = nxt
    node[parts[-1]] = value


def apply_profile(cfg: "Config", name: str) -> None:
    """Overlay a named profile's overrides onto the config, then re-validate.

    Profiles hold only what they change; everything else stays as the shared
    baseline. Validation runs again afterwards so a profile cannot smuggle in
    a combination the bot would refuse at startup.
    """
    profiles = cfg.raw.get("profiles") or {}
    if name not in profiles:
        raise ConfigError(
            f"unknown profile {name!r}. Available: "
            f"{', '.join(sorted(profiles)) or 'none defined'}")
    for dotted, value in (profiles[name].get("overrides") or {}).items():
        set_dotted(cfg.raw, dotted, value)
    cfg.raw["active_profile"] = name
    _validate(cfg)


def profile_names(cfg: "Config") -> list[str]:
    return sorted((cfg.raw.get("profiles") or {}).keys())


def project_root() -> Path:
    return Path(__file__).resolve().parent.parent
