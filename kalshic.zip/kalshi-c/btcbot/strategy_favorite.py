"""The favourite strategy.

It subclasses WindowTrader so they inherit the whole measurement scaffold —
WindowRecord, position accounting, `_exit_now`, `_settle_at_expiry`, `_finish`
— and override only `run()`. Nothing here changes the ladder's behaviour.

  FavoriteTrader   Buy a clear favourite late in the round and hold it to
                   settlement. See its docstring for the gates.
"""
from __future__ import annotations

import asyncio
import logging
from collections import deque

from .execution import OrderResult
from .logging_jsonl import WindowRecord
from .orderbook import Side
from .portfolio import Position
from .strategy import WindowTrader

log = logging.getLogger(__name__)


class FavoriteTrader(WindowTrader):
    """Run C: buy a well-clear favourite late, and hold it to settlement.

    Four gates, all required. They exist because the strategy's one loss came
    from the CALMEST round in the sample: BTC sat on the target all round and
    settled $3.23 the wrong way. A quiet round is the dangerous one — the
    danger is not volatility, it is a small gap.

      * the round must not have run more than `max_adverse_usd` AGAINST the
        side being bought during the first `observe_seconds`, and must not
        have run that far in BOTH directions;
      * at the moment of buying, BTC must be at least `min_gap_usd` clear of
        target IN FAVOUR of that side;
      * the buy happens only inside the last `entry_window_seconds`;
      * the side must be offered at `min_price` or better.

    Whatever is bought is held to settlement; there is no exit rule.
    """

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        c = self.cfg.get("favorite", {}) or {}
        self.min_price = float(c.get("min_price", 0.93))
        self.observe_seconds = float(c.get("observe_seconds", 720.0))
        self.entry_window = float(c.get("entry_window_seconds", 150.0))
        self.max_adverse = float(c.get("max_adverse_usd", 100.0))
        # A gap requirement at the moment of buying looked sensible and tested
        # badly: waiting for the gap means paying for it, because the price
        # already encodes it. 0 disables it.
        self.min_gap = float(c.get("min_gap_usd", 0.0))
        # How far the round must have TRAVELLED during the observation
        # stretch. A round pinned to the target for twelve minutes is one
        # where settlement is still a coin flip however confident the price
        # looks — that is where the only loss came from.
        self.min_range = float(c.get("min_range_usd", 50.0))
        self.stake = float(c.get("stake_usd", 50.0))
        self.stake_after_loss = float(c.get("stake_after_loss_usd", 40.0))
        self.recover_rounds = int(c.get("stake_recover_rounds", 2))
        self.record.note(f"strategy:favorite>={self.min_price:.2f}"
                         f",range>={self.min_range:.0f}")
        # Worst excursion each way during the observation stretch.
        self._max_above = 0.0
        self._max_below = 0.0
        # Rolling (elapsed, btc, yes_ask, no_ask) samples, kept short. Without
        # this there is no way to say what the price was BEFORE a buy — by the
        # time the buy happens that moment has already gone.
        self._hist: deque = deque(maxlen=400)

    def _sample(self) -> None:
        self._hist.append((self.elapsed(), self.feed.price,
                           self.book.ask("yes"), self.book.ask("no")))

    def _price_at(self, seconds_ago: float):
        """The sample closest to `seconds_ago` before now, or None."""
        if not self._hist:
            return None
        want = self.elapsed() - seconds_ago
        best = min(self._hist, key=lambda x: abs(x[0] - want))
        return best if abs(best[0] - want) <= 3.0 else None

    def _stake_for_round(self) -> float:
        """Full stake, or the reduced one for the rounds after a loss."""
        p = self.portfolio
        if p.rounds_lost > 0 and p.consecutive_wins < self.recover_rounds:
            return self.stake_after_loss
        return self.stake

    def _gate(self, side: Side, ask: float, gap: float) -> tuple[bool, str]:
        """Every reason this side may not be bought, in plain terms."""
        direction = "up" if side == "yes" else "down"
        favour = gap if direction == "up" else -gap
        if ask < self.min_price:
            return False, f"price {ask:.3f} under {self.min_price:.2f}"
        if ask >= 1.0:
            return False, "nothing left to win"
        if self.min_gap > 0 and favour < self.min_gap:
            return False, (f"only ${favour:+.2f} in favour, needs "
                           f"${self.min_gap:.2f}")
        adverse = self._max_below if direction == "up" else self._max_above
        if adverse > self.max_adverse:
            return False, (f"ran ${adverse:.2f} against {direction.upper()} "
                           f"earlier, limit ${self.max_adverse:.0f}")
        if self._max_above > self.max_adverse and self._max_below > self.max_adverse:
            return False, "swung past the limit in BOTH directions"
        return True, ""

    async def run(self) -> WindowRecord:
        if self.portfolio.halted:
            self.record.no_trigger_reason = "halted"
            self.record.no_entry_reason = "halted"
            log.info("%s: halted (%s) — sitting out", self.window_id,
                     self.portfolio.halt_reason)
            return self._finish(took_position=False, net_pnl=0.0)

        # --- watch the opening stretch ---
        while self.elapsed() < self.observe_seconds and self.remaining() > 0:
            px = self.feed.price
            if px is not None and self.market.target is not None:
                d = px - self.market.target
                self._max_above = max(self._max_above, d)
                self._max_below = max(self._max_below, -d)
            self._sample()
            await self.clock.sleep(0.2)

        self.record.note(f"ran_up:{self._max_above:.2f}")
        self.record.note(f"ran_down:{self._max_below:.2f}")
        travelled = self._max_above + self._max_below
        self.record.note(f"range:{travelled:.2f}")
        if travelled < self.min_range:
            self.record.no_trigger_reason = (
                f"too quiet: moved ${travelled:.2f}, needs ${self.min_range:.0f}")
            log.info("%s: only moved $%.2f in the first %.0fs (needs $%.0f) — "
                     "a round pinned to the target is a coin flip, sitting out",
                     self.window_id, travelled, self.observe_seconds,
                     self.min_range)
            return self._finish(took_position=False, net_pnl=0.0)
        if (self._max_above > self.max_adverse
                and self._max_below > self.max_adverse):
            self.record.no_trigger_reason = "swung_both_directions"
            log.info("%s: ran +$%.2f and -$%.2f — swung past $%.0f BOTH ways, "
                     "sitting out", self.window_id, self._max_above,
                     self._max_below, self.max_adverse)
            return self._finish(took_position=False, net_pnl=0.0)

        # --- hunt for a qualifying favourite inside the entry window ---
        bought = False
        last_why = None
        while self.remaining() > 0 and not bought:
            self._sample()
            if self.remaining() > self.entry_window:
                await self.clock.sleep(0.1)
                continue
            px = self.feed.price
            gap = (None if px is None or self.market.target is None
                   else px - self.market.target)
            if gap is None:
                await self.clock.sleep(0.1)
                continue
            for side in ("yes", "no"):
                ask = self.book.ask(side)
                if ask is None:
                    continue
                ok, why = self._gate(side, ask, gap)
                if not ok:
                    last_why = f"{'UP' if side == 'yes' else 'DOWN'}: {why}"
                    continue
                stake = self._stake_for_round()
                contracts = int(stake // ask)
                if contracts <= 0:
                    last_why = "stake too small for the price"
                    continue
                allowed, blocked = self.portfolio.can_deploy(
                    ask * contracts, 0.0)
                if not allowed:
                    last_why = f"capital: {blocked}"
                    self.record.note(f"favorite_blocked:{blocked}")
                    continue
                bought = await self._take_favorite(side, contracts, ask, gap,
                                                   stake)
                if bought:
                    break
            if not bought:
                await self.clock.sleep(0.1)

        if not bought:
            self.record.no_trigger_reason = (last_why or
                                             f"no side reached {self.min_price:.2f}")
            log.info("%s: no qualifying favourite in the last %.0fs — %s",
                     self.window_id, self.entry_window, last_why or "nothing offered")
            return self._finish(took_position=False, net_pnl=0.0)

        # --- hold to settlement, no exit rule ---
        self.record.held_to_settle = True
        self.record.held_to_settle_from_s = round(self.elapsed(), 2)
        while self.remaining() > 0:
            await self.clock.sleep(0.1)
        if self.position and self.position.is_open and not self.exited:
            try:
                await self._settle_at_expiry()
            finally:
                self._done = True
        self._done = True
        self.record.cycles = self.cycle
        return self._finish(took_position=True, net_pnl=self._net_pnl())

    def _snap_dict(self, sample, side: Side) -> dict:
        if sample is None:
            return {}
        el, btc, ya, na = sample
        tgt = self.market.target
        return {
            "btc": btc,
            "gap_from_target": (None if btc is None or tgt is None
                                else round(btc - tgt, 2)),
            "ask": ya if side == "yes" else na,
            "seconds_before": round(self.elapsed() - el, 1),
        }

    async def _snap_after(self, side: Side, snap: dict) -> None:
        """Where the market was 5 seconds after the fill."""
        try:
            await self.clock.sleep(5.0)
            tgt = self.market.target
            btc = self.feed.price
            snap["after_5s"] = {
                "btc": btc,
                "gap_from_target": (None if btc is None or tgt is None
                                    else round(btc - tgt, 2)),
                "ask": self.book.ask(side),
                "bid": self.book.bid(side),
            }
            self.record.snapshots = snap
            self.logger.event("price_around_buy", window=self.window_id, **snap)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 - observation must not break trading
            log.debug("post-buy snapshot failed", exc_info=True)

    async def _take_favorite(self, side: Side, contracts: int, ask: float,
                             gap: float, stake: float) -> bool:
        # The side must be locked BEFORE the order is recorded: the trade
        # ledger reads it from here.
        self.locked_side = side
        self.locked_direction = "up" if side == "yes" else "down"
        result = await self.executor.buy(self.book, side, contracts,
                                         "always_take", 0.0)
        self._record_order(result, rung=1, intended=ask)
        if not result.filled or not result.filled_contracts:
            self.locked_side = None
            self.locked_direction = None
            return False
        if result.avg_price < self.min_price - 1e-9:
            self.record.note(f"favorite_filled_under_floor:{result.avg_price:.3f}")
        self.record.direction = self.locked_direction
        self.record.side = side
        self.record.trigger_fired = True
        self.record.trigger_elapsed_s = round(self.elapsed(), 3)
        self.record.trigger_time = self._now_iso()
        self.record.trigger_btc_price = self.feed.price
        self.record.trigger_distance = round(gap, 4)
        self.record.note(f"gap_at_entry:{gap:+.2f}")
        self.record.note(f"stake:{stake:.2f}")
        self.cycle = 1
        self.position = Position(side=side)
        for f in result.fills:
            self.position.add(f)
            self.total_cost += f.price * f.contracts
            self.total_entry_fees += f.fee_paid
            self.total_contracts += f.contracts
        self.buys_done = self.total_buys = 1

        # Three snapshots around the fill: what it could see 5s earlier, what
        # it paid, and where the market went 5s later. The gap between them is
        # how you tell a real edge from buying into a spike.
        before = self._price_at(5.0)
        snap = {
            "before_5s": self._snap_dict(before, side),
            "at_buy": {
                "btc": self.feed.price,
                "gap_from_target": round(gap, 2),
                "ask": round(ask, 4),
                "filled_at": round(result.avg_price, 4),
            },
        }
        self.record.snapshots = snap
        asyncio.create_task(self._snap_after(side, snap))

        log.info("%s: FAVOURITE %s %d @ %.3f — BTC is $%+.2f from target, "
                 "%.0fs left, stake $%.0f — holding to settlement",
                 self.window_id, side, result.filled_contracts,
                 result.avg_price, gap, self.remaining(), stake)
        return True


STRATEGIES = {
    "ladder": WindowTrader,
    "favorite": FavoriteTrader,
}


def build_trader(name: str):
    try:
        return STRATEGIES[name]
    except KeyError:
        raise ValueError(
            f"unknown strategy {name!r}; expected one of "
            f"{', '.join(sorted(STRATEGIES))}") from None
