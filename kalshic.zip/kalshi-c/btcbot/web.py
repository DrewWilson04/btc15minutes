"""Localhost web dashboard.

Why this exists alongside the terminal one: a browser tab is a far better
place for a long-running monitor. Closing the tab does not kill the bot, the
page reconnects on its own, you can reopen it whenever you like, and a stale
screen is impossible to mistake for a running one — the page says how many
seconds ago it last heard from the bot.

No dependencies: a small asyncio HTTP server serving one HTML page plus a
/state JSON endpoint the page polls.

Binds to 127.0.0.1 by default. The page exposes account balances and live
positions, so it should not be put on a public interface without thought.
"""
from __future__ import annotations

import asyncio
import json
import logging
import traceback
from pathlib import Path
from datetime import datetime, timezone

from datetime import timedelta

from .clock import (DISPLAY_TZ, local_hms, monotonic, to_local,
                     tz_abbrev, utcnow)

log = logging.getLogger(__name__)


# The rule names in config are identifiers; these are what a human reads.
RULE_WORDS = {
    "take_profit_7pct": "take profit",
    "settle_for_3pct": "settle for less",
    "take_any_profit": "take any profit",
    "dearest_rung_in_profit": "dearest rung up 5% — sold the lot",
    "blended_position_profit": "whole position up 8.5% — cleared",
    "take_profit_7pct_sweep": "swept along with the 7% sale",
    "take_any_profit_sweep": "swept along",
    "get_out_flat_sweep": "swept along",
    "get_out_flat": "get out flat",
    "cut_losses": "cut losses",
    "adverse_move_breakeven": "adverse move — get out flat",
    "forced_exit_near_close": "forced exit at close",
    "expired_settled": "held to settlement",
}


def words(name: str | None) -> str:
    return RULE_WORDS.get(name or "", (name or "").replace("_", " "))


def rule_help(cfg) -> dict:
    """Plain-English explanation of every exit label, built from live config
    so the numbers quoted are the ones actually running."""
    goal = [t for t in cfg.get("exit.thresholds")
            if t["time_remaining_under"] is None][0]["min_net_return"]
    dear = (cfg.get("exit.sell_all_when_dearest") or {}).get("min_net_return", 0.05)
    hold = cfg.get("exit.hold_if_winning") or {}
    adv = cfg.get("exit.adverse_move") or {}
    return {
        "take_profit_7pct": {
            "title": "Take profit",
            "text": (f"Every buy is tracked against what THAT buy cost. When one "
                     f"reaches +{goal*100:.0f}% on its own, after fees, it sells by "
                     f"itself — the other buys stay in and keep working. Cheaper "
                     f"buys get there first, because they need a smaller move to "
                     f"make the same percentage."),
        },
        "take_profit_5pct": {
            "title": "Settle for 5%",
            "text": ("Same as taking profit, but the target has stepped down to 5% "
                     "because there is under 5:00 left in the round. Less time to "
                     "wait for the full target, so it accepts less."),
        },
        "take_profit_7pct_sweep": {
            "title": "Swept along",
            "text": (f"When one buy sells at its target, any other buy sitting just "
                     f"behind it goes out in the same move — but only if that buy "
                     f"is genuinely in profit after fees. It stops a near-miss "
                     f"being stranded when the price fades. A buy at a loss is "
                     f"never swept."),
        },
        "take_profit_5pct_sweep": {
            "title": "Swept along (late)",
            "text": ("Swept out alongside another buy, during the part of the round "
                     "where the target has dropped to 5%."),
        },
        "dearest_rung_in_profit": {
            "title": "Dearest buy in profit — sold the lot",
            "text": (f"Watches the buy you paid the MOST for, which is the hardest "
                     f"one to get into profit. If even that one is up "
                     f"{dear*100:.0f}%, every cheaper buy is up more — so it sells "
                     f"the whole position at once rather than trickling out while "
                     f"the move fades. Usually fires when the price jumps."),
        },
        "get_out_flat": {
            "title": "Get out flat",
            "text": ("Under 1:00 left. The target is now breakeven — take anything "
                     "that is not a loss and be done."),
        },
        "get_out_now": {
            "title": "Get out now",
            "text": ("Under 0:30 left. Sells at whatever the book is bidding, "
                     "whatever the price. Better a small loss than a contract that "
                     "settles at zero."),
        },
        "expired_settled": {
            "title": "Held to settlement",
            "text": ("Nothing sold it, so it ran to the bell. A contract on the "
                     "right side of the target pays $1.00; on the wrong side it "
                     "pays nothing. All or nothing."),
        },
        "forced_exit_near_close": {
            "title": "Forced exit",
            "text": ("Last few seconds, and BTC has moved well past the target. "
                     "Sells immediately at whatever is there."),
        },
        "adverse_move_breakeven": {
            "title": "Adverse move",
            "text": (f"BTC went ${adv.get('distance_usd', 0):.0f} the WRONG side of "
                     f"the target. The bet is broken, so it stops buying and drops "
                     f"the goal to breakeven to get out clean."),
        },
        "thin_margin_breakeven": {
            "title": "Too close to call",
            "text": (f"Late in the round, BTC is on our side by less than "
                     f"${hold.get('min_margin_usd', 0):.2f} and the market prices "
                     f"our side cheaply — both say coin flip. It aims for breakeven "
                     f"rather than gambling on settlement."),
        },
        "thin_margin_get_out": {
            "title": "Coin flip — out",
            "text": ("Final seconds of a too-close-to-call round. Takes whatever "
                     "the book gives."),
        },
        "thin_margin_partial": {
            "title": "Free roll",
            "text": (f"Sold most of the position but kept "
                     f"{hold.get('thin_margin_keep_fraction', 0)*100:.0f}% riding to "
                     f"settlement. Caps the downside while still collecting $1.00 a "
                     f"contract if the coin lands your way."),
        },
        "blended_position_profit": {
            "title": "Whole position in profit",
            "text": ("Last-resort check: the position as a whole, all buys averaged "
                     "together, is up 8.5%. Clears it."),
        },
        "cooldown_after_losses": {
            "title": "Sat this one out",
            "text": ("Skipped the round deliberately after a run of losses."),
        },
        "price_never_entered_band": {
            "title": "Never got a price",
            "text": ("The side it wanted to buy never traded inside the allowed "
                     "price band, so no position was opened."),
        },
        "never_hit_threshold": {
            "title": "No trigger",
            "text": ("BTC never moved far enough from the target to pick a side, "
                     "so the round was skipped."),
        },
    }


def _iso(dt) -> str | None:
    if not isinstance(dt, datetime):
        return None
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


STRATEGY_BLURB = {
    "ladder": "A — 10.01 trigger, 30s confirm, laddered buys",
    "dual_limit": "B — resting buys on both sides, sell at a fixed price",
    "favorite": "C — late favourite in a calm round, held to settlement",
}


class WebDashboard:
    def __init__(self, state, log_pane=None, host: str = "127.0.0.1",
                 port: int = 8787, on_reset=None):
        self.state = state
        self.log_pane = log_pane
        self.host = host
        self.port = port
        self.on_reset = on_reset
        self._server = None

    # -- state ------------------------------------------------------------

    def state_dict(self) -> dict:
        s = self.state
        cfg = s.cfg
        p = s.portfolio
        t = s.trader
        m = s.market
        book = s.book

        feed_age = None
        if s.feed.state.last is not None:
            feed_age = round(monotonic() - s.feed.state.last.received_at, 2)

        out: dict = {
            "now": _iso(utcnow()),
            "tz": DISPLAY_TZ,
            "tz_label": tz_abbrev(),
            "mode": s.mode,
            "profile": s.cfg.active_profile,
            "profile_label": s.cfg.profile_label,
            "profiles": sorted((s.cfg.raw.get("profiles") or {}).keys()),
            "up_seconds": round((utcnow() - s.started).total_seconds()),
            "ws_market": s.ws_market,
            "ws_index": s.ws_index,
            "feed": {
                "price": s.feed.price,
                "target": None,       # filled in below once a round is known
                "delta": None,
                "ticks": s.feed.state.tick_count,
                "age_s": feed_age,
                "stale_after": float(cfg.get(
                    "price_feed.kalshi_index.stale_tick_seconds", 5.0)),
            },
            "account": {
                "rounds_total": p.rounds_total,
                "rounds_traded": p.rounds_traded,
                "rounds_skipped": p.rounds_total - p.rounds_traded,
                "rounds_won": p.rounds_won,
                "rounds_lost": p.rounds_lost,
                "balance": round(p.balance, 4),
                "stake": round(p.current_notional, 2),
                "cooldown": p.cooldown_remaining,
                "start": round(p.starting_balance, 4),
                "pnl": round(p.balance - p.starting_balance, 4),
                "buy_cap": p.buy_cap,
                "stake": round(p.current_notional, 2),
                "cooldown": p.cooldown_remaining,
                "wins": p.consecutive_wins,
                "losses": p.consecutive_losses,
                "halted": p.halted,
                "halt_reason": p.halt_reason,
                "max_deployed": round(p.max_deployed, 2),
            },
            "rules": {
                "trigger_usd": cfg.get("trigger.distance_usd"),
                "gate_s": cfg.get("trigger.max_elapsed_seconds"),
                "buy_cutoff_s": cfg.get("entry.no_buy_after_elapsed_seconds"),
                "adverse_usd": cfg.get("exit.adverse_move.distance_usd"),
            },
            "window": None,
            "observing": None,
            "next_open": _iso(s.next_open),
            "book": None,
            "position": None,
            "activity": [],
            "recent": [],
            "log": [],
        }

        # Target rides next to the price wherever a round is known, traded or
        # merely observed, so the two numbers are always read together.
        live_target = None
        if m is not None and m.has_target:
            live_target = m.target
        elif s.observed_market is not None and s.observed_market.has_target:
            live_target = s.observed_market.target
        if live_target is not None:
            out["feed"]["target"] = live_target
            if s.feed.price is not None:
                out["feed"]["delta"] = round(s.feed.price - live_target, 2)

        # A market strip that does NOT depend on a round being in progress:
        # between rounds the trader is gone but the book and the feed are
        # still live, and that is exactly when you want to see where the
        # trigger levels sit relative to the price.
        trig = cfg.get("trigger.distance_usd")
        mk = {
            "btc": s.feed.price,
            "target": live_target,
            "delta": (round(s.feed.price - live_target, 2)
                      if (live_target is not None and s.feed.price is not None)
                      else None),
            "trigger_usd": trig,
            "trigger_up": (round(live_target + trig, 2)
                           if live_target is not None else None),
            "trigger_down": (round(live_target - trig, 2)
                             if live_target is not None else None),
            "ticker": (m.ticker if m is not None else
                       (s.observed_market.ticker
                        if s.observed_market is not None else None)),
            "yes_bid": None, "yes_ask": None, "no_bid": None, "no_ask": None,
        }
        if s.book is not None and s.book.is_ready():
            mk.update({
                "yes_bid": s.book.bid("yes"), "yes_ask": s.book.ask("yes"),
                "no_bid": s.book.bid("no"), "no_ask": s.book.ask("no"),
            })
        out["market"] = mk

        if m is not None and t is not None:
            r = t.record
            out["window"] = {
                "ticker": m.ticker,
                "target": m.target,
                "elapsed": round(t.elapsed(), 1),
                "remaining": round(t.remaining(), 1),
                "trigger_fired": r.trigger_fired,
                "direction": r.direction,
                "side": r.side,
                "trigger_elapsed": r.trigger_elapsed_s,
                "trigger_time": r.trigger_time,
                "trigger_btc": r.trigger_btc_price,
                "trigger_distance": r.trigger_distance,
                "no_trigger_reason": r.no_trigger_reason,
                "adverse": r.adverse_move_fired,
                "adverse_btc": r.adverse_move_btc,
                "adverse_distance": r.adverse_move_distance,
                "peak_distance": (round(t._peak_distance(), 2)
                                  if t.feed.state.history else 0.0),
                "avg_buy": (round(t.total_cost / t.total_contracts, 4)
                            if t.total_contracts else None),
                "buys_done": t.buys_done,
                "total_buys": t.total_buys,
                "buy_cap": s.portfolio.buy_cap,
                "cycle": t.cycle,
                "max_cycles": t.max_cycles,
            }
            allowed, why = t._buying_allowed()
            out["window"]["buying_allowed"] = allowed
            out["window"]["buying_blocked_why"] = why

            locked = t.locked_side
            if book.is_ready():
                b = {
                    "yes_bid": book.bid("yes"), "yes_ask": book.ask("yes"),
                    "no_bid": book.bid("no"), "no_ask": book.ask("no"),
                    "spread": book.spread("yes"), "locked": locked,
                }
                if locked:
                    rung = t.buys_done + 1
                    lo, hi = t._band_for_rung(rung)
                    q = book.quote(locked, cfg.get("entry.band_reference", "ask"))
                    b.update({"rung": rung, "band_lo": lo, "band_hi": hi,
                              "band_price": q,
                              "in_band": q is not None and lo <= q <= hi})
                out["book"] = b

            pos = t.position
            if pos and pos.is_open:
                from .fees import net_return_on_exit
                bid = book.bid(pos.side)
                net = None
                if bid is not None:
                    net, _f, _p = net_return_on_exit(
                        pos.cost, pos.entry_fees, bid, pos.contracts, False,
                        t.fee_cfg)
                rule = t._active_rule(t.remaining())
                need = rule.min_net_return
                name = rule.name
                if t.adverse_fired and t.adverse_min_return < need:
                    need, name = t.adverse_min_return, "adverse_move_breakeven"
                out["position"] = {
                    "rule_words": words(name),
                    "side": pos.side, "contracts": pos.contracts,
                    "avg_price": round(pos.avg_price, 4),
                    "cost": round(pos.cost, 4),
                    "fees": round(pos.entry_fees, 4),
                    "mark": bid, "net": net, "need": need, "rule": name,
                }

            out["activity"] = self._activity(r)

        elif s.observed_market is not None and s.observed_market.has_target:
            om = s.observed_market
            btc = s.feed.price
            out["observing"] = {
                "ticker": om.ticker, "target": om.target,
                "delta": (round(btc - om.target, 2) if btc else None),
            }

        for rec in list(s.recent)[-8:]:
            out["recent"].append({
                "id": rec.window_id, "dir": rec.direction,
                "contracts": rec.contracts_held,
                "deployed": rec.capital_deployed,
                "net": rec.net_pnl, "pct": rec.net_return,
                "reason": (words(rec.exit_reason) if rec.exit_reason
                           else (rec.no_entry_reason or "").replace("_", " ")),
                "reason_key": rec.exit_reason or rec.no_entry_reason,
                "traded": rec.capital_deployed > 0,
            })

        if self.log_pane:
            out["log"] = [{"t": ts, "level": lv, "msg": msg}
                          for ts, lv, msg in list(self.log_pane.lines)]
        return out

    @staticmethod
    def _activity(r) -> list[dict]:
        rows: list[dict] = []
        if r.trigger_fired:
            rows.append({"kind": "trig", "t": r.trigger_time or "",
                         "text": f"{(r.direction or '').upper()} locked",
                         "detail": f"+{r.trigger_elapsed_s:.2f}s · BTC "
                                   f"{r.trigger_btc_price:,.2f} · "
                                   f"Δ {r.trigger_distance:+.2f}"})
        for b in r.buys:
            fills = b.get("fills") or []
            if not fills:
                continue
            qty = sum(f["contracts"] for f in fills)
            cost = sum(f["fill_price"] * f["contracts"] for f in fills)
            fee = sum(f["fee_paid"] for f in fills)
            rows.append({"kind": "buy", "t": b.get("timestamp", ""),
                         "text": f"BUY {b.get('rung','?')}"
                                 + (f" ·{b['cycle']}" if b.get("cycle", 1) > 1 else ""),
                         "detail": f"{qty}c @ {b.get('avg_fill_price', 0):.3f} · "
                                   f"cost ${cost:.2f} · fee ${fee:.2f} · "
                                   f"{fills[0].get('liquidity')}",
                         "liquidity": fills[0].get("liquidity")})
        for o in r.unfilled_orders:
            if o.get("kind") == "abandoned_limit":
                rows.append({"kind": "cxl", "t": o.get("timestamp", ""),
                             "text": f"CXL {o.get('rung','?')}",
                             "detail": f"limit {o.get('posted_price') or 0:.3f} "
                                       f"unfilled {o.get('rested_s',0):.1f}s → crossed"})
        for e in r.exits:
            pnl = e.get("realized_net_pnl")
            pct = e.get("realized_net_pct")
            if e.get("reason") == "expired_settled":
                rows.append({"kind": "setl", "t": e.get("timestamp", ""),
                             "text": "SETTLE",
                             "detail": f"{e.get('contracts',0)}c @ "
                                       f"{e.get('settle_value',0):.0f} · "
                                       f"${pnl:+.2f} · ",
                             "reason_key": e.get("reason"),
                             "reason_words": words(e.get("reason")),
                             "pnl": pnl})
            else:
                rows.append({"kind": "sell", "t": e.get("timestamp", ""),
                             "text": "SELL",
                             "detail": f"{e.get('filled_contracts',0)}c · "
                                       f"bought {(e.get('avg_buy_price') or 0):.3f} "
                                       f"→ sold {(e.get('avg_sell_price') or 0):.3f} · "
                                       f"${pnl:+.2f} ({(pct or 0)*100:+.2f}%) · ",
                             "reason_key": e.get("reason"),
                             "reason_words": words(e.get("reason")),
                             "pnl": pnl})
        return rows[-12:]

    # -- rules ------------------------------------------------------------

    def _alt_rules(self, strat: str, c, t) -> list:
        """Rulebook for the non-ladder strategies, from their own config."""
        common = {
            "title": "The round",
            "rows": [
                ["Length", f"{t(float(c.get('market.window_seconds')))}, on the "
                           "clock at :00 / :15 / :30 / :45"],
                ["Timed from", "Kalshi's own open_time, never a local stopwatch"],
                ["Target price", "Kalshi's published floor_strike for the market"],
                ["BTC price", "Kalshi's CF Benchmarks BRTI feed — the index the "
                              "market settles on"],
                ["Money", f"paper only, starting at "
                          f"${float(c.get('capital.paper_starting_balance_usd')):.2f}"],
            ],
        }
        if strat == "dual_limit":
            d = c.get("dual_limit", {}) or {}
            buy = float(d.get("buy_price", 0.25))
            sell = float(d.get("sell_price", 0.45))
            cancel = float(d.get("cancel_after_elapsed_seconds", 120.0))
            frac = float(d.get("stake_fraction_per_side", 0.06))
            return [common, {
                "title": "How it trades",
                "rows": [
                    ["No trigger", "BTC's distance from target is never consulted. "
                                   "The market decides the round by reaching a "
                                   "price, not by moving a distance."],
                    ["At the open", f"rest a BUY at {buy:.2f} on BOTH up and down"],
                    ["Size", f"{frac * 100:.0f}% of the current balance on each "
                             f"side, so {frac * 200:.0f}% is posted in total — "
                             f"but only one side can ever fill"],
                    ["First fill wins", "whichever side fills becomes the "
                                        "position; the other order is cancelled "
                                        "immediately"],
                    ["Then", f"rest a sell-all at {sell:.2f} for the rest of the "
                             f"round; if the bid reaches it first, cross and take it"],
                    ["If neither fills", f"cancel both at {t(cancel)} elapsed "
                                         f"({t(900 - cancel)} remaining) and sit "
                                         f"the round out"],
                    ["If it never sells", "the contract settles at $1.00 or $0.00 "
                                          "at expiry"],
                    ["Best case", f"buy {buy:.2f} -> sell {sell:.2f} = "
                                  f"{(sell - buy) / buy * 100:+.0f}% before fees"],
                ]}]
        f = c.get("favorite", {}) or {}
        floor = float(f.get("min_price", 0.93))
        obs = float(f.get("observe_seconds", 720.0))
        win = float(f.get("entry_window_seconds", 165.0))
        adverse = float(f.get("max_adverse_usd", 100.0))
        rng = float(f.get("min_range_usd", 40.0))
        gap = float(f.get("min_gap_usd", 0.0))
        stake = float(f.get("stake_usd", 20.0))
        after = float(f.get("stake_after_loss_usd", stake))
        recov = int(f.get("stake_recover_rounds", 2))
        halt_n = c.get("halt.consecutive_losses")
        bal = float(c.get("capital.paper_starting_balance_usd"))

        gates = [
            ["1. Watch", f"the first {t(obs)} is observation only — nothing is "
                         f"bought, the round is just measured"],
            ["2. Must have moved",
             f"the round has to have travelled at least ${rng:.0f} — furthest "
             f"above target plus furthest below"],
            ["3. Not against it",
             f"skipped if BTC ran more than ${adverse:.0f} AGAINST the side "
             f"being bought, or more than ${adverse:.0f} in BOTH directions"],
            ["4. When", f"buys only inside the last {t(win)}"],
            ["5. What", f"whichever side is offered at {floor:.2f} or better"],
        ]
        if gap > 0:
            gates.append(["6. Minimum gap",
                          f"BTC must also be ${gap:.2f} clear of target in that "
                          f"side's favour at the moment of buying"])

        return [
            {"title": "The bet", "rows": [
                ["In one line", f"buy a heavy favourite in the last {t(win)} of "
                                f"the round and hold it to settlement"],
                ["Pays", f"{floor:.2f} -> 1.00 is "
                         f"{(1 - floor) / floor * 100:+.1f}% before fees"],
                ["Costs", "the entire stake — a losing contract settles at $0.00"],
                ["So it needs", f"roughly {floor * 100:.0f}% of its bets to come "
                                f"in just to break even"],
                ["No exit rule", "it never sells. Once bought, the round is "
                                 "decided at settlement and nothing can be done "
                                 "about it."],
            ]},
            {"title": "What has to be true before it buys", "rows": gates},
            {"title": "Money", "rows": [
                ["Stake", f"${stake:.2f} a round"
                          + (f", dropping to ${after:.2f} for {recov} rounds "
                             f"after a loss" if after != stake else "")],
                ["Book", f"paper only, started at ${bal:.2f}"],
                ["Halt", ("OFF for this run — it keeps trading through a losing "
                          "streak on purpose, because how bad those streaks get "
                          "is the number this whole idea rests on")
                         if (halt_n or 0) > 100
                         else f"pauses after {halt_n} losses in a row"],
            ]},
            {"title": "Where the numbers came from", "rows": [
                ["The one loss", "in the historical sample, the only losing round "
                                 "was the quietest one — it travelled $37 in "
                                 "twelve minutes and settled $3.23 the wrong way"],
                ["Why rule 2", f"every winning round travelled $75 or more, so "
                               f"${rng:.0f} sits between them. It is fitted to a "
                               f"single loss, so treat it as a hypothesis under "
                               f"test, not a law."],
                ["Why no gap rule", "requiring BTC to be a set distance clear at "
                                    "the moment of buying was tested and made "
                                    "things worse: waiting for the gap means "
                                    "paying for it, because the price already "
                                    "encodes it"],
            ]},
        ]

    def rules_dict(self) -> dict:
        """The live rulebook, built from config rather than written out by hand.

        Generating it from the same values the strategy reads means the panel
        cannot drift from what the bot actually does — if you change a number
        in config.yaml, this changes with it.
        """
        c = self.state.cfg
        W = float(c.get("market.window_seconds"))
        cut = float(c.get("entry.no_buy_after_elapsed_seconds"))
        gate = float(c.get("trigger.max_elapsed_seconds"))
        trip = c.get("trigger.distance_usd")
        clip = c.get("entry.notional_per_buy_usd")
        ref = c.get("entry.band_reference", "ask")
        adv = c.get("exit.adverse_move")
        fee = c.get("fees")

        def t(sec) -> str:
            sec = int(sec)
            return f"{sec // 60}:{sec % 60:02d}"

        rungs = []
        prev = 0
        for row in c.get("entry.rungs"):
            up_to = row.get("up_to")
            if up_to is None:
                label = f"buys {prev + 1} and beyond"
            elif up_to == prev + 1:
                label = f"buy {up_to}"
            else:
                label = f"buys {prev + 1}–{up_to}"
            rungs.append([label, f"pay between {row['min_price']:.2f} and "
                                f"{row['max_price']:.2f}"])
            prev = up_to if up_to is not None else prev

        ladder = []
        # Chronological: the base rule applies from the first fill, then each
        # step-down in the order the clock reaches it.
        for th in sorted(c.get("exit.thresholds"),
                         key=lambda x: (x["time_remaining_under"] is not None,
                                        -(x["time_remaining_under"] or 0))):
            tr = th["time_remaining_under"]
            when = ("from the first fill" if tr is None
                    else f"from {t(W - tr)} into the round")
            goal = th["min_net_return"]
            goal_txt = ("break even" if goal == 0
                        else "sell at any price" if goal <= -1
                        else "take any profit at all" if 0 < goal < 0.005
                        else f"take {goal * 100:+.0f}% profit" if goal > 0
                        else f"accept up to {abs(goal) * 100:.0f}% loss")
            ladder.append([when, goal_txt])

        strat = c.get("strategy.name", "ladder")
        if strat != "ladder":
            # B and C do not use the trigger/ladder machinery at all, so the
            # generic sections below would describe rules they never consult.
            return {"glossary": rule_help(c),
                    "sections": self._alt_rules(strat, c, t)}

        return {"glossary": rule_help(c), "sections": [
            {"title": "The round",
             "rows": [
                 ["Length", f"{t(W)}, on the clock at :00 / :15 / :30 / :45"],
                 ["Timed from", "Kalshi's own open_time for that market, never "
                                "a local stopwatch"],
                 ["Target price", "read off the market record (floor_strike) and "
                                  "cross-checked against Kalshi's own printed "
                                  "subtitle before trading"],
                 ["BTC price", "Kalshi's CF Benchmarks BRTI feed — the same index "
                               "the market settles on"],
             ]},
            {"title": "Picking a side",
             "rows": [
                 ["Trigger", f"the first moment BTC is ${trip} or more away "
                             f"from the target"],
                 ["Above target", "buy UP (YES)"],
                 ["Below target", "buy DOWN (NO)"],
                 ["Deadline", f"only in the first {t(gate)} of the round — after "
                              f"that the round is skipped entirely"],
                 ["Locked", "the side is final for the round; moves the other way "
                            "are ignored"],
                 ["After the lock", f"the ${trip} stops mattering — price may come "
                                    f"back inside it and buying continues"],
             ]},
            {"title": "Buying",
             "rows": [
                 ["Each buy", f"${clip:.2f} worth — contracts = floor("
                              f"{clip:.0f} ÷ price)"],
                 ["Price checked against", f"the {ref} (what you would actually pay)"],
             ] + rungs + [
                 ["Between buys", f"wait {c.get('entry.cooldown_seconds'):.0f} "
                                  f"seconds"],
                 ["Buys per round", f"{c.get('entry.buy_cap.default')} — counted "
                                    f"across the whole round, not per position"],
                 ["Buying closes", f"{t(cut)} into the round (selling is unaffected)"],
                 ["Order style", f"{c.get('execution.order_type')} — rest at the "
                                 f"near touch for "
                                 f"{c.get('execution.limit_timeout_seconds'):.0f}s, "
                                 f"then cross if unfilled"],
             ]},
            {"title": "Selling",
             "rows": [
                 ["Any time", "no minimum hold — checked ~20x a second from the "
                              "first fill"],
                 ["Takes the gap", "sells at the going bid, so if it jumps past the "
                                   "goal you get the jump, not the goal"],
                 ["Profit is", "net return on cash deployed, after entry AND exit "
                               "fees"],
             ] + ladder + [
                 ["Clear the lot", (f"as soon as the most expensive rung is up "
                                    f"{c.get('exit.sell_all_when_dearest')['min_net_return']*100:.0f}%, "
                                    f"sell the whole position — every cheaper "
                                    f"rung is up more by then")
                                   if (c.get("exit.sell_all_when_dearest") or {}).get("enabled")
                                   else "off"],
                 ["Sweeping", (f"when one rung hits the goal, rungs bought "
                               f"within {c.get('exit.lot_sweep')['within_price']:.2f} "
                               f"of it — or already within "
                               f"{c.get('exit.lot_sweep')['within_return_fraction']*100:.0f}% "
                               f"of the goal — are sold too, but only if they "
                               f"are in profit")
                              if (c.get("exit.lot_sweep") or {}).get("enabled")
                              else "off"],
                 ["Sell then re-buy", ("allowed — up to "
                                       f"{c.get('entry.max_cycles_per_round')} round "
                                       "trips, while buys remain")
                                      if c.get("entry.allow_reentry") else "off"],
                 ["Last 10 seconds", f"forced out if BTC is more than "
                                     f"${c.get('exit.forced_exit.distance_usd')} "
                                     f"past the target"],
             ]},
            {"title": "Safety",
             "rows": [
                 ["Adverse move", f"if BTC goes ${adv['distance_usd']:.0f} the WRONG "
                                  f"side of the target after "
                                  f"{t(adv.get('after_elapsed_seconds', 0))}, aim "
                                  f"for break even (never a loss) and stop buying"],
                 ["Most at risk", f"{c.get('capital.max_deployed_fraction') * 100:.0f}%"
                                  f" of the current balance at any moment"],
                 ["Per round", f"at most {c.get('entry.buy_cap.default')} × "
                               f"${clip:.0f}"],
                 ["Stop trading", f"{c.get('halt.consecutive_losses')} losing rounds "
                                  f"in a row, or {c.get('halt.rolling_losses')} of "
                                  f"the last {c.get('halt.rolling_window_count')}"],
                 ["Scale up", f"after {c.get('scaling.wins_to_scale_up')} straight "
                              f"wins, buys per round go to "
                              f"{c.get('entry.buy_cap.scaled')}; any loss resets it"],
                 ["Mode", "LIVE — real money" if c.live_trading
                          else "PAPER — simulated against the real book, "
                               "no real orders"],
             ]},
            {"title": "Fees (Kalshi's, modelled exactly)",
             "rows": [
                 ["Taker", f"ceil({fee['taker_rate']} × price × (1−price) × "
                           f"contracts × 100) ÷ 100"],
                 ["Maker", f"{fee['maker_share_of_taker'] * 100:.0f}% of the taker fee"],
                 ["Charged", "on the way in and the way out; both are in every "
                             "profit number shown"],
                 ["Worth knowing", "the fee peaks at 50¢, so a round trip costs "
                                   "~5% at 63¢ but ~10% at 30¢"],
             ]},
        ]}

    # -- receipt ----------------------------------------------------------

    def receipt(self, window_id: str) -> str:
        """A full account of one round: what it did, when, and why.

        Two views of the same round. The TIMELINE is every action in the
        order it happened, stamped with both the wall clock and the round
        clock, so a decision can be read against how much time was left. The
        sections after it are the totals.
        """
        path = Path(self.state.cfg.get("logging.window_log_path"))
        rec = None
        if path.exists():
            for line in path.read_text().splitlines():
                if not line.strip():
                    continue
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if r.get("window_id") == window_id:
                    rec = r            # last match wins
        if rec is None:
            return (f"No completed round found with id {window_id!r}.\n"
                    f"Receipts are written when a round closes; a round still "
                    f"in flight has no receipt yet.\n")

        L: list[str] = []
        def add(x=""): L.append(x)

        pct = lambda v: "—" if v is None else f"{v * 100:+.2f}%"
        usd = lambda v: "—" if v is None else f"${v:,.2f}"
        prc = lambda v: "—" if v is None else f"{v:.3f}"

        def rc(sec) -> str:
            """Round clock: how far into the 15:00 an action happened."""
            if sec is None:
                return "  —  "
            sec = int(sec)
            sign = "-" if sec < 0 else "+"
            sec = abs(sec)
            return f"{sign}{sec // 60}:{sec % 60:02d}"

        def left(sec) -> str:
            if sec is None:
                return "—"
            sec = max(0, int(sec))
            return f"{sec // 60}:{sec % 60:02d} left"

        tzl = tz_abbrev(rec.get("open_time"))
        opened = to_local(rec.get("open_time"))
        strat = self.state.cfg.get("strategy.name", "ladder")
        W = float(self.state.cfg.get("market.window_seconds", 900))

        line = "=" * 70
        add(line)
        add("  KXBTC15M ROUND RECEIPT")
        add(line)
        add()
        add("  ROUND")
        add(f"    market       {rec.get('window_id')}")
        add(f"    day          "
            f"{opened.strftime('%A, %d %b %Y') if opened else '—'}")
        add(f"    opened       {local_hms(rec.get('open_time'))} {tzl}"
            f"      ({rec.get('open_time')})")
        add(f"    closed       {local_hms(rec.get('close_time'))} {tzl}"
            f"      ({rec.get('close_time')})")
        add(f"    length       {int(W) // 60}:{int(W) % 60:02d}")
        add(f"    target       {usd(rec.get('target_price'))}   "
            f"(Kalshi floor_strike — the price it settles against)")
        add(f"    strategy     {STRATEGY_BLURB.get(strat, strat)}")
        add(f"    mode         PAPER — simulated fills against the real book")
        add()

        # ---------------- timeline ----------------------------------------
        # (when, tie-break, lines). Several things land on the same second —
        # the entry decision and the buy it causes, the settlement and the
        # bell — so equal times are ordered by what logically comes first.
        ev: list[tuple[float, int, list[str]]] = []
        P_OPEN, P_SIGNAL, P_ORDER, P_SELL, P_SETTLE, P_CLOSE = 0, 1, 2, 3, 4, 5

        def push(sec, prio, *lines):
            ev.append((sec if sec is not None else 0.0, prio, list(lines)))

        push(0.0, P_OPEN, "round opened — 15:00 on the clock")

        if rec.get("trigger_fired"):
            d = rec.get("trigger_distance")
            side = str(rec.get("direction") or "").upper()
            if strat == "ladder":
                push(rec.get("trigger_elapsed_s"), P_SIGNAL,
                     f"TRIGGER — BTC {rec.get('trigger_btc_price'):,.2f} is "
                     f"${abs(d):,.2f} {'above' if (d or 0) > 0 else 'below'} "
                     f"target",
                     f"  locks the round to {side}; direction never changes "
                     f"after this")
            elif strat == "dual_limit":
                push(rec.get("trigger_elapsed_s"), P_SIGNAL,
                     f"FILLED — the {side} limit was reached first",
                     f"  the other side's order is cancelled now")
            else:
                push(rec.get("trigger_elapsed_s"), P_SIGNAL,
                     f"ENTRY — {side} offered at the favourite price",
                     f"  BTC {rec.get('trigger_btc_price'):,.2f}, "
                     f"${abs(d):,.2f} "
                     f"{'above' if (d or 0) > 0 else 'below'} target")
        elif (rec.get("no_trigger_reason")
              and rec["no_trigger_reason"] != "no_trigger_in_this_strategy"):
            push(None, P_SIGNAL, f"no entry — {rec.get('no_trigger_reason')}")

        for n in rec.get("notes") or []:
            if n.startswith("confirm@"):
                bits = n.split(":")
                held = len(bits) > 1 and bits[1] == "held"
                # The confirm happens `confirm_after_seconds` AFTER the touch,
                # not at it — stamping it at the trigger hid the whole wait.
                wait = float(self.state.cfg.get(
                    "trigger.confirm_after_seconds", 0.0) or 0.0)
                push((rec.get("trigger_elapsed_s") or 0) + wait, P_SIGNAL,
                     f"CONFIRM — {'still the same side' if held else 'FLIPPED'}"
                     f" after waiting {wait:.0f}s"
                     + (f" (BTC {bits[2]} vs target)" if len(bits) > 2 else ""),
                     "  " + ("cleared to buy" if held
                             else "round abandoned — no position taken"))

        if rec.get("adverse_move_fired"):
            push(rec.get("adverse_move_elapsed_s"), P_SIGNAL,
                 f"ADVERSE MOVE — BTC ran "
                 f"${abs(rec.get('adverse_move_distance') or 0):,.2f} the "
                 f"wrong way",
                 "  stops further buying and drops the goal to breakeven")

        for u in rec.get("unfilled_orders") or []:
            k = u.get("kind", "")
            if not k.startswith("resting_buy"):
                continue
            qty = u.get("contracts")
            way = str(u.get("direction", "")).upper()
            at = u.get("posted_price")
            # Placing it and giving up on it are two different moments, and
            # the gap between them is the whole point of the rule.
            push(0.0, P_ORDER,
                 f"ORDER — rest a buy for {qty} {way} @ {at:.3f}",
                 f"  waits here until the market comes to it")
            if k == "resting_buy_expired":
                push(u.get("rested_s"), P_ORDER,
                     f"CANCEL — {qty} {way} @ {at:.3f} never filled",
                     f"  the market never traded down to {at:.3f}; "
                     f"round sat out")
            else:
                push(rec.get("trigger_elapsed_s"), P_ORDER,
                     f"CANCEL — {qty} {way} @ {at:.3f} pulled",
                     f"  the other side filled first, so this one is no "
                     f"longer wanted")

        buys = rec.get("buys") or []
        for i, b in enumerate(buys, 1):
            fills = b.get("fills") or []
            liq = ("maker" if fills and fills[0].get("liquidity") == "maker"
                   else "taker")
            bk = b.get("book") or {}
            top = ""
            if bk.get("yes_top") and bk.get("no_top"):
                top = (f"  book then: UP {bk['yes_top'][0][0]:.3f} / "
                       f"DOWN {bk['no_top'][0][0]:.3f}")
            lines = [
                f"BUY {i}/{rec.get('buy_cap')} — {b.get('filled_contracts')} "
                f"{str(rec.get('direction') or '').upper()} @ "
                f"{(b.get('avg_fill_price') or 0):.3f}   "
                f"cost {usd((b.get('avg_fill_price') or 0) * (b.get('filled_contracts') or 0))}"
                f"   fee {usd(b.get('fees'))}   ({liq})",
            ]
            la = b.get("limit_attempt")
            if la:
                lines.append(f"  wanted {la['posted_price']:.3f}, rested "
                             f"{la['rested_s']:.1f}s unfilled, then crossed "
                             f"the spread to get filled")
            if top:
                lines.append(top)
            push(b.get("elapsed_s"), P_ORDER, *lines)

        for e in rec.get("exits") or []:
            if e.get("reason") == "expired_settled":
                won = e.get("won")
                push(e.get("elapsed_s"), P_SETTLE,
                     f"SETTLED — {e.get('contracts')} contracts expired at "
                     f"${(e.get('settle_value') or 0):.2f}",
                     f"  BTC {e.get('btc_at_expiry')} vs target "
                     f"{e.get('target')}  ->  "
                     f"{'WON' if won else 'LOST' if won is not None else '—'}",
                     f"  no exit fee is charged at settlement")
            else:
                lot = e.get("lot")
                which = (f" [the clip bought @ {lot['avg_price']:.3f}]"
                         if lot else " [whole position]")
                push(e.get("elapsed_s"), P_SELL,
                     f"SELL — {e.get('filled_contracts')} @ "
                     f"{(e.get('avg_fill_price') or 0):.3f}"
                     f"   into a {prc(e.get('bid_at_decision'))} bid"
                     f"   fee {usd(e.get('fees'))}",
                     f"  {pct(e.get('net_return_at_decision'))} net on that "
                     f"clip{which}",
                     f"  rule that fired: "
                     f"{str(e.get('reason') or '').replace('_', ' ')}"
                     f"   ({left(e.get('remaining_s'))})")

        push(W, P_CLOSE, "round closed")

        add("  TIMELINE   (wall clock · round clock · what happened)")
        add()
        # Events a fraction of a second apart are the same moment to a reader,
        # so whole seconds decide first and the tie-break decides within them.
        for sec, _prio, lines in sorted(
                ev, key=lambda x: (round(x[0]), x[1], x[0])):
            stamp = ""
            if opened is not None and sec is not None:
                stamp = (opened + timedelta(seconds=sec)).strftime("%H:%M:%S")
            add(f"    {stamp:>8}  {rc(sec):>6}   {lines[0]}")
            for extra in lines[1:]:
                add(f"                       {extra}")
        add()

        # ---------------- bought -------------------------------------------
        tc = sum(b.get("filled_contracts") or 0 for b in buys)
        add(f"  BOUGHT   ({len(buys)} "
            f"{'order' if len(buys) == 1 else 'orders'}, {tc} contracts, "
            f"{usd(rec.get('capital_deployed'))})")
        if not buys:
            add(f"    nothing — {rec.get('no_entry_reason') or 'no reason recorded'}")
            for u in rec.get("unfilled_orders") or []:
                if u.get("kind", "").startswith("resting_buy"):
                    add(f"      rested {u.get('contracts')} "
                        f"{str(u.get('direction', '')).upper()} @ "
                        f"{u.get('posted_price'):.3f} — {u.get('outcome')}")
        else:
            add(f"    {'clock':>8} {'round':>6}  {'qty':>4}  {'price':>6}"
                f"  {'cost':>8}  {'fee':>6}  fill")
            for b in buys:
                c = b.get("filled_contracts") or 0
                pr = b.get("avg_fill_price") or 0
                fills = b.get("fills") or []
                liq = ("maker" if fills and fills[0].get("liquidity") == "maker"
                       else "taker")
                add(f"    {local_hms(b.get('timestamp')):>8} "
                    f"{rc(b.get('elapsed_s')):>6}  {c:>4}  {pr:>6.3f}"
                    f"  {usd(pr * c):>8}  {usd(b.get('fees')):>6}  {liq}")
            add(f"    average buy price   "
                f"{prc(rec.get('avg_buy_price'))} per contract")
        add()

        # ---------------- price around the buy ------------------------------
        snap = rec.get("snapshots") or {}
        if snap:
            add("  PRICE AROUND THE BUY")
            def row(label, d):
                if not d:
                    add(f"    {label:<14} —")
                    return
                btc = d.get("btc")
                g = d.get("gap_from_target")
                ask = d.get("ask")
                bid = d.get("bid")
                bits = []
                if btc is not None:
                    bits.append(f"BTC {btc:,.2f}")
                if g is not None:
                    bits.append(f"({g:+.2f} vs target)")
                if ask is not None:
                    bits.append(f"ask {ask:.3f}")
                if bid is not None:
                    bits.append(f"bid {bid:.3f}")
                if d.get("filled_at") is not None:
                    bits.append(f"FILLED {d['filled_at']:.3f}")
                add(f"    {label:<14} {'   '.join(bits)}")
            row("5s before", snap.get("before_5s"))
            row("at the buy", snap.get("at_buy"))
            row("5s after", snap.get("after_5s"))
            b, a = snap.get("before_5s") or {}, snap.get("after_5s") or {}
            gb, ga = b.get("gap_from_target"), a.get("gap_from_target")
            if gb is not None and ga is not None:
                add(f"    moved          {ga - gb:+.2f} across those ten seconds")
            add()

        # ---------------- sold / final price -------------------------------
        exits = rec.get("exits") or []
        sells = [e for e in exits if e.get("reason") != "expired_settled"]
        settle = [e for e in exits if e.get("reason") == "expired_settled"]
        sc = sum(e.get("filled_contracts") or 0 for e in sells)
        add(f"  SOLD   ({len(sells)} "
            f"{'order' if len(sells) == 1 else 'orders'}, {sc} contracts)")
        if not sells:
            add("    nothing was sold on the market")
        else:
            add(f"    {'clock':>8} {'round':>6}  {'qty':>4}  {'price':>6}"
                f"  {'proceeds':>9}  {'fee':>6}  net on that clip")
            for e in sells:
                c = e.get("filled_contracts") or 0
                pr = e.get("avg_fill_price") or 0
                add(f"    {local_hms(e.get('timestamp')):>8} "
                    f"{rc(e.get('elapsed_s')):>6}  {c:>4}  {pr:>6.3f}"
                    f"  {usd(pr * c):>9}  {usd(e.get('fees')):>6}"
                    f"  {pct(e.get('net_return_at_decision'))}")
            add(f"    average sell price  "
                f"{prc(rec.get('avg_sell_price'))} per contract")
        if settle:
            e = settle[0]
            won = e.get("won")
            add()
            add(f"  FINAL PRICE   (what was still held at the bell)")
            add(f"    {e.get('contracts')} contracts settled at "
                f"${(e.get('settle_value') or 0):.2f} each")
            add(f"    BTC finished {e.get('btc_at_expiry')} against a target "
                f"of {e.get('target')}")
            marg = (None if e.get("btc_at_expiry") is None
                    or e.get("target") is None
                    else e["btc_at_expiry"] - e["target"])
            if marg is not None:
                add(f"    that is {usd(abs(marg))} "
                    f"{'above' if marg > 0 else 'below'} target — "
                    f"{str(rec.get('direction') or '').upper()} "
                    f"{'WON' if won else 'LOST'}")
        add()

        # ---------------- why ----------------------------------------------
        sold_out = bool(sells)
        held_by_design = (strat == "favorite")
        if buys and held_by_design:
            add("  WHY IT HELD")
            add("    by design — this strategy has no exit rule at all. It")
            add("    rides the contract to settlement at $1.00 or $0.00.")
            add()
        elif buys and not sold_out:
            add("  WHY IT DIDN'T SELL")
            bn = rec.get("best_net_return")
            if bn is None:
                add("    no bid was ever available to price the position")
            else:
                add(f"    best bid seen while holding : "
                    f"{prc(rec.get('best_bid_seen'))}")
                add(f"    best profit reached         : {pct(bn)} "
                    f"(after fees) at "
                    f"{rc(rec.get('best_net_elapsed_s'))} into the round")
                need = rec.get("best_net_needed")
                add(f"    the goal at that moment     : {pct(need)}")
                if need is not None:
                    add(f"    it came up short by         : "
                        f"{(need - bn) * 100:.2f} points")
            add()
        elif buys and sold_out:
            add("  WHY IT SOLD")
            for e in sells:
                add(f"    {rc(e.get('elapsed_s')):>6}  "
                    f"{str(e.get('reason') or '').replace('_', ' ')} — "
                    f"{pct(e.get('net_return_at_decision'))} net with "
                    f"{left(e.get('remaining_s'))}")
            if settle:
                add(f"    the rest was still held at the bell and settled")
            add()

        # ---------------- result -------------------------------------------
        ab, as_ = rec.get("avg_buy_price"), rec.get("avg_sell_price")
        sp = rec.get("avg_spread")
        add("  RESULT")
        add(f"    contracts        {rec.get('contracts_held')} bought, "
            f"{rec.get('contracts_sold')} closed out")
        add(f"    average buy      {prc(ab)} per contract")
        add(f"    average sell     {prc(as_)} per contract")
        add(f"    spread           {'—' if sp is None else f'{sp:+.3f}'} "
            f"per contract (before fees)")
        add(f"    entry cost       {usd(rec.get('capital_deployed'))}")
        add(f"    entry fees       {usd(rec.get('entry_fees'))}")
        add(f"    exit fees        {usd(rec.get('exit_fees'))}")
        add(f"    gross P&L        {usd(rec.get('gross_pnl'))}")
        add(f"    NET P&L          {usd(rec.get('net_pnl'))}   "
            f"({pct(rec.get('net_return'))})")
        add(f"    balance after    {usd(rec.get('balance_after'))}")
        if rec.get("notes"):
            add(f"    notes            {', '.join(rec['notes'])}")
        add(line)
        return "\n".join(L) + "\n"

    # -- server -----------------------------------------------------------

    async def _handle(self, reader: asyncio.StreamReader,
                      writer: asyncio.StreamWriter) -> None:
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=5)
            if not line:
                return
            parts = line.decode("latin-1").split()
            path = parts[1] if len(parts) > 1 else "/"
            while True:  # drain headers
                h = await asyncio.wait_for(reader.readline(), timeout=5)
                if h in (b"\r\n", b"\n", b""):
                    break
            if path.startswith("/trades"):
                tp = Path(self.state.cfg.get("logging.trade_log_path",
                                             "./logs/trades.log"))
                if tp.exists():
                    lines = tp.read_text(encoding="utf-8").splitlines()
                    text = "\n".join(lines[-500:]) + "\n"
                else:
                    text = ("No fills logged yet for this run.\n"
                            "The ledger is written as they happen.\n")
                body = text.encode()
                writer.write(
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: text/plain; charset=utf-8\r\n"
                    + f"Content-Length: {len(body)}\r\n".encode()
                    + b"Cache-Control: no-store\r\nConnection: close\r\n\r\n"
                    + body)
                await writer.drain()
                return
            if path.startswith("/receipt"):
                from urllib.parse import parse_qs, urlparse
                q = parse_qs(urlparse(path).query)
                wid = (q.get("id") or [""])[0]
                body = self.receipt(wid).encode()
                safe = "".join(ch for ch in wid if ch.isalnum() or ch in "-_")
                writer.write(
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: text/plain; charset=utf-8\r\n"
                    + f'Content-Disposition: attachment; filename="receipt-{safe}.txt"\r\n'.encode()
                    + f"Content-Length: {len(body)}\r\n".encode()
                    + b"Cache-Control: no-store\r\nConnection: close\r\n\r\n"
                    + body)
                await writer.drain()
                return
            elif path.startswith("/rules"):
                body = json.dumps(self.rules_dict(), default=str).encode()
                ctype = "application/json"
            elif path.startswith("/reset"):
                # Only clears the cached counters. The JSONL logs are the
                # permanent record and are deliberately left untouched.
                if self.on_reset is None:
                    payload = {"ok": False, "error": "reset not available"}
                elif self.state.trader is not None:
                    payload = {"ok": False,
                               "error": "a round is in flight — wait for it to "
                                        "close so its result is not lost"}
                else:
                    before = self.on_reset()
                    payload = {"ok": True, "cleared": before}
                body = json.dumps(payload, default=str).encode()
                ctype = "application/json"
            elif path.startswith("/state"):
                body = json.dumps(self.state_dict(), default=str).encode()
                ctype = "application/json"
            else:
                body = PAGE.encode()
                ctype = "text/html; charset=utf-8"
            writer.write(
                b"HTTP/1.1 200 OK\r\n"
                + f"Content-Type: {ctype}\r\n".encode()
                + f"Content-Length: {len(body)}\r\n".encode()
                + b"Cache-Control: no-store\r\nConnection: close\r\n\r\n"
                + body)
            await writer.drain()
        except (asyncio.TimeoutError, ConnectionResetError, BrokenPipeError):
            pass
        except Exception:  # noqa: BLE001 - the UI must never take the bot down
            # Return the error rather than an empty body: a silent 0-byte
            # response looks like a dead server and hides the real fault.
            log.warning("web request failed", exc_info=True)
            try:
                err = json.dumps({"error": traceback.format_exc()[-800:]}).encode()
                writer.write(b"HTTP/1.1 500 Internal Server Error\r\n"
                             b"Content-Type: application/json\r\n"
                             + f"Content-Length: {len(err)}\r\n".encode()
                             + b"Connection: close\r\n\r\n" + err)
                await writer.drain()
            except Exception:  # noqa: BLE001
                pass
        finally:
            try:
                writer.close()
            except Exception:  # noqa: BLE001
                pass

    async def run(self) -> None:
        try:
            self._server = await asyncio.start_server(
                self._handle, self.host, self.port)
        except OSError as exc:
            log.error("web dashboard could not bind %s:%s (%s) — is another "
                      "copy running?", self.host, self.port, exc)
            return
        log.info("web dashboard: http://%s:%d", self.host, self.port)
        async with self._server:
            await self._server.serve_forever()

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()


PAGE = r"""<!doctype html><html><head><meta charset="utf-8">
<title>KXBTC15M</title>
<style>
:root{--bg:#12151a;--panel:#171b22;--line:#242a34;--txt:#d6dae1;--dim:#7c8698;
--amber:#f0a53a;--green:#3ddc91;--red:#ff6b6b;--cyan:#5ad2e0;--blue:#6aa9ff;--mag:#c39ce8;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);
font:13px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
.wrap{max-width:1080px;margin:0 auto;padding:14px}
.top{display:flex;justify-content:space-between;align-items:center;gap:10px;
border-bottom:1px solid var(--line);padding-bottom:8px;margin-bottom:10px;flex-wrap:wrap}
.brand{font-weight:700;color:var(--amber);letter-spacing:.06em}
.pill{border:1px solid var(--line);border-radius:3px;padding:1px 7px;font-size:11px;color:var(--dim)}
.pill.ok{color:var(--green);border-color:#2a4a3c}.pill.bad{color:var(--red);border-color:#4a2a2a}
.pill.live{color:var(--red);border-color:#4a2a2a}
h2{font-size:10px;letter-spacing:.16em;color:var(--dim);text-transform:uppercase;
margin:0 0 6px;font-weight:600}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:4px;
padding:9px 11px;margin-bottom:9px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
@media(max-width:760px){.grid{grid-template-columns:1fr}}
.row{display:flex;justify-content:space-between;gap:12px;padding:1px 0}
.k{color:var(--dim)}.v{font-variant-numeric:tabular-nums}
.big{font-size:20px;font-weight:700;font-variant-numeric:tabular-nums}
.g{color:var(--green)}.r{color:var(--red)}.a{color:var(--amber)}.c{color:var(--cyan)}
.d{color:var(--dim)}.b{color:var(--blue)}.m{color:var(--mag)}
table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}
td{padding:2px 5px 2px 0;vertical-align:top}
td.t{color:var(--dim);width:62px}td.tag{width:64px;font-weight:600}
.bar{height:5px;background:#232833;border-radius:3px;overflow:hidden;margin-top:5px}
.bar > i{display:block;height:100%;background:var(--amber)}
.log{font-size:11px;color:var(--dim);max-height:150px;overflow:auto}
.log b{color:var(--txt);font-weight:400}
.stale{color:var(--red);font-weight:700}
.muted{color:var(--dim);font-style:italic}
button{background:#1d222b;color:var(--dim);border:1px solid var(--line);border-radius:3px;
padding:2px 9px;font:inherit;font-size:11px;cursor:pointer;margin-left:8px}
button:hover{color:var(--red);border-color:#4a2a2a}
button:disabled{opacity:.4;cursor:not-allowed}
a.dl{color:var(--dim);border:1px solid var(--line);border-radius:3px;padding:0 5px;
font-size:10px;text-decoration:none;margin-left:6px;white-space:nowrap}
a.dl:hover{color:var(--amber);border-color:#4a3a1e}
.why{color:var(--cyan);border-bottom:1px dotted var(--cyan);cursor:help}
.why:hover{color:var(--amber);border-color:var(--amber)}
#pop{position:fixed;inset:0;background:rgba(6,8,11,.72);display:none;z-index:60;
padding:60px 14px;overflow:auto}
#pop.on{display:block}
#popbox{max-width:520px;margin:0 auto;background:var(--panel);
border:1px solid var(--line);border-radius:5px;padding:16px 18px;
box-shadow:0 14px 44px rgba(0,0,0,.6)}
#popbox h3{margin:0 0 8px;font-size:14px;color:var(--amber)}
#popbox p{margin:0 0 12px;color:var(--txt);line-height:1.6}
#ovl{position:fixed;inset:0;background:rgba(6,8,11,.78);display:none;z-index:50;
padding:26px 14px;overflow:auto}
#ovl.on{display:block}
#modal{max-width:760px;margin:0 auto;background:var(--panel);border:1px solid var(--line);
border-radius:5px;padding:16px 18px;box-shadow:0 14px 44px rgba(0,0,0,.6)}
#modal h3{margin:0;font-size:14px;color:var(--amber);letter-spacing:.06em}
#modal h4{margin:16px 0 5px;font-size:10px;letter-spacing:.16em;color:var(--dim);
text-transform:uppercase;border-bottom:1px solid var(--line);padding-bottom:4px}
#modal table{width:100%}
#modal td{padding:3px 8px 3px 0;vertical-align:top}
#modal td.rk{color:var(--dim);width:190px;white-space:nowrap}
#modal td.rv{color:var(--txt)}
.mhead{display:flex;justify-content:space-between;align-items:center;gap:10px}
</style></head><body><div class="wrap">
<div class="top">
  <div><span class="brand">KXBTC15M</span> <span id="mode" class="pill"></span>
  <span id="mkt" class="pill">MKT</span> <span id="idx" class="pill">IDX</span></div>
  <div class="d"><span id="conn"></span> · up <span id="up"></span> · <span id="now"></span>
  <button id="rulesbtn" title="Every buying and selling rule the bot is running right now">rules</button>
  <button id="reset" title="Clear cached balance, win/loss streaks and halt state. Log files are kept.">clear cache</button></div>
</div>

<div class="panel">
  <div class="row" style="align-items:baseline">
    <div><span class="k">BTC NOW</span> <span id="btc" class="big"></span>
         <span class="k" style="margin-left:16px">TARGET</span> <span id="tgt" class="big"></span>
         <span class="k" style="margin-left:16px">DIFF</span> <span id="diff" class="big"></span></div>
    <div class="d">last tick <span id="age"></span> · <span id="ticks"></span> ticks</div></div>
  <div class="d" id="tgthint"></div>
</div>

<div class="panel"><h2>Round</h2><div id="win"></div><div class="bar"><i id="prog" style="width:0"></i></div></div>

<div class="grid">
  <div class="panel"><h2>Book</h2><div id="book"></div></div>
  <div class="panel"><h2>Position</h2><div id="pos"></div></div>
</div>

<div class="panel"><h2>Activity — this round only</h2><table id="act"></table></div>

<div class="panel"><h2>Account — running total, kept across restarts</h2><div id="acct"></div></div>

<div class="panel"><h2>Recent rounds</h2><table id="recent"></table></div>

<div class="panel"><h2>Log</h2><div id="log" class="log"></div></div>
</div>

<div id="pop"><div id="popbox">
  <h3 id="poptitle"></h3><p id="poptext"></p>
  <button id="popclose">close</button>
</div></div>

<div id="ovl"><div id="modal">
  <div class="mhead"><h3>TRADING RULES</h3>
    <div><span class="d" id="rulesmode"></span>
    <button id="rulesclose">close</button></div></div>
  <div class="d" style="margin-top:4px">Read live from the running bot's config — this is what it is actually doing, not a description of it.</div>
  <div id="rulesbody"></div>
</div></div>

<script>
const $=id=>document.getElementById(id);
// Times are sent as UTC ISO and rendered in the display timezone the server
// reports, so the screen matches how Kalshi names its rounds (Eastern).
let TZ='America/New_York', TZL='ET';
const hms=iso=>{ if(!iso) return ''; const d=new Date(iso);
  return isNaN(d)?'':d.toLocaleTimeString('en-US',{timeZone:TZ,hour12:false}); };
const hm=iso=>{ if(!iso) return ''; const d=new Date(iso);
  return isNaN(d)?'':d.toLocaleTimeString('en-US',{timeZone:TZ,hour12:false,
    hour:'2-digit',minute:'2-digit'}); };
const money=v=>(v==null?'—':(v<0?'-$':'$')+Math.abs(v).toFixed(2));
const pct=v=>v==null?'—':(v>0?'+':'')+(v*100).toFixed(2)+'%';
const num=(v,d=2)=>v==null?'—':v.toLocaleString(undefined,{minimumFractionDigits:d,maximumFractionDigits:d});
const mmss=s=>{if(s==null)return'—';const n=Math.abs(Math.round(s));
  return (s<0?'-':'')+String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0')};
const cls=v=>v==null?'':(v>=0?'g':'r');
let misses=0;

function render(d){
  $('mode').textContent=d.mode; $('mode').className='pill '+(d.mode==='LIVE'?'live':'ok');
  $('rulesmode').textContent=(d.profile_label||'')+' · '+(d.mode==='LIVE'?'LIVE — real money':'paper mode');
  $('mkt').className='pill '+(d.ws_market?'ok':'bad');
  $('idx').className='pill '+(d.ws_index?'ok':'bad');
  $('up').textContent=mmss(d.up_seconds);
  TZ=d.tz||TZ; TZL=d.tz_label||TZL;
  $('now').textContent=hms(d.now)+' '+TZL;

  const f=d.feed, stale=f.age_s!=null&&f.age_s>f.stale_after;
  $('btc').textContent=f.price?num(f.price):'—';
  $('tgt').textContent=f.target?num(f.target):'—';
  if(f.delta==null){ $('diff').textContent='—'; $('diff').className='big'; $('tgthint').textContent=''; }
  else{
    $('diff').textContent=(f.delta>=0?'+':'')+num(f.delta);
    $('diff').className='big '+(f.delta>=0?'g':'r');
    const trip=d.rules.trigger_usd, hit=Math.abs(f.delta)>=trip;
    $('tgthint').innerHTML= hit
      ? 'BTC is <b class="'+(f.delta>=0?'g':'r')+'">'+(f.delta>=0?'ABOVE':'BELOW')+'</b> target by more than $'+trip+
        ' → this round trades <b class="'+(f.delta>=0?'g':'r')+'">'+(f.delta>=0?'UP':'DOWN')+'</b>'
      : 'needs $'+trip+' away from target to pick a side — currently $'+Math.abs(f.delta).toFixed(2)+' away';
  }
  $('age').innerHTML=f.age_s==null?'—':(stale?'<span class="stale">STALE '+f.age_s+'s</span>':f.age_s+'s ago');
  $('ticks').textContent=(f.ticks||0).toLocaleString();

  const w=d.window,o=d.observing;
  if(w){
    const gate=d.rules.gate_s, cut=d.rules.buy_cutoff_s;
    let h='<div class="row"><div class="c">'+w.ticker+'</div><div>';
    h+='<span class="k">T-</span><b class="'+(w.remaining>240?'g':w.remaining>60?'a':'r')+'">'+mmss(w.remaining)+'</b>';
    h+=' <span class="k">elapsed</span> '+mmss(w.elapsed)+'</div></div>';
    if(w.cycle>1) h+='<div class="row"><div class="a">round trip '+w.cycle+' of '+w.max_cycles+
       ' <span class="d">— sold once already, re-armed</span></div><div></div></div>';
    h+='<div class="row"><div><span class="k">TARGET</span> '+num(w.target)+
       ' &nbsp;<span class="k">Δ</span> <b class="'+(f.price&&f.price>w.target?'g':'r')+'">'+
       (f.price?((f.price-w.target>=0?'+':'')+num(f.price-w.target)):'—')+'</b></div>';
    h+='<div class="d">gate '+mmss(gate)+' · buys close '+mmss(cut)+'</div></div>';
    if(w.trigger_fired){
      h+='<div class="row"><div><b class="'+(w.direction==='up'?'g':'r')+'">▶ '+w.direction.toUpperCase()+
         '</b> <span class="k">('+(w.side||'').toUpperCase()+') locked</span> <b>'+hms(w.trigger_time)+'</b>'+
         ' <span class="k">'+TZL+'</span> <span class="d">(+'+w.trigger_elapsed.toFixed(2)+'s into the round)</span>'+
         ' <span class="k">BTC</span> '+num(w.trigger_btc)+' <span class="k">Δ</span> '+
         (w.trigger_distance>=0?'+':'')+num(w.trigger_distance)+'</div>'+
         '<div class="d">direction final</div></div>';
      if(w.adverse) h+='<div class="row"><div class="r"><b>■ ADVERSE MOVE</b> BTC '+num(w.adverse_btc)+
         ' is '+(w.adverse_distance>=0?'+':'')+num(w.adverse_distance)+' vs target</div>'+
         '<div class="a">no more buys · exit → breakeven</div></div>';
      if(!w.buying_allowed) h+='<div class="row"><div class="a">buys closed: '+w.buying_blocked_why+'</div><div></div></div>';
    } else if(w.no_trigger_reason){
      h+='<div class="a">✕ no trigger — '+w.no_trigger_reason+'</div>';
    } else {
      h+='<div class="row"><div class="d">armed, watching for ±$'+d.rules.trigger_usd+'…</div>'+
         '<div class="d">closest '+num(w.peak_distance)+'</div></div>';
    }
    $('win').innerHTML=h;
    $('prog').style.width=Math.min(100,100*w.elapsed/(w.elapsed+Math.max(w.remaining,0)))+'%';
  } else if(o){
    $('win').innerHTML='<div class="row"><div><span class="k">observing</span> <span class="d">'+o.ticker+
      '</span> &nbsp;<span class="k">TARGET</span> '+num(o.target)+' &nbsp;<span class="k">Δ</span> <b class="'+
      (o.delta>=0?'g':'r')+'">'+(o.delta>=0?'+':'')+num(o.delta)+'</b></div><div class="a">next round '+
      ((d.next_open||'').slice(11,16))+'Z</div></div>'+
      '<div class="muted">not trading this one — the trigger only counts in a round\'s first '+mmss(d.rules.gate_s)+'</div>';
    $('prog').style.width='0';
  } else {
    $('win').innerHTML='<div class="d">waiting for the next round'+(d.next_open?' — '+hm(d.next_open)+' '+TZL:'')+'…</div>';
    $('prog').style.width='0';
  }

  const b=d.book;
  $('book').innerHTML=!b?'<div class="d">no book</div>':
    '<div class="row"><div><span class="'+(b.locked==='yes'?'a':'k')+'">'+(b.locked==='yes'?'▸ ':'')+
    'UP/YES</span> <span class="k">bid</span> <span class="g">'+num(b.yes_bid,3)+'</span> <span class="k">ask</span> <span class="r">'+num(b.yes_ask,3)+'</span></div>'+
    '<div><span class="'+(b.locked==='no'?'a':'k')+'">'+(b.locked==='no'?'▸ ':'')+
    'DOWN/NO</span> <span class="k">bid</span> <span class="g">'+num(b.no_bid,3)+'</span> <span class="k">ask</span> <span class="r">'+num(b.no_ask,3)+'</span></div></div>'+
    (b.rung?'<div class="row"><div><span class="k">buy '+b.rung+' band</span> '+num(b.band_lo,2)+'–'+num(b.band_hi,2)+
      ' <span class="k">now</span> <b>'+num(b.band_price,3)+'</b></div><div class="'+(b.in_band?'g':'d')+'">'+
      (b.in_band?'● IN BAND':'○ outside band')+'</div></div>':'');

  const p=d.position;
  $('pos').innerHTML=!p?'<div class="d">nothing held</div>':
    '<div class="row"><div><span class="k">holding</span> <b>'+p.contracts+'</b> <span class="k">'+
    (p.side==='yes'?'UP':'DOWN')+' contracts, avg</span> '+num(p.avg_price,3)+
    '</div><div class="d">paid '+money(p.cost)+' + '+money(p.fees)+' fees</div></div>'+
    '<div class="row"><div><span class="k">worth now</span> '+num(p.mark,3)+' <span class="k">→ profit</span> <b class="'+
    cls(p.net)+'">'+pct(p.net)+'</b> <span class="k">after all fees</span></div></div>'+
    '<div class="row"><div><span class="k">SELLS WHEN PROFIT REACHES</span> <b class="a">'+pct(p.need)+
    '</b> <span class="d">— '+p.rule_words+'</span></div>'+
    '<div class="'+(p.net!=null&&p.net>=p.need?'g':'d')+'">'+
    (p.net!=null&&p.net>=p.need?'▲ SELLING NOW':(p.net!=null?pct(p.need-p.net)+' to go':''))+'</div></div>';

  $('act').innerHTML=(d.activity&&d.activity.length)?d.activity.map(a=>{
    const c={trig:'a',buy:'g',cxl:'a',sell:'r',setl:'b'}[a.kind]||'';
    const liq=a.liquidity==='maker'?' <span class="b">·maker</span>':'';
    const why = a.reason_key
      ? '<span class="why" data-why="'+a.reason_key+'">'+a.reason_words+'</span>' : '';
    return '<tr><td class="t">'+hms(a.t)+'</td><td class="tag '+c+'">'+a.text+
      '</td><td>'+a.detail+why+liq+'</td></tr>';}).join(''):
    '<tr><td class="d">nothing yet this round</td></tr>';

  const A=d.account;
  $('acct').innerHTML=
    '<div class="row"><div><span class="k">BALANCE</span> <b class="big">'+money(A.balance)+'</b> '+
    '<b class="'+cls(A.pnl)+'">'+(A.pnl>=0?'+':'-')+money(Math.abs(A.pnl)).replace('-','')+'</b> '+
    '<span class="k">total since start ('+money(A.start)+')</span></div>'+
    '<div class="d">max at risk '+money(A.max_deployed)+'</div></div>'+
    '<div class="row"><div><span class="k">rounds seen</span> <b>'+A.rounds_total+'</b>'+
    ' &nbsp;<span class="k">traded</span> <b>'+A.rounds_traded+'</b>'+
    ' &nbsp;<span class="k">no trade</span> <b class="d">'+A.rounds_skipped+'</b>'+
    ' &nbsp;<span class="k">won</span> <b class="g">'+A.rounds_won+'</b>'+
    ' &nbsp;<span class="k">lost</span> <b class="r">'+A.rounds_lost+'</b>'+
    ' &nbsp;<span class="k">win rate</span> <b>'+(A.rounds_traded?((100*A.rounds_won/A.rounds_traded).toFixed(0)+'%'):'—')+'</b>'+
    '</div><div class="d">'+(A.rounds_total?((100*A.rounds_traded/A.rounds_total).toFixed(0)+'% of rounds traded'):'')+'</div></div>'+
    '<div class="row"><div class="d">streak <span class="g">'+A.wins+'W</span> / <span class="r">'+A.losses+'L</span>'+
    ' · '+A.buy_cap+' buys of $'+(A.stake||5).toFixed(2)+
    (A.cooldown?' · <b class="a">COOLING OFF '+A.cooldown+' rounds</b>':'')+
    '</div><div class="d"></div></div>'+
    (A.halted?'<div class="r"><b>■ HALTED</b> '+A.halt_reason+'</div>':'');

  $('recent').innerHTML=(d.recent&&d.recent.length)?d.recent.slice().reverse().map(r=>{
    const dl='<a class="dl" href="/receipt?id='+encodeURIComponent(r.id)+
             '" title="Download a receipt for this round: every buy, every sell, or why it did not sell">receipt</a>';
    return r.traded
      ? '<tr><td class="tag '+cls(r.net)+'">'+(r.net>0?'▲':r.net<0?'▼':'=')+' '+(r.dir||'')+
        '</td><td class="t">'+r.id.slice(-8)+'</td><td>'+r.contracts+'c '+money(r.deployed)+' → <b class="'+
        cls(r.net)+'">'+money(r.net)+'</b> '+pct(r.pct)+' '+
        (r.reason_key?'<span class="why" data-why="'+r.reason_key+'">'+r.reason+'</span>'
                     :'<span class="d">'+r.reason+'</span>')+dl+'</td></tr>'
      : '<tr><td class="tag d">·</td><td class="t">'+r.id.slice(-8)+'</td><td class="d">no position — '+r.reason+dl+'</td></tr>';
  }).join(''):'<tr><td class="d">none yet</td></tr>';

  $('log').innerHTML=(d.log||[]).slice().reverse().map(l=>
    '<div>'+l.t+' <b>'+l.msg.replace(/</g,'&lt;')+'</b></div>').join('');
}

async function tick(){
  try{
    const r=await fetch('/state',{cache:'no-store'});
    const d=await r.json(); misses=0;
    $('conn').textContent='connected'; $('conn').className='g';
    render(d);
  }catch(e){
    misses++;
    $('conn').textContent='NO CONNECTION ('+misses+') — is the bot running?';
    $('conn').className='r';
  }
}
// Pull the glossary once so every rule label on the page can be clicked.
fetch('/rules',{cache:'no-store'}).then(r=>r.json())
  .then(d=>{ GLOSSARY=d.glossary||{}; }).catch(()=>{});

const pop=$('pop');
function showWhy(key){
  const g=GLOSSARY[key];
  $('poptitle').textContent = g ? g.title : (key||'').replace(/_/g,' ');
  $('poptext').textContent  = g ? g.text  : 'No description for this one yet.';
  pop.classList.add('on');
}
function closeWhy(){ pop.classList.remove('on'); }
$('popclose').onclick=closeWhy;
pop.onclick=e=>{ if(e.target===pop) closeWhy(); };
document.addEventListener('click',e=>{
  const el=e.target.closest('.why');
  if(el) showWhy(el.getAttribute('data-why'));
});

const ovl=$('ovl');
function closeRules(){ ovl.classList.remove('on'); }
$('rulesbtn').onclick=async()=>{
  $('rulesbody').innerHTML='<div class="d" style="padding:12px 0">loading…</div>';
  ovl.classList.add('on');
  try{
    const r=await fetch('/rules',{cache:'no-store'});
    const d=await r.json();
    $('rulesbody').innerHTML=d.sections.map(sec=>
      '<h4>'+sec.title+'</h4><table>'+sec.rows.map(row=>
        '<tr><td class="rk">'+row[0]+'</td><td class="rv">'+row[1]+'</td></tr>'
      ).join('')+'</table>').join('');
  }catch(e){
    $('rulesbody').innerHTML='<div class="r" style="padding:12px 0">could not load rules: '+e+'</div>';
  }
};
$('rulesclose').onclick=closeRules;
ovl.onclick=e=>{ if(e.target===ovl) closeRules(); };
document.addEventListener('keydown',e=>{ if(e.key==='Escape'){ closeRules(); closeWhy(); } });

$('reset').onclick=async()=>{
  if(!confirm('Clear cached balance, win/loss streaks and halt state?\n\n'+
              'Log files (windows.jsonl) are kept — only the live counters reset.')) return;
  $('reset').disabled=true;
  try{
    const r=await fetch('/reset',{method:'POST'});
    const j=await r.json();
    if(!j.ok) alert('Not cleared: '+j.error);
  }catch(e){ alert('Reset failed: '+e); }
  $('reset').disabled=false; tick();
};
tick(); setInterval(tick,500);
</script></body></html>
"""
