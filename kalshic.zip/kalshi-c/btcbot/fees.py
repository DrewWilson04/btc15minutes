"""Kalshi fee model.

Kalshi charges a quadratic fee that peaks at 50c and vanishes at the wings.
At $5 clips the ceil-to-the-cent rounding is not a rounding detail, it is a
material share of the edge: 7 contracts at 63c costs ceil(0.07*0.63*0.37*7*100)
= ceil(11.43) = 12c, and you pay it on the way in and on the way out.

Everything here is pure and deterministic so the numbers in the log can be
recomputed and checked by hand.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class FeeConfig:
    taker_rate: float
    maker_share_of_taker: float
    round_up_to_cents: bool = True

    @classmethod
    def from_dict(cls, d: dict) -> "FeeConfig":
        return cls(
            taker_rate=float(d["taker_rate"]),
            maker_share_of_taker=float(d["maker_share_of_taker"]),
            round_up_to_cents=bool(d.get("round_up_to_cents", True)),
        )


def _round_cents_up(dollars: float) -> float:
    """Kalshi rounds fees UP to the next whole cent."""
    return math.ceil(round(dollars * 100, 9)) / 100.0


def fee(price: float, contracts: int, is_maker: bool, cfg: FeeConfig) -> float:
    """Fee in dollars for one order.

    price:      contract price in DOLLARS (0.0 - 1.0)
    contracts:  contract count
    is_maker:   maker orders pay `maker_share_of_taker` of the taker rate
    """
    if contracts <= 0:
        return 0.0
    rate = cfg.taker_rate * (cfg.maker_share_of_taker if is_maker else 1.0)
    raw = rate * price * (1.0 - price) * contracts
    return _round_cents_up(raw) if cfg.round_up_to_cents else round(raw, 4)


def taker_fee(price: float, contracts: int, cfg: FeeConfig) -> float:
    return fee(price, contracts, is_maker=False, cfg=cfg)


def maker_fee(price: float, contracts: int, cfg: FeeConfig) -> float:
    return fee(price, contracts, is_maker=True, cfg=cfg)


def round_trip_drag(price: float, contracts: int, cfg: FeeConfig,
                    entry_maker: bool = False, exit_maker: bool = False) -> float:
    """Total fee cost of a round trip as a fraction of capital deployed.

    Used for pre-trade sanity logging: at 63c taker/taker this is ~4.6%, which
    is why a 5% NET exit needs close to a 10% gross move.
    """
    cost = price * contracts
    if cost <= 0:
        return 0.0
    entry = fee(price, contracts, entry_maker, cfg)
    exit_ = fee(price, contracts, exit_maker, cfg)
    return (entry + exit_) / cost


def net_return_on_exit(entry_cost: float, entry_fees: float,
                       exit_price: float, contracts: int,
                       exit_is_maker: bool, cfg: FeeConfig) -> tuple[float, float, float]:
    """Net return on capital deployed if we sold `contracts` at `exit_price`.

    Returns (net_return_fraction, exit_fee, net_pnl_dollars).

    Capital deployed is the entry cost EXCLUDING entry fees; entry fees are
    charged against the P&L. This matches "net return on capital deployed,
    after all entry and exit fees".
    """
    if entry_cost <= 0 or contracts <= 0:
        return (0.0, 0.0, 0.0)
    ex_fee = fee(exit_price, contracts, exit_is_maker, cfg)
    proceeds = exit_price * contracts
    net_pnl = proceeds - ex_fee - entry_cost - entry_fees
    return (net_pnl / entry_cost, ex_fee, net_pnl)
