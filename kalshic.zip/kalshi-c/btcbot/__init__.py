"""Kalshi KXBTC15M paper trading bot."""
__version__ = "0.1.0"
