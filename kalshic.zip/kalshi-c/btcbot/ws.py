"""WebSocket clients.

Two separate sockets, because Kalshi serves them from two different APIs:

  1. Order book / trades  -> wss://api.elections.kalshi.com/trade-api/ws/v2
     channels: orderbook_delta, ticker, trade
  2. Settlement index     -> wss://api.elections.kalshi.com/v1/ws
     channel: cfbenchmarks_value, index_ids: ["BRTI"]
     This is the CF Benchmarks index the market actually settles against.

Both reconnect with backoff. On reconnect the book resubscribes and discards
stale state until a fresh snapshot arrives, so a dropped socket can never
leave the strategy trading off a half-updated book.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

import websockets
from websockets.exceptions import ConnectionClosed

from .auth import KalshiSigner
from .clock import monotonic

log = logging.getLogger(__name__)

Handler = Callable[[dict], Awaitable[None] | None]


class ReconnectingWS:
    """Base: connect, subscribe, pump messages, reconnect with backoff."""

    def __init__(self, url: str, signer: KalshiSigner | None, sign_path: str,
                 name: str = "ws", max_backoff: float = 30.0):
        self.url = url
        self.signer = signer
        self.sign_path = sign_path
        self.name = name
        self.max_backoff = max_backoff
        self._ws: Any = None
        self._msg_id = 0
        self._stop = asyncio.Event()
        self.connected = asyncio.Event()
        self.reconnect_count = 0
        self.last_message_at: float = 0.0

    # -- subclass hooks -----------------------------------------------------

    async def on_connect(self) -> None:
        """Send subscriptions. Called on every (re)connect."""

    async def on_message(self, msg: dict) -> None:
        raise NotImplementedError

    async def on_disconnect(self) -> None:
        """Invalidate any state that a gap could have corrupted."""

    # -- plumbing -----------------------------------------------------------

    def next_id(self) -> int:
        self._msg_id += 1
        return self._msg_id

    async def send(self, payload: dict) -> None:
        if self._ws is None:
            raise RuntimeError(f"{self.name}: not connected")
        await self._ws.send(json.dumps(payload))

    async def subscribe(self, params: dict) -> None:
        await self.send({"id": self.next_id(), "cmd": "subscribe", "params": params})

    def _headers(self) -> dict[str, str]:
        if self.signer is None:
            return {}
        return self.signer.ws_headers(self.sign_path)

    async def run(self) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                async with websockets.connect(
                    self.url,
                    additional_headers=self._headers(),
                    open_timeout=20,
                    ping_interval=10,
                    ping_timeout=20,
                    max_queue=1024,
                ) as ws:
                    self._ws = ws
                    self.connected.set()
                    backoff = 1.0
                    log.info("%s connected", self.name)
                    await self.on_connect()
                    async for raw in ws:
                        self.last_message_at = monotonic()
                        try:
                            msg = json.loads(raw)
                        except json.JSONDecodeError:
                            log.warning("%s: non-JSON frame dropped", self.name)
                            continue
                        await self.on_message(msg)
            except asyncio.CancelledError:
                raise
            except (ConnectionClosed, OSError, websockets.InvalidStatus) as exc:
                if self._stop.is_set():
                    break
                self.reconnect_count += 1
                log.warning("%s disconnected (%s: %s); retry in %.1fs",
                            self.name, type(exc).__name__, str(exc)[:120], backoff)
            except Exception as exc:  # noqa: BLE001 - never let the socket kill the bot
                self.reconnect_count += 1
                log.exception("%s unexpected error: %s; retry in %.1fs", self.name, exc, backoff)
            finally:
                self._ws = None
                self.connected.clear()
                await self.on_disconnect()

            if self._stop.is_set():
                break
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, self.max_backoff)

    async def stop(self) -> None:
        self._stop.set()
        if self._ws is not None:
            await self._ws.close()


class MarketDataWS(ReconnectingWS):
    """Order book + trades for one ticker at a time.

    `set_ticker` switches subscription at each window rollover. The book is
    marked not-ready until a fresh snapshot arrives so the strategy will not
    act on a stale ladder.
    """

    def __init__(self, url: str, signer: KalshiSigner, sign_path: str,
                 on_snapshot: Handler, on_delta: Handler,
                 on_trade: Handler | None = None,
                 on_index: Handler | None = None,
                 index_channel: str = "cfbenchmarks_value",
                 index_id: str | None = None,
                 on_gap=None):
        super().__init__(url, signer, sign_path, name="market-ws")
        self._on_snapshot = on_snapshot
        self._on_delta = on_delta
        self._on_trade = on_trade
        self._on_index = on_index
        self._on_gap = on_gap
        self.index_channel = index_channel
        self.index_id = index_id
        self.ticker: str | None = None
        self._sub_lock = asyncio.Lock()

    async def on_disconnect(self) -> None:
        """A gap means the ladder we hold may be wrong; let the owner reset it."""
        if self._on_gap is not None:
            await _maybe_await(self._on_gap())

    async def set_ticker(self, ticker: str) -> None:
        async with self._sub_lock:
            self.ticker = ticker
            if self.connected.is_set():
                await self._subscribe_current()

    async def _subscribe_current(self) -> None:
        if not self.ticker:
            return
        await self.subscribe({
            "channels": ["orderbook_delta", "trade", "ticker"],
            "market_tickers": [self.ticker],
        })
        log.info("market-ws subscribed to %s", self.ticker)

    async def on_connect(self) -> None:
        # The index rides the same socket as the book: one connection to
        # authenticate, one to reconnect, one place for a gap to appear.
        if self._on_index and self.index_id:
            await self.subscribe({"channels": [self.index_channel],
                                  "index_ids": [self.index_id]})
            log.info("subscribed to %s/%s", self.index_channel, self.index_id)
        await self._subscribe_current()

    async def on_message(self, msg: dict) -> None:
        mtype = msg.get("type")
        if mtype == self.index_channel and self._on_index:
            await _maybe_await(self._on_index(msg.get("msg", {})))
        elif mtype == "orderbook_snapshot":
            await _maybe_await(self._on_snapshot(msg.get("msg", {})))
        elif mtype == "orderbook_delta":
            await _maybe_await(self._on_delta(msg.get("msg", {})))
        elif mtype == "trade" and self._on_trade:
            await _maybe_await(self._on_trade(msg.get("msg", {})))
        elif mtype == "error":
            log.error("market-ws error frame: %s", msg)
        elif mtype in ("subscribed", "ok", "pong"):
            log.debug("market-ws: %s", msg)


async def _maybe_await(result) -> None:
    if asyncio.iscoroutine(result):
        await result


def dig(d: dict, dotted: str, default=None):
    """Pull a nested field like 'avg_60s_data.value' out of a payload."""
    node: Any = d
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node
