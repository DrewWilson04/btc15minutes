"""Order execution.

PaperExecutor simulates fills against the real live book. It never sends
anything to Kalshi. LiveExecutor places real orders and is only constructible
when live trading has been explicitly armed.

Fill simulation is deliberately pessimistic, because the whole point of the
paper run is to find out whether maker fills are achievable — an optimistic
model would answer that question by assumption:

  * Taker orders walk the real ladder level by level. If the book is thin the
    average fill price is worse than the touch, and a partial fill stays
    partial rather than being rounded up to the full clip.
  * Maker orders join the BACK of the queue at their level. They fill only
    once the size that was resting ahead of us has traded off, observed from
    real prints. Resting at the touch does not conjure a fill.
"""
from __future__ import annotations

import asyncio
import itertools
import logging
from dataclasses import dataclass, field
from typing import Literal

from .clock import iso
from .fees import FeeConfig, fee
from .orderbook import FULL, Book, Side, to_units
from .portfolio import Fill
from .vclock import Clock, RealClock

log = logging.getLogger(__name__)

OrderMode = Literal["limit_first", "always_take", "always_limit"]
_order_seq = itertools.count(1)


@dataclass
class OrderResult:
    """Outcome of one attempt to buy or sell."""
    filled: bool
    fills: list[Fill] = field(default_factory=list)
    cancelled: bool = False
    reason: str = ""
    requested_contracts: int = 0
    order_id: str = ""
    # When limit_first posts and then has to cross, the abandoned limit is
    # kept here so the log can show what was given up on, not just the fill.
    limit_attempt: dict | None = None

    @property
    def filled_contracts(self) -> int:
        return sum(f.contracts for f in self.fills)

    @property
    def total_cost(self) -> float:
        return sum(f.price * f.contracts for f in self.fills)

    @property
    def total_fees(self) -> float:
        return sum(f.fee_paid for f in self.fills)

    @property
    def avg_price(self) -> float:
        c = self.filled_contracts
        return self.total_cost / c if c else 0.0

    @property
    def partial(self) -> bool:
        return 0 < self.filled_contracts < self.requested_contracts

    def as_dict(self) -> dict:
        return {
            "order_id": self.order_id,
            "filled": self.filled,
            "partial": self.partial,
            "requested_contracts": self.requested_contracts,
            "filled_contracts": self.filled_contracts,
            "cancelled": self.cancelled,
            "reason": self.reason,
            "avg_fill_price": round(self.avg_price, 4) if self.fills else None,
            "fees": round(self.total_fees, 4),
            "fills": [f.as_dict() for f in self.fills],
            "limit_attempt": self.limit_attempt,
        }


class Executor:
    def __init__(self, fee_cfg: FeeConfig, clock: Clock | None = None):
        self.fee_cfg = fee_cfg
        self.clock = clock or RealClock()

    async def buy(self, book: Book, side: Side, contracts: int,
                  mode: OrderMode, limit_timeout: float,
                  max_price: float | None = None) -> OrderResult:
        raise NotImplementedError

    async def sell(self, book: Book, side: Side, contracts: int,
                   take: bool = True) -> OrderResult:
        raise NotImplementedError


class PaperExecutor(Executor):
    """Simulates against the live book. Places nothing."""

    def __init__(self, fee_cfg: FeeConfig, paper_cfg: dict,
                 tape=None, clock: Clock | None = None):
        super().__init__(fee_cfg, clock)
        self.model_queue = bool(paper_cfg.get("model_queue_position", True))
        self.queue_ahead_fraction = float(paper_cfg.get("queue_ahead_fraction", 1.0))
        self.allow_partial = bool(paper_cfg.get("allow_partial_fills", True))
        self.tape = tape
        # Cumulative traded volume per (side, price units), from real prints.
        # Sizes are fractional on Kalshi, so this is a float.
        self._traded: dict[tuple[str, int], float] = {}

    def on_trade(self, side_taken: str, price, count) -> None:
        """Record a real print so resting maker orders can be worked off."""
        try:
            key = (side_taken, to_units(price))
            self._traded[key] = self._traded.get(key, 0.0) + float(count)
        except (TypeError, ValueError):
            return

    def traded_since(self, side: str, price, baseline: float) -> float:
        return max(0.0, self._traded.get((side, to_units(price)), 0.0) - baseline)

    # -- taker --------------------------------------------------------------

    def _walk_ladder(self, book: Book, side: Side, contracts: int,
                     buying: bool,
                     limit_price: float | None = None) -> list[tuple[float, int]]:
        """Consume real depth. Returns [(price, count)] actually filled.

        Book depth is fractional; our own fills stay whole contracts, so a
        level offering 8.55 fills at most 8.

        `limit_price` is a hard bound on the fill, not on the decision: a buy
        stops at the first level above it and a sell at the first level below,
        taking a partial fill rather than paying through the limit. Without it
        a thin touch silently fills the rest of the clip at any price the book
        happens to offer.
        """
        ladder = book.ask_ladder(side) if buying else book.bid_ladder(side)
        out: list[tuple[float, int]] = []
        remaining = contracts
        for price, available in ladder:
            if remaining <= 0:
                break
            if not (0 < price < 1):
                continue
            if limit_price is not None:
                if buying and price > limit_price + 1e-9:
                    break
                if not buying and price < limit_price - 1e-9:
                    break
            take = min(remaining, int(available))
            if take > 0:
                out.append((price, take))
                remaining -= take
        return out

    def _fills_from_levels(self, levels, side: Side, intended: float,
                           is_maker: bool, t0: float, order_id: str) -> list[Fill]:
        fills = []
        for price, count in levels:
            fills.append(Fill(
                timestamp=iso(self.clock.now()),
                side=side,
                price=price,
                intended_price=intended,
                contracts=count,
                is_maker=is_maker,
                fee_paid=fee(price, count, is_maker, self.fee_cfg),
                time_to_fill_s=self.clock.time() - t0,
                order_id=order_id,
            ))
        return fills

    async def _take(self, book: Book, side: Side, contracts: int,
                    buying: bool, order_id: str, t0: float,
                    limit_price: float | None = None) -> OrderResult:
        touch = book.ask(side) if buying else book.bid(side)
        if touch is None:
            return OrderResult(False, reason="no_book", order_id=order_id,
                               requested_contracts=contracts)
        levels = self._walk_ladder(book, side, contracts, buying, limit_price)
        if not levels:
            return OrderResult(False,
                               reason=("price_above_limit" if limit_price is not None
                                       and buying else "no_depth"),
                               order_id=order_id,
                               requested_contracts=contracts)
        got = sum(c for _, c in levels)
        if got < contracts and not self.allow_partial:
            return OrderResult(False, reason="insufficient_depth", order_id=order_id,
                               requested_contracts=contracts)
        fills = self._fills_from_levels(levels, side, touch, False, t0, order_id)
        return OrderResult(True, fills=fills, requested_contracts=contracts,
                           order_id=order_id,
                           reason="taker_partial" if got < contracts else "taker")

    # -- maker --------------------------------------------------------------

    async def _rest_limit(self, book: Book, side: Side, contracts: int,
                          buying: bool, timeout: float, order_id: str,
                          t0: float) -> OrderResult:
        """Post at the near touch and wait. Fill only if the queue clears."""
        price = book.bid(side) if buying else book.ask(side)
        if price is None:
            return OrderResult(False, reason="no_book", order_id=order_id,
                               requested_contracts=contracts)

        # Where we sit in the queue at this level right now. Selling `side`
        # means resting on the opposite ladder, at the mirrored price.
        if not self.model_queue:
            resting_ahead = 0.0
        elif buying:
            resting_ahead = book.size_at(side, price) * self.queue_ahead_fraction
        else:
            opp: Side = "no" if side == "yes" else "yes"
            resting_ahead = (book.size_at(opp, round(1.0 - price, 4))
                             * self.queue_ahead_fraction)

        trade_key_side = side if buying else ("no" if side == "yes" else "yes")
        baseline = self._traded.get((trade_key_side, to_units(price)), 0.0)

        deadline = self.clock.time() + timeout
        poll = 0.05
        while self.clock.time() < deadline:
            await self.clock.sleep(poll)
            # Someone traded through our level: work off the queue ahead first.
            traded = self.traded_since(trade_key_side, price, baseline)
            if traded > resting_ahead:
                got = int(min(contracts, traded - resting_ahead))
                if got > 0:
                    fills = self._fills_from_levels([(price, got)], side,
                                                    price, True, t0, order_id)
                    return OrderResult(True, fills=fills,
                                       requested_contracts=contracts,
                                       order_id=order_id,
                                       reason="maker_partial" if got < contracts
                                              else "maker")
            # The book moved away from our price: we are no longer at the touch,
            # so the resting order is stale and will not fill.
            now_touch = book.bid(side) if buying else book.ask(side)
            if now_touch is not None:
                if buying and now_touch > price + 1e-9:
                    break
                if not buying and now_touch < price - 1e-9:
                    break

        return OrderResult(False, cancelled=True, reason="limit_timeout",
                           order_id=order_id, requested_contracts=contracts)

    # -- resting limit at an arbitrary price --------------------------------

    async def rest_at(self, book: Book, side: Side, contracts: int,
                      price: float, buying: bool, deadline: float,
                      poll: float = 0.05) -> OrderResult:
        """Rest an order AT `price` until `deadline` (absolute clock time).

        Unlike _rest_limit this does not sit at the touch and does not give up
        when the book moves away — the whole point is to park an order far from
        the market and wait for the market to come to it.

        Fill model, deliberately pessimistic and consistent with _rest_limit:
        we join the BACK of the queue at our level, and only fill once the size
        that was resting ahead of us has traded off at that price or through it.
        """
        order_id = f"paper-{next(_order_seq)}"
        t0 = self.clock.time()
        if contracts <= 0:
            return OrderResult(False, reason="zero_contracts", order_id=order_id)

        # Buying `side` at `price` means resting on that side's own bid ladder.
        # Selling `side` at `price` means resting on the OPPOSITE ladder at the
        # mirrored price, which is where that liquidity actually sits.
        if buying:
            queue_side: Side = side
            queue_price = price
        else:
            queue_side = "no" if side == "yes" else "yes"
            queue_price = round(1.0 - price, 4)

        if not self.model_queue:
            resting_ahead = 0.0
        else:
            resting_ahead = (book.size_at(queue_side, queue_price)
                             * self.queue_ahead_fraction)
        baseline = self._traded.get((queue_side, to_units(queue_price)), 0.0)

        while self.clock.time() < deadline:
            await self.clock.sleep(poll)
            traded = self.traded_since(queue_side, queue_price, baseline)
            if traded > resting_ahead:
                got = int(min(contracts, traded - resting_ahead))
                if got > 0:
                    fills = self._fills_from_levels([(price, got)], side,
                                                    price, True, t0, order_id)
                    return OrderResult(
                        True, fills=fills, requested_contracts=contracts,
                        order_id=order_id,
                        reason="maker_partial" if got < contracts else "maker")
            # A resting BUY is also filled if the market gaps through it: the
            # ask falls to or below our price and we are the standing bid.
            if buying:
                a = book.ask(side)
                if a is not None and a <= price + 1e-9:
                    fills = self._fills_from_levels([(price, contracts)], side,
                                                    price, True, t0, order_id)
                    return OrderResult(True, fills=fills,
                                       requested_contracts=contracts,
                                       order_id=order_id, reason="maker_gapped")
            else:
                b = book.bid(side)
                if b is not None and b >= price - 1e-9:
                    fills = self._fills_from_levels([(price, contracts)], side,
                                                    price, True, t0, order_id)
                    return OrderResult(True, fills=fills,
                                       requested_contracts=contracts,
                                       order_id=order_id, reason="maker_gapped")

        return OrderResult(False, cancelled=True, reason="rest_expired",
                           order_id=order_id, requested_contracts=contracts)

    # -- public -------------------------------------------------------------

    async def buy(self, book: Book, side: Side, contracts: int,
                  mode: OrderMode, limit_timeout: float,
                  max_price: float | None = None) -> OrderResult:
        order_id = f"paper-{next(_order_seq)}"
        t0 = self.clock.time()
        if contracts <= 0:
            return OrderResult(False, reason="zero_contracts", order_id=order_id)

        if mode == "always_take":
            return await self._take(book, side, contracts, True, order_id, t0,
                                    max_price)

        posted_at = book.bid(side)
        result = await self._rest_limit(book, side, contracts, True,
                                        limit_timeout, order_id, t0)
        if result.filled or mode == "always_limit":
            return result

        # limit_first: the resting order did not fill, so cancel and cross.
        abandoned = {
            "posted_price": posted_at,
            "contracts": contracts,
            "rested_s": round(self.clock.time() - t0, 3),
            "outcome": result.reason,
        }
        crossed = await self._take(book, side, contracts, True, order_id, t0,
                                   max_price)
        crossed.reason = f"limit_timeout_then_{crossed.reason}"
        crossed.cancelled = True
        crossed.limit_attempt = abandoned
        return crossed

    async def sell(self, book: Book, side: Side, contracts: int,
                   take: bool = True) -> OrderResult:
        order_id = f"paper-{next(_order_seq)}"
        t0 = self.clock.time()
        if contracts <= 0:
            return OrderResult(False, reason="zero_contracts", order_id=order_id)
        # Exits always cross: getting out is not optional.
        return await self._take(book, side, contracts, False, order_id, t0)


class LiveExecutor(Executor):
    """Real orders. Only reachable when live trading is armed and confirmed."""

    def __init__(self, fee_cfg: FeeConfig, rest, armed: bool,
                 clock: Clock | None = None):
        super().__init__(fee_cfg, clock)
        if not armed:
            raise RuntimeError(
                "LiveExecutor constructed without arming. This is a bug — live "
                "trading requires mode.live_trading plus the typed confirmation.")
        self.rest = rest
        log.warning("LIVE EXECUTOR ACTIVE — real orders, real money")

    async def buy(self, book: Book, side: Side, contracts: int,
                  mode: OrderMode, limit_timeout: float) -> OrderResult:
        raise NotImplementedError(
            "Live order placement is intentionally not implemented in this "
            "build. Run the paper measurement first; wire this up only once "
            "the logs justify it.")

    async def sell(self, book: Book, side: Side, contracts: int,
                   take: bool = True) -> OrderResult:
        raise NotImplementedError("see LiveExecutor.buy")
