"""BTC price feeds for the entry trigger.

Primary source is Kalshi's own cfbenchmarks_value stream, which carries the
CF Benchmarks index the market settles against. Because the trigger and the
settlement then share one number, |BTC - target| means exactly what the market
means by it.

The external venue feeds exist as a fallback and as an optional cross-check
that gets logged but never traded off.
"""
from __future__ import annotations

import asyncio
import json
import logging
import statistics
from dataclasses import dataclass, field
from typing import Callable

import websockets

from .clock import monotonic, utcnow

log = logging.getLogger(__name__)


@dataclass
class Tick:
    price: float
    received_at: float          # monotonic, for staleness
    wall_time: str              # ISO, for the log
    source: str
    index_window_end: str | None = None   # which index observation this is


@dataclass
class PriceState:
    """Latest tick plus enough history to prove the trigger wasn't missed."""
    last: Tick | None = None
    tick_count: int = 0
    history: list[tuple[float, float]] = field(default_factory=list)  # (mono, price)
    max_history: int = 4000

    def update(self, tick: Tick) -> None:
        self.last = tick
        self.tick_count += 1
        self.history.append((tick.received_at, tick.price))
        if len(self.history) > self.max_history:
            del self.history[: len(self.history) // 4]

    def is_stale(self, max_age: float) -> bool:
        if self.last is None:
            return True
        return (monotonic() - self.last.received_at) > max_age

    def clear_history(self) -> None:
        self.history.clear()


class PriceFeed:
    """Interface: owns a task, exposes the latest tick, notifies on each tick."""

    def __init__(self, name: str):
        self.name = name
        self.state = PriceState()
        self._subscribers: list[Callable[[Tick], None]] = []

    def subscribe(self, fn: Callable[[Tick], None]) -> None:
        """Called synchronously on every tick — keep the callback cheap.

        The trigger check lives here rather than on a poll loop so a fleeting
        touch of the threshold cannot be missed between polls.
        """
        self._subscribers.append(fn)

    def _emit(self, tick: Tick) -> None:
        self.state.update(tick)
        for fn in self._subscribers:
            try:
                fn(tick)
            except Exception:  # noqa: BLE001 - one bad subscriber must not kill the feed
                log.exception("price feed subscriber raised")

    @property
    def price(self) -> float | None:
        return self.state.last.price if self.state.last else None

    async def run(self) -> None:
        raise NotImplementedError

    async def stop(self) -> None:
        pass


class KalshiIndexFeed(PriceFeed):
    """The CF Benchmarks index Kalshi settles against.

    Payload shape (from the cfbenchmarks_value channel):

        {"index_id": "BRTI",
         "received_at": 1788729131063,
         "data": "{\"type\":\"value\",\"time\":...,\"value\":\"79989.84\"}",
         "avg_60s_data": {"value": "79989.84000000", "window_size": 0,
                          "window_start_ts_ms": ..., "window_end_ts_exclusive": ...}}

    Note `data` is a JSON STRING, not an object, and every value is a string.
    """

    def __init__(self, index_id: str, value_source: str = "spot",
                 avg60_min_window: int = 55):
        super().__init__(f"kalshi:{index_id}")
        self.index_id = index_id
        self.value_source = value_source
        self.avg60_min_window = avg60_min_window
        self.last_avg60: float | None = None
        self.last_avg60_window: int = 0
        self.rejected = 0

    def _now(self) -> float:
        """Overridden by replay so recorded ticks carry tape time, not wall time."""
        return monotonic()

    def _wall(self) -> str:
        """Wall-clock stamp for a tick. Replay overrides this so a replayed
        round is stamped with the time it actually happened, not the time the
        replay was run."""
        return utcnow().isoformat().replace("+00:00", "Z")

    @staticmethod
    def _f(v) -> float | None:
        try:
            f = float(v)
        except (TypeError, ValueError):
            return None
        return f if f > 0 else None

    def handle_payload(self, payload: dict) -> None:
        if payload.get("index_id") and payload["index_id"] != self.index_id:
            return

        spot = None
        raw = payload.get("data")
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except json.JSONDecodeError:
                raw = None
        if isinstance(raw, dict):
            spot = self._f(raw.get("value"))

        avg = payload.get("avg_60s_data") or {}
        self.last_avg60 = self._f(avg.get("value")) or self.last_avg60
        try:
            self.last_avg60_window = int(avg.get("window_size") or 0)
        except (TypeError, ValueError):
            self.last_avg60_window = 0

        if self.value_source == "avg_60s":
            # Kalshi builds this average from our stream start, so it is not a
            # real 60s average until the window has filled. Trading off a
            # half-warmed average would quietly shift every trigger.
            if self.last_avg60_window < self.avg60_min_window:
                self.rejected += 1
                return
            price = self.last_avg60
        else:
            price = spot

        if price is None:
            self.rejected += 1
            log.debug("index tick without usable value: %s", str(payload)[:180])
            return

        self._emit(Tick(
            price=price,
            received_at=self._now(),
            wall_time=self._wall(),
            source=self.name,
            index_window_end=str(avg.get("window_end_ts_exclusive") or ""),
        ))

    async def run(self) -> None:
        # The socket is driven by run.py; nothing to do here.
        await asyncio.Event().wait()


# ---------------------------------------------------------------------------
# External venue feeds — fallback / cross-check only.
# ---------------------------------------------------------------------------

VENUE_CONFIG = {
    "coinbase": {
        "url": "wss://ws-feed.exchange.coinbase.com",
        "subscribe": {"type": "subscribe", "product_ids": ["BTC-USD"],
                      "channels": ["ticker"]},
        "extract": lambda m: float(m["price"]) if m.get("type") == "ticker"
                              and m.get("price") else None,
    },
    "kraken": {
        "url": "wss://ws.kraken.com/v2",
        "subscribe": {"method": "subscribe",
                      "params": {"channel": "ticker", "symbol": ["BTC/USD"]}},
        "extract": lambda m: (float(m["data"][0]["last"])
                              if m.get("channel") == "ticker" and m.get("data")
                              else None),
    },
    "bitstamp": {
        "url": "wss://ws.bitstamp.net",
        "subscribe": {"event": "bts:subscribe",
                      "data": {"channel": "live_trades_btcusd"}},
        "extract": lambda m: (float(m["data"]["price"])
                              if m.get("event") == "trade" and m.get("data")
                              else None),
    },
    "gemini": {
        "url": "wss://api.gemini.com/v1/marketdata/BTCUSD?trades=true&heartbeat=true",
        "subscribe": None,
        "extract": lambda m: next(
            (float(e["price"]) for e in m.get("events", [])
             if e.get("type") == "trade" and e.get("price")), None),
    },
}


class VenueFeed(PriceFeed):
    """A single exchange websocket, reconnecting."""

    def __init__(self, venue: str):
        super().__init__(venue)
        if venue not in VENUE_CONFIG:
            raise ValueError(f"unknown venue: {venue}")
        self.cfg = VENUE_CONFIG[venue]
        self._stop = asyncio.Event()

    async def run(self) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                async with websockets.connect(self.cfg["url"], open_timeout=15,
                                              ping_interval=15) as ws:
                    if self.cfg["subscribe"]:
                        await ws.send(json.dumps(self.cfg["subscribe"]))
                    backoff = 1.0
                    log.info("venue feed %s connected", self.name)
                    async for raw in ws:
                        if self._stop.is_set():
                            break
                        try:
                            msg = json.loads(raw)
                        except json.JSONDecodeError:
                            continue
                        try:
                            price = self.cfg["extract"](msg)
                        except (KeyError, TypeError, ValueError, IndexError):
                            continue
                        if price:
                            self._emit(Tick(price, monotonic(),
                                            utcnow().isoformat().replace("+00:00", "Z"),
                                            self.name))
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                if self._stop.is_set():
                    break
                log.warning("venue %s dropped (%s); retry in %.1fs",
                            self.name, str(exc)[:100], backoff)
            if self._stop.is_set():
                break
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30.0)

    async def stop(self) -> None:
        self._stop.set()


class CompositeFeed(PriceFeed):
    """Median across venues. A single venue stalling or printing an outlier
    cannot move the trigger."""

    def __init__(self, venues: list[str], stale_seconds: float, min_live: int):
        super().__init__("composite")
        self.feeds = [VenueFeed(v) for v in venues]
        self.stale_seconds = stale_seconds
        self.min_live = min_live
        for f in self.feeds:
            f.subscribe(self._on_venue_tick)

    def _on_venue_tick(self, _tick: Tick) -> None:
        live = [f.state.last.price for f in self.feeds
                if f.state.last and not f.state.is_stale(self.stale_seconds)]
        if len(live) < self.min_live:
            return
        self._emit(Tick(statistics.median(live), monotonic(),
                        utcnow().isoformat().replace("+00:00", "Z"),
                        f"composite({len(live)})"))

    def live_venue_count(self) -> int:
        return sum(1 for f in self.feeds
                   if f.state.last and not f.state.is_stale(self.stale_seconds))

    async def run(self) -> None:
        await asyncio.gather(*(f.run() for f in self.feeds))

    async def stop(self) -> None:
        await asyncio.gather(*(f.stop() for f in self.feeds))


def build_feed(cfg) -> PriceFeed:
    source = cfg.get("price_feed.source")
    if source == "kalshi_index":
        k = cfg.get("price_feed.kalshi_index")
        return KalshiIndexFeed(k["index_id"],
                               k.get("value_source", "spot"),
                               int(k.get("avg60_min_window_size", 55)))
    if source == "composite":
        c = cfg.get("price_feed.composite")
        return CompositeFeed(c["venues"], c["stale_tick_seconds"], c["min_live_venues"])
    if source == "coinbase":
        return VenueFeed("coinbase")
    raise ValueError(f"unknown price_feed.source: {source}")
