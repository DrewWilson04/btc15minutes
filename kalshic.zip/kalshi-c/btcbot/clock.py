"""Time helpers. All internal time is UTC and monotonic where it matters."""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo


# Display timezone. Kalshi's rounds are named in Eastern (the ticker suffix is
# the ET close time), so Eastern is what the screen should show. Everything
# internal stays UTC; this is presentation only.
DISPLAY_TZ = "America/New_York"


def display_tz() -> ZoneInfo:
    try:
        return ZoneInfo(DISPLAY_TZ)
    except Exception:  # noqa: BLE001 - never let a tz lookup break the bot
        return timezone.utc


def to_local(ts) -> datetime | None:
    """UTC datetime or ISO string -> display timezone."""
    if ts is None:
        return None
    if isinstance(ts, str):
        if not ts:
            return None
        try:
            ts = parse_iso(ts)
        except ValueError:
            return None
    return ts.astimezone(display_tz())


def local_hms(ts) -> str:
    """HH:MM:SS in the display timezone; '' when there is nothing to show."""
    d = to_local(ts)
    return d.strftime("%H:%M:%S") if d else ""


def tz_abbrev(ts=None) -> str:
    """ET label that follows DST — EDT in summer, EST in winter."""
    d = to_local(ts or utcnow())
    return d.strftime("%Z") if d else "UTC"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(ts: datetime | None = None) -> str:
    return (ts or utcnow()).isoformat().replace("+00:00", "Z")


def parse_iso(s: str) -> datetime:
    """Parse Kalshi timestamps, which may end in Z and may carry sub-second."""
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def monotonic() -> float:
    return time.monotonic()


async def sleep_until(target: datetime) -> None:
    """Sleep until a wall-clock UTC instant, in slices so clock jumps recover."""
    while True:
        delta = (target - utcnow()).total_seconds()
        if delta <= 0:
            return
        await asyncio.sleep(min(delta, 5.0))
