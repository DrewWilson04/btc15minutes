"""Kalshi request signing.

Kalshi authenticates with an RSA key you generate in account settings. Each
request carries three headers; the signature is RSA-PSS/SHA256 over the string

    <timestamp_ms><HTTP_METHOD><path>

where `path` excludes the query string but INCLUDES the API prefix
(e.g. /trade-api/v2/markets). Websocket upgrades sign "GET" plus the ws path.

The private key never leaves this process and is never logged.
"""
from __future__ import annotations

import base64
import time
from functools import lru_cache
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


class AuthError(RuntimeError):
    pass


@lru_cache(maxsize=4)
def _load_private_key(path: str) -> rsa.RSAPrivateKey:
    p = Path(path).expanduser()
    if not p.exists():
        raise AuthError(f"private key not found: {p}")
    data = p.read_bytes()
    try:
        key = serialization.load_pem_private_key(data, password=None)
    except Exception as exc:  # noqa: BLE001 - surface a readable message
        raise AuthError(
            f"could not read private key at {p}: {exc}. It should be the "
            f"PEM file Kalshi gave you when you created the API key."
        ) from exc
    if not isinstance(key, rsa.RSAPrivateKey):
        raise AuthError(f"key at {p} is not an RSA private key")
    return key


class KalshiSigner:
    def __init__(self, api_key_id: str, private_key_path: str):
        if not api_key_id:
            raise AuthError("missing KALSHI_API_KEY_ID")
        self.api_key_id = api_key_id
        self.private_key_path = private_key_path
        # Fail fast at construction rather than on the first request.
        _load_private_key(private_key_path)

    def _sign(self, message: str) -> str:
        key = _load_private_key(self.private_key_path)
        signature = key.sign(
            message.encode("utf-8"),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH,
            ),
            hashes.SHA256(),
        )
        return base64.b64encode(signature).decode("utf-8")

    def headers(self, method: str, path: str) -> dict[str, str]:
        """Auth headers for `method path`. `path` must exclude the query string."""
        ts = str(int(time.time() * 1000))
        path = path.split("?", 1)[0]
        return {
            "KALSHI-ACCESS-KEY": self.api_key_id,
            "KALSHI-ACCESS-SIGNATURE": self._sign(ts + method.upper() + path),
            "KALSHI-ACCESS-TIMESTAMP": ts,
            "accept": "application/json",
        }

    def ws_headers(self, path: str) -> dict[str, str]:
        return self.headers("GET", path)
