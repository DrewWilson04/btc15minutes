#!/usr/bin/env python3
"""Read windows.jsonl and report what the paper run actually measured.

    python summarize.py
    python summarize.py --log logs/windows.jsonl --json

The P&L number is the least interesting line here. The ones that decide
whether this strategy is viable are the fee drag and the maker/taker split.
"""
from __future__ import annotations

import argparse
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def load(path: Path) -> list[dict]:
    if not path.exists():
        raise SystemExit(f"no log at {path} — run the bot first")
    out = []
    for i, line in enumerate(path.read_text().splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            print(f"  (skipping malformed line {i})")
    return out


def pct(x: float) -> str:
    return f"{x * 100:.2f}%"


def money(x: float) -> str:
    return f"${x:,.2f}"


def bar(value: float, total: float, width: int = 28) -> str:
    if total <= 0:
        return ""
    n = int(round(width * value / total))
    return "#" * n + "." * (width - n)


def summarize(records: list[dict]) -> dict:
    traded = [r for r in records if r.get("capital_deployed", 0) > 0]
    untraded = [r for r in records if r.get("capital_deployed", 0) <= 0]

    wins = [r for r in traded if r["net_pnl"] > 0]
    losses = [r for r in traded if r["net_pnl"] < 0]
    flat = [r for r in traded if r["net_pnl"] == 0]

    net_total = sum(r["net_pnl"] for r in traded)
    entry_fees = sum(r.get("entry_fees", 0) for r in traded)
    exit_fees = sum(r.get("exit_fees", 0) for r in traded)
    total_fees = entry_fees + exit_fees
    gross_total = net_total + total_fees

    returns = [r["net_return"] for r in traded if r.get("net_return") is not None]

    # maker vs taker across every individual fill
    liquidity = Counter()
    fill_prices = []
    time_to_fill = []
    for r in records:
        for b in r.get("buys", []):
            for f in b.get("fills", []):
                liquidity[f.get("liquidity", "unknown")] += f.get("contracts", 0)
                fill_prices.append(f.get("fill_price", 0))
                time_to_fill.append(f.get("time_to_fill_s", 0))
    exit_liquidity = Counter()
    for r in records:
        for e in r.get("exits", []):
            for f in e.get("fills", []):
                exit_liquidity[f.get("liquidity", "unknown")] += f.get("contracts", 0)

    # cancelled / unfilled limit orders
    unfilled = sum(len(r.get("unfilled_orders", [])) for r in records)
    cancelled = sum(1 for r in records for o in r.get("unfilled_orders", [])
                    if o.get("cancelled"))

    # trigger timing distribution
    trigger_times = [r["trigger_elapsed_s"] for r in records
                     if r.get("trigger_fired") and r.get("trigger_elapsed_s") is not None]

    # exit reasons
    exit_reasons = Counter(r["exit_reason"] for r in records if r.get("exit_reason"))

    # why no entry
    no_entry = Counter(r["no_entry_reason"] for r in records
                       if r.get("no_entry_reason"))

    # feed health
    calib = [r["feed_calibration_error"] for r in records
             if r.get("feed_calibration_error") is not None]
    diverge = [r["feed_cross_check_divergence"] for r in records
               if r.get("feed_cross_check_divergence") is not None]

    return {
        "windows_total": len(records),
        "windows_traded": len(traded),
        "windows_no_position": len(untraded),
        "wins": len(wins), "losses": len(losses), "flat": len(flat),
        "win_rate": len(wins) / len(traded) if traded else 0.0,
        "net_pnl": net_total,
        "gross_pnl": gross_total,
        "entry_fees": entry_fees,
        "exit_fees": exit_fees,
        "total_fees": total_fees,
        "fee_drag_share_of_gross": (total_fees / abs(gross_total)
                                    if gross_total else None),
        "avg_net_return_per_window": statistics.mean(returns) if returns else 0.0,
        "median_net_return": statistics.median(returns) if returns else 0.0,
        "best_window": max((r["net_pnl"] for r in traded), default=0.0),
        "worst_window": min((r["net_pnl"] for r in traded), default=0.0),
        "capital_deployed_total": sum(r.get("capital_deployed", 0) for r in traded),
        "entry_liquidity": dict(liquidity),
        "exit_liquidity": dict(exit_liquidity),
        "avg_fill_price": statistics.mean(fill_prices) if fill_prices else None,
        "avg_time_to_fill_s": statistics.mean(time_to_fill) if time_to_fill else None,
        "unfilled_orders": unfilled,
        "cancelled_orders": cancelled,
        "trigger_times": trigger_times,
        "exit_reasons": dict(exit_reasons),
        "no_entry_reasons": dict(no_entry),
        "calibration_errors": calib,
        "cross_check_divergence": diverge,
        "final_balance": records[-1].get("balance_after") if records else None,
        "halted": any(r.get("halted") for r in records),
        "halt_reason": next((r.get("halt_reason") for r in reversed(records)
                             if r.get("halt_reason")), None),
    }


def report(s: dict, records: list[dict]) -> None:
    W = 62
    print()
    print("=" * W)
    print("  KXBTC15M PAPER RUN SUMMARY".center(W))
    print("=" * W)

    print(f"\nWINDOWS")
    print(f"  observed            {s['windows_total']}")
    print(f"  took a position     {s['windows_traded']}")
    print(f"  no position         {s['windows_no_position']}")
    if s["windows_traded"]:
        print(f"  win / loss / flat   {s['wins']} / {s['losses']} / {s['flat']}")
        print(f"  win rate            {pct(s['win_rate'])}")

    print(f"\nP&L")
    print(f"  gross               {money(s['gross_pnl'])}")
    print(f"  fees                {money(-s['total_fees'])}  "
          f"(entry {money(s['entry_fees'])}, exit {money(s['exit_fees'])})")
    print(f"  net                 {money(s['net_pnl'])}")
    if s["final_balance"] is not None:
        print(f"  final balance       {money(s['final_balance'])}")
    if s["windows_traded"]:
        print(f"  avg net % / window  {pct(s['avg_net_return_per_window'])}")
        print(f"  median net %        {pct(s['median_net_return'])}")
        print(f"  best / worst        {money(s['best_window'])} / {money(s['worst_window'])}")

    print(f"\nFEE DRAG")
    if s["fee_drag_share_of_gross"] is not None:
        print(f"  fees / |gross P&L|  {pct(s['fee_drag_share_of_gross'])}")
    if s["capital_deployed_total"]:
        print(f"  fees / capital      "
              f"{pct(s['total_fees'] / s['capital_deployed_total'])}")
    print(f"  capital deployed    {money(s['capital_deployed_total'])}")

    print(f"\nLIQUIDITY (contracts)")
    for label, d in (("entry", s["entry_liquidity"]), ("exit", s["exit_liquidity"])):
        total = sum(d.values())
        if not total:
            print(f"  {label:<6} none")
            continue
        maker = d.get("maker", 0)
        print(f"  {label:<6} maker {maker:>5} ({pct(maker / total)})  "
              f"taker {d.get('taker', 0):>5} ({pct(d.get('taker', 0) / total)})")
    if s["avg_fill_price"] is not None:
        print(f"  avg entry fill      {s['avg_fill_price']:.3f}")
    if s["avg_time_to_fill_s"] is not None:
        print(f"  avg time to fill    {s['avg_time_to_fill_s']:.2f}s")
    print(f"  unfilled / cancelled  {s['unfilled_orders']} / {s['cancelled_orders']}")

    print(f"\nTRIGGER TIMING (elapsed into window)")
    tt = s["trigger_times"]
    if not tt:
        print("  no triggers fired")
    else:
        print(f"  fired               {len(tt)} of {s['windows_total']} windows")
        print(f"  median              {statistics.median(tt):.1f}s")
        print(f"  min / max           {min(tt):.1f}s / {max(tt):.1f}s")
        buckets = [(0, 5), (5, 15), (15, 30), (30, 60), (60, 120),
                   (120, 300), (300, 1e9)]
        counts = defaultdict(int)
        for t in tt:
            for lo, hi in buckets:
                if lo <= t < hi:
                    counts[(lo, hi)] += 1
                    break
        for lo, hi in buckets:
            n = counts[(lo, hi)]
            if not n and hi > 300:
                continue
            label = f"{lo:>3.0f}-{hi:<4.0f}s" if hi < 1e9 else "  >300s   "
            print(f"    {label} {n:>3}  {bar(n, len(tt))}")

    print(f"\nEXIT THRESHOLD FIRED")
    if not s["exit_reasons"]:
        print("  none")
    total_ex = sum(s["exit_reasons"].values())
    for reason, n in sorted(s["exit_reasons"].items(), key=lambda x: -x[1]):
        print(f"  {reason:<28} {n:>3}  {bar(n, total_ex)}")

    if s["no_entry_reasons"]:
        print(f"\nNO ENTRY REASONS")
        total_ne = sum(s["no_entry_reasons"].values())
        for reason, n in sorted(s["no_entry_reasons"].items(), key=lambda x: -x[1]):
            print(f"  {reason:<28} {n:>3}  {bar(n, total_ne)}")

    if s["calibration_errors"]:
        ce = s["calibration_errors"]
        print(f"\nFEED HEALTH")
        print(f"  calibration vs floor_strike: n={len(ce)} "
              f"median {statistics.median(ce):+.2f} "
              f"max |err| {max(abs(x) for x in ce):.2f}")
        if s["cross_check_divergence"]:
            cd = s["cross_check_divergence"]
            print(f"  index vs external venue:     n={len(cd)} "
                  f"median {statistics.median(cd):+.2f} "
                  f"max |div| {max(abs(x) for x in cd):.2f}")

    if s["halted"]:
        print(f"\nHALTED: {s['halt_reason']}")

    print("\n" + "=" * W + "\n")


def main() -> int:
    ap = argparse.ArgumentParser(description="summarize a KXBTC15M paper run")
    ap.add_argument("--log", default="logs/windows.jsonl")
    ap.add_argument("--json", action="store_true", help="emit raw JSON")
    args = ap.parse_args()

    records = load(Path(args.log))
    if not records:
        print("log is empty")
        return 1
    s = summarize(records)
    if args.json:
        print(json.dumps(s, indent=2, default=str))
    else:
        report(s, records)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
