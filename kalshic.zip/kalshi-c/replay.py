#!/usr/bin/env python3
"""Dry-run replay: re-run the strategy against recorded windows.

    python replay.py --tape tape/                  # replay every recorded window
    python replay.py --tape tape/KXBTC15M-... .gz  # one window
    python replay.py --tape tape/ --set entry.buy_1.max_price=0.60

Replay drives the same WindowTrader used live, so logic changes can be tested
against real recorded books without waiting on the market. Config overrides let
you re-run the same tape under different rules and compare the logs.

A synthetic tape can also be generated for smoke-testing the plumbing:
    python replay.py --synthetic 5
"""
from __future__ import annotations

import argparse
import asyncio
import gzip
import json
import logging
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from btcbot.clock import parse_iso, utcnow
from btcbot.ws import dig
from btcbot.config import load_config
from btcbot.execution import PaperExecutor
from btcbot.feeds import KalshiIndexFeed, PriceFeed, Tick
from btcbot.fees import FeeConfig
from btcbot.logging_jsonl import Logger, setup_console_logging
from btcbot.orderbook import Book
from btcbot.portfolio import Portfolio
from btcbot.rest import Market
from btcbot.strategy_favorite import build_trader
from btcbot.strategy import WindowTrader
from btcbot.vclock import VirtualClock
from btcbot.dashboard import BotState, Dashboard, attach_log_pane

log = logging.getLogger("replay")


class ReplayFeed(KalshiIndexFeed):
    """Recorded index ticks, parsed by the SAME code the live feed uses.

    Subclassing rather than reimplementing matters: if replay parsed the
    payload its own way, a parser bug could pass in replay and fail live.
    """

    def __init__(self, clock: VirtualClock, cfg=None):
        k = (cfg.get("price_feed.kalshi_index", {}) if cfg else {})
        super().__init__(k.get("index_id", "BRTI"),
                         k.get("value_source", "spot"),
                         int(k.get("avg60_min_window_size", 55)))
        self.clock = clock
        self.name = "replay"

    def _now(self) -> float:
        return self.clock.time()

    def _wall(self) -> str:
        from btcbot.clock import iso
        return iso(self.clock.now())

    async def run(self) -> None:
        await asyncio.Event().wait()


def read_tape(path: Path) -> list[dict]:
    """Read a tape, tolerating damage at the end.

    A tape is being appended to while the bot runs, so any tape from a process
    that was killed ends in a half-written line — and gzip may raise on the
    truncated trailer. Salvage what is readable rather than discarding the
    whole round.
    """
    opener = gzip.open if path.suffix == ".gz" else open
    rows: list[dict] = []
    bad = 0
    try:
        with opener(path, "rt", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    bad += 1
    except Exception as exc:  # noqa: BLE001 - zlib raises its own error type
        log.warning("%s: truncated tape (%s) — using the %d events read",
                    path.name, type(exc).__name__, len(rows))
    if bad:
        log.warning("%s: skipped %d unreadable line(s)", path.name, bad)
    return rows


def market_from_header(header: dict) -> Market:
    return Market(
        ticker=header["ticker"],
        event_ticker=header.get("event_ticker", ""),
        floor_strike=float(header["target"]),
        open_time=parse_iso(header["open_time"]),
        close_time=parse_iso(header["close_time"]),
        status="active",
        title="replay",
        raw=header,
    )


async def replay_one(cfg, path: Path, portfolio: Portfolio, logger: Logger,
                     speed: float, dash: Dashboard | None = None,
                     state: BotState | None = None) -> None:
    events = read_tape(path)
    if not events or events[0].get("kind") != "header":
        log.warning("%s: no header, skipping", path.name)
        return
    header = events[0]["d"]
    market = market_from_header(header)

    clock = VirtualClock(market.open_time)
    book = Book()
    feed = ReplayFeed(clock, cfg)
    fee_cfg = FeeConfig.from_dict(cfg.get("fees"))
    executor = PaperExecutor(fee_cfg, cfg.get("execution.paper", {}), clock=clock)

    trader_cls = build_trader(cfg.get("strategy.name", "ladder"))
    trader = trader_cls(cfg, market, book, feed, executor, portfolio,
                        fee_cfg, logger, clock=clock)
    if state is not None:
        state.market = market
        state.trader = trader
        state.feed = feed
        state.book = book
        state.ws_market = True
        state.ws_index = True
    trader_task = asyncio.create_task(trader.run())
    await _settle(clock)

    for ev in events[1:]:
        kind, d = ev["kind"], ev["d"]

        # Apply market data at the old timestamp, then advance the clock, so
        # the strategy always sees the book as it was at that instant.
        # Same field names the live socket sends — replay must not be able to
        # pass while live fails, which is exactly what happened when this tape
        # used an invented format.
        if kind == "book_snapshot":
            book.apply_snapshot(d.get("yes_dollars_fp") or d.get("yes") or [],
                                d.get("no_dollars_fp") or d.get("no") or [],
                                d.get("seq", 0))
        elif kind == "book_delta":
            if d.get("side") in ("yes", "no"):
                book.apply_delta(d["side"],
                                 d.get("price_dollars", d.get("price")),
                                 d.get("delta_fp", d.get("delta")),
                                 d.get("seq", 0))
        elif kind == "trade":
            taker = d.get("taker_side")
            price = (d.get("yes_price_dollars") if taker == "yes"
                     else d.get("no_price_dollars"))
            count = d.get("count_fp", d.get("count"))
            if taker in ("yes", "no") and price is not None and count is not None:
                executor.on_trade(taker, price, count)

        clock.advance_to(parse_iso(ev["t"]))

        if kind == "index":
            feed.handle_payload(d)

        await _settle(clock)
        if dash is not None:
            dash.render()
        if speed:
            await asyncio.sleep(speed)
        if trader_task.done():
            break

    # Tape exhausted: run the clock past the close so exits and settlement
    # fire. Time is advanced in real steps rather than just waking sleepers,
    # so duration-based loops actually see their deadlines pass.
    end = market.close_time + timedelta(seconds=1)
    for i in range(120):
        if trader_task.done():
            break
        clock.advance_to(end + timedelta(seconds=i * 10))
        clock.release_all()
        await _settle(clock)

    if not trader_task.done():
        trader_task.cancel()
        log.warning("%s: trader did not settle, cancelled", path.name)
    try:
        record = await trader_task
        if state is not None and record is not None:
            state.recent.append(record)
            state.windows_done += 1
    except (asyncio.CancelledError, Exception):  # noqa: BLE001
        pass
    if dash is not None:
        state.trader = None
        dash.render()


async def _settle(clock: VirtualClock, spins: int = 6) -> None:
    """Let woken tasks run to their next await before time moves again."""
    for _ in range(spins):
        await asyncio.sleep(0)


def make_synthetic(dir_: Path, n: int) -> list[Path]:
    """Generate plausible tapes so the plumbing can be smoke-tested offline."""
    dir_.mkdir(parents=True, exist_ok=True)
    out = []
    base = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    rng = random.Random(7)

    for w in range(n):
        open_t = base - timedelta(minutes=15 * (n - w))
        close_t = open_t + timedelta(minutes=15)
        target = 79800 + rng.uniform(-400, 400)
        ticker = f"SYNTH-{open_t:%y%b%d%H%M}".upper()
        path = dir_ / f"{ticker}.jsonl.gz"
        rows = [{"t": open_t.isoformat().replace("+00:00", "Z"), "kind": "header",
                 "d": {"ticker": ticker, "target": round(target, 2),
                       "open_time": open_t.isoformat().replace("+00:00", "Z"),
                       "close_time": close_t.isoformat().replace("+00:00", "Z")}}]

        # A book that starts near 50c and drifts with the index.
        price = target
        yes_c = 50
        drift = rng.choice([1, -1]) * rng.uniform(0.4, 1.6)
        for step in range(0, 900, 2):
            t = (open_t + timedelta(seconds=step)).isoformat().replace("+00:00", "Z")
            price += drift + rng.gauss(0, 3.0)
            rows.append({"t": t, "kind": "index",
                         "d": {"index_id": "BRTI",
                               # same shape Kalshi sends: `data` is a STRING
                               "data": json.dumps({"type": "value",
                                                   "time": step * 1000,
                                                   "id": "BRTI",
                                                   "value": f"{price:.2f}"}),
                               "avg_60s_data": {"value": f"{price:.8f}",
                                                "window_size": min(step, 60),
                                                "window_end_ts_exclusive": step}}})
            edge = max(-40, min(40, (price - target) / 3.0))
            yes_c = int(max(3, min(97, 50 + edge)))
            yb, ya = (yes_c - 1) / 100.0, (yes_c + 1) / 100.0
            rows.append({"t": t, "kind": "book_snapshot",
                         "d": {"market_ticker": ticker,
                               "yes_dollars_fp": [
                                   [f"{yb:.4f}", f"{rng.uniform(50, 400):.2f}"],
                                   [f"{yb - 0.01:.4f}", f"{rng.uniform(50, 400):.2f}"]],
                               "no_dollars_fp": [
                                   [f"{1 - ya:.4f}", f"{rng.uniform(50, 400):.2f}"],
                                   [f"{1 - ya - 0.01:.4f}", f"{rng.uniform(50, 400):.2f}"]],
                               "seq": step}})
            if rng.random() < 0.35:
                rows.append({"t": t, "kind": "trade",
                             "d": {"taker_side": rng.choice(["yes", "no"]),
                                   "yes_price_dollars": f"{yb:.4f}",
                                   "no_price_dollars": f"{1 - yb:.4f}",
                                   "count_fp": f"{rng.uniform(1, 300):.2f}"}})

        with gzip.open(path, "wt", encoding="utf-8") as fh:
            for r in rows:
                fh.write(json.dumps(r) + "\n")
        out.append(path)
    return out


def apply_overrides(cfg, overrides: list[str]) -> None:
    for item in overrides:
        if "=" not in item:
            raise SystemExit(f"--set expects key=value, got {item!r}")
        key, value = item.split("=", 1)
        node = cfg.raw
        parts = key.split(".")
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            parsed = value
        node[parts[-1]] = parsed
        log.info("override %s = %r", key, parsed)


async def amain(args) -> int:
    cfg = load_config(args.config)
    setup_console_logging("INFO")
    if args.set:
        apply_overrides(cfg, args.set)

    # Replay writes to its own log so it never pollutes the live measurement.
    cfg.raw.setdefault("logging", {})
    cfg.raw["logging"]["window_log_path"] = args.out
    cfg.raw["logging"]["event_log_path"] = args.out.replace(".jsonl", "_events.jsonl")
    cfg.raw["logging"]["tape"] = {"enabled": False, "dir": "./tape"}

    if args.synthetic:
        tape_dir = Path("tape/synthetic")
        paths = make_synthetic(tape_dir, args.synthetic)
        print(f"generated {len(paths)} synthetic windows in {tape_dir}")
    else:
        p = Path(args.tape)
        paths = sorted(p.glob("*.jsonl*")) if p.is_dir() else [p]
    if not paths:
        print(f"no tapes found at {args.tape}")
        return 1

    fee_cfg = FeeConfig.from_dict(cfg.get("fees"))
    portfolio = Portfolio(cfg, fee_cfg)
    logger = Logger(cfg)

    dash = state = None
    if args.dashboard:
        from btcbot.orderbook import Book as _Book
        pane = attach_log_pane()
        state = BotState(cfg, portfolio, _Book(),
                         ReplayFeed(VirtualClock(utcnow()), cfg), mode="REPLAY")
        dash = Dashboard(state, pane,
                         theme=cfg.get('logging.dashboard_theme', 'dark'))
        dash.start()
        # A tape replayed at full speed is unwatchable; pace it unless told not to.
        if args.speed == 0.0:
            args.speed = 0.02
    else:
        print(f"replaying {len(paths)} window(s)...")

    try:
        for path in paths:
            await replay_one(cfg, path, portfolio, logger, args.speed, dash, state)
            if portfolio.halted:
                if not dash:
                    print(f"halted after {path.name}: {portfolio.halt_reason}")
                break
    finally:
        if dash:
            dash.render()
            await asyncio.sleep(1.0)
            dash.stop()
    logger.close()

    print(f"\nreplay done. balance ${portfolio.balance:.2f} "
          f"(from ${portfolio.starting_balance:.2f})")
    print(f"log: {args.out}")
    print(f"summary: python summarize.py --log {args.out}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="replay recorded KXBTC15M windows")
    ap.add_argument("--tape", default="tape/", help="tape file or directory")
    ap.add_argument("--config", default=None)
    ap.add_argument("--out", default="logs/replay.jsonl")
    ap.add_argument("--speed", type=float, default=0.0,
                    help="seconds to sleep per tape event (0 = as fast as possible)")
    ap.add_argument("--synthetic", type=int, default=0,
                    help="generate and replay N synthetic windows")
    ap.add_argument("--dashboard", action="store_true",
                    help="live terminal dashboard instead of scrolling logs")
    ap.add_argument("--set", action="append", default=[],
                    help="config override, e.g. --set entry.buy_1.max_price=0.60")
    args = ap.parse_args()
    return asyncio.run(amain(args))


if __name__ == "__main__":
    raise SystemExit(main())
